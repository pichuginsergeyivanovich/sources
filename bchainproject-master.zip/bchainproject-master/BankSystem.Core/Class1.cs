﻿using System;

namespace BankSystem.Core
{
    public class Class1
    {
    }
}
