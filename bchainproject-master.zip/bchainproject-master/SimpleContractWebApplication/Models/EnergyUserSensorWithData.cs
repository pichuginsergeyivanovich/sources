﻿using System;
using System.Collections.Generic;
using EnergyConsumption.Data;

namespace SimpleContractWebApplication.Models
{
    public class EnergyUserSensorWithData
    {
        public int UserSensorId { get; set; }
        public Guid UserId { get; set; }
        public Guid SensorId { get; set; }
        public string SensorText { get; set; }
        public DateTime Created { get; set; }
        public IEnumerable<BillingDataModel> BillingData { get; set; }
        public IEnumerable<SensorData> SensorData { get; set; }
    }
}
