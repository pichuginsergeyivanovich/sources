﻿using System;

namespace SimpleContractWebApplication.Models
{
    public class TariffZoneModel
    {
          public byte TariffZoneId { get; set; }

          public string Text { get; set; }

    }
}
