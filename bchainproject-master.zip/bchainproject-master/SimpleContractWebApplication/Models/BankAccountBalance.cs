﻿using System;

namespace SimpleContractWebApplication.Models
{
    public class BankAccountBalance
    {
        public Guid AccountId { get; set; }
        public decimal Amount { get; set; }

        public DateTime Modified { get; set; }
    }
}
