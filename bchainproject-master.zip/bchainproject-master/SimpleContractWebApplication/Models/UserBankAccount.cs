﻿using System;

namespace SimpleContractWebApplication.Models
{
    public class UserBankAccount
    {
        public int UserAccountId { get; set; }
        public Guid UserId { get; set; }
        public Guid AccountId { get; set; }

        public string BlockchainAddress { get; set; }

        public DateTime Created { get; set; }

        public bool IsAutoPayAllowed { get; set; }

        public Guid AutoPaySensorId { get; set; }
    }
}
