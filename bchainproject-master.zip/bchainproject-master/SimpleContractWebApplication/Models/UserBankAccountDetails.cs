﻿using System.Collections.Generic;

namespace SimpleContractWebApplication.Models
{
    public class UserBankAccountDetails : UserBankAccount
    {
        public IEnumerable<BankTransaction> Transactions { get; set; }

        public IEnumerable<BankInvoiceModel> Invoices { get; set; }

        public BankAccountBalance Balance { get; set; }
    }
}
