﻿using System.Collections.Generic;

namespace SimpleContractWebApplication.Models
{
    public class EnergyServiceProfileDetails
    {
        public IEnumerable<EnergyUserSensor> sensors { get; set; }

    }
}
