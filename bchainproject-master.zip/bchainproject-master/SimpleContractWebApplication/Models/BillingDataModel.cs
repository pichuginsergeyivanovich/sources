﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SimpleContractWebApplication.Models
{
    public class BillingDataModel
    {
        public int Id { get; set; }
        public Guid SensorId { get; set; }
        public int Year { get; set; }
        public int Month { get; set; }
        public long TotalMonthAmount { get; set; }
        public decimal TotalMonthCosts { get; set; }
        public long EstimatedMonthAmount { get; set; }
        public decimal EstimatedMonthCosts { get; set; }
        public DateTime Created { get; set; }
        public DateTime LastUpdated { get; set; }
    }
}
