﻿using System;

namespace SimpleContractWebApplication.Models
{
    public class BankInvoiceModel
    {
            public Guid InvoiceId { get; set; }
            public Guid AccountId { get; set; }

            public string IssuerName { get; set; }
            public string IssuerAddress { get; set; }
            public DateTime IssueDate { get; set; }

            public decimal Amount { get; set; }
            public Guid PaymentAccountId { get; set; }
            public DateTime Created { get; set; }
            public byte StatusId { get; set; }

            public DateTime? StatusChanged { get; set; }

            public byte? TypeId { get; set; }

            public string StatusText { get; set; }

            public string TypeText
            {
                get
                {
                    if (TypeId == 1)
                        return "preview invoice #1";
                    else if(TypeId ==2)
                        return "preview invoice #2";
                    else if (TypeId == 3)
                        return "final invoice";
                    else
                        return "unknown invoice type";
                }
            }

            public short? Year { get; set; }

            public byte? Month { get; set; }

    }
}
