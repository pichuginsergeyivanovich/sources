﻿using System;
using System.ComponentModel;

namespace SimpleContractWebApplication.Models
{
    public class EnergyUserSensor
    {
        [DisplayName("DeviceID")]
        public int UserSensorId { get; set; }
        [DisplayName("UserID")]
        public Guid UserId { get; set; }
        [DisplayName("Device Serial")]
        public Guid SensorId { get; set; }
        [DisplayName("Display Name")]
        public string SensorText { get; set; }
        [DisplayName("Created On")]
        public DateTime Created { get; set; }

        public byte TariffZoneId {get; set;}

        [DisplayName("Last Counters")]
        public int LastCounterValue { get; set; }
        [DisplayName("Last Counters Taken On ")]
        public DateTime LastCounterValueDateTime { get; set; }
    }
}
