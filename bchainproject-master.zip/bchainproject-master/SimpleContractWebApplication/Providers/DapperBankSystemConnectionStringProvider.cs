﻿using Common;
using Microsoft.Extensions.Configuration;

namespace SimpleContractWebApplication.Providers
{
    public class DapperBankSystemConnectionStringProvider : IDapperConnectionStringProvider
    {
        public DapperBankSystemConnectionStringProvider(IConfiguration config)
        {
            ConnectionString = config.GetConnectionString("BankSystemConnection");
        }
        public string ConnectionString { get; }
    }
}
