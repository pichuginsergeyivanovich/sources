﻿using Common;
using Microsoft.Extensions.Configuration;

namespace SimpleContractWebApplication.Providers
{
    public class DapperEnergyServicesConnectionStringProvider : IDapperConnectionStringProvider
    {
        public DapperEnergyServicesConnectionStringProvider(IConfiguration config)
        {
            ConnectionString = config.GetConnectionString("EnergyServicesConnection");
        }
        public string ConnectionString { get; }
    }
}
