﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Threading.Tasks;
using BankSystem.Business;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using SimpleContractWebApplication.Models;

namespace SimpleContractWebApplication.Controllers
{
    [Authorize(Roles="admin")]
    public class SettingsController : Controller
    {
        private readonly SettingsOperations _seops;

        public SettingsController(SettingsOperations seops)
        {
            _seops = seops;
        }
        public IActionResult Index()
        {
            var dbs = _seops.Get();

            return View("SettingsEdit",new SettingsModel()
            {
                InvoiceFinalDate = dbs.InvoiceFinalDate,
                InvoicePreview1Date = dbs.InvoicePreview1Date,
                InvoicePreview2Date = dbs.InvoicePreview2Date
        });
        }
        [HttpPost]
        public IActionResult Index(IFormCollection collection)
        {
            try
            {
                _seops.Add(
                    DateTime.Parse(collection["InvoicePreview1Date"]),
                    DateTime.Parse(collection["InvoicePreview2Date"]),
                    DateTime.Parse(collection["InvoiceFinalDate"])
                    );

                return RedirectToAction(nameof(Index));
            }
            catch(Exception ex)
            {
                return View();
            }
        }
    }
}