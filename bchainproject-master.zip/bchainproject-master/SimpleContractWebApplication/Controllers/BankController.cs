﻿using System;
using System.Linq;
using BankSystem.Business;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using SimpleContractWebApplication.Models;

namespace SimpleContractWebApplication.Controllers
{
    [Authorize()]
    public class BankController : Controller
    {
        private readonly IConfiguration _config;
        private readonly UserAccountOperations _ops;
        private readonly InvoiceOperations _iops;
        private readonly TransactionOperations _tops;
        private readonly InvoiceTextOperations _itops;

        public BankController(IConfiguration config, UserAccountOperations ops, InvoiceOperations iops, TransactionOperations tops, InvoiceTextOperations itops)
        {
            _config = config;
            _ops = ops;
            _iops = iops;
            _tops = tops;
            _itops = itops;

            var cs = config.GetConnectionString("DefaultConnection");
        }
        public IActionResult Index()
        {
            var userId = Guid.Parse(HttpContext.User.Claims
                .FirstOrDefault(i => i.Type == "http://schemas.xmlsoap.org/ws/2005/05/identity/claims/nameidentifier").Value
                );

            var model = _ops.GetList(userId).Select(i => new UserBankAccount()
            {
                AccountId = i.AccountId,
                BlockchainAddress = i.BlockchainAddress,
                UserAccountId = i.UserAccountId,
                UserId = i.UserId,
                Created = i.Created
            });
            
            return View(model);
        }
        // GET: Blockchain/Details/5
        public ActionResult Details(int id)
        {
            

            var userId = Guid.Parse(HttpContext.User.Claims.FirstOrDefault(i => i.Type == "http://schemas.xmlsoap.org/ws/2005/05/identity/claims/nameidentifier").Value);

            var istatus = _itops.GetList().ToDictionary(i=>i.Id);

            var userAccount = _ops.GetOne(id);

            var transactions = _tops.GetList(userAccount.AccountId).Select(i => new BankTransaction()
            {
                AccountId = i.AccountId,
                Amount = i.Value,
                Comment = i.Comment,
                Purpose = i.Purpose,
                StatusId = i.StatusId,
                TransactionId = i.TransactionId,
                Created = i.Created
            });
            var invoices = _iops.GetList(userAccount.AccountId).Select(
                    i => new BankInvoiceModel() { 
                                                    InvoiceId=i.InvoiceId,
                                                    AccountId=i.AccountId,
                                                    Amount=i.Amount,
                                                    IssueDate=i.IssueDate,
                                                    IssuerAddress=i.IssuerAddress,
                                                    IssuerName=i.IssuerName,
                                                    PaymentAccountId=i.PaymentAccountId,
                                                    StatusId=i.StatusId,
                                                    StatusText = istatus[i.StatusId]?.Text,
                                                    StatusChanged=i.StatusChanged,
                                                    Created=i.Created,
                                                    TypeId = i.TypeId,
                                                    Year = i.Year,
                                                    Month = i.Month
                                                });

            var balance = transactions.Sum(i=>i.Amount);

            var model = new UserBankAccountDetails()
            {
                AccountId = userAccount.AccountId,
                BlockchainAddress = userAccount.BlockchainAddress,
                UserAccountId = userAccount.UserAccountId,
                AutoPaySensorId = userAccount.AutoPaySensorId,
                IsAutoPayAllowed = userAccount.IsAutoPayAllowed,
                UserId = userAccount.UserId,
                Created = userAccount.Created,
                Transactions = transactions.OrderByDescending(i=>i.Created),
                Invoices = invoices.OrderByDescending(i=>i.StatusChanged).ThenByDescending(i=>i.Created),
                Balance = new BankAccountBalance() { AccountId = userAccount.AccountId, Amount = balance, Modified = DateTime.Now }
            };

             return View(model);
        }

        // GET: Blockchain/Create
        public ActionResult Create()
        {
            var userId = Guid.Parse(HttpContext.User.Claims
                .FirstOrDefault(i => i.Type == "http://schemas.xmlsoap.org/ws/2005/05/identity/claims/nameidentifier").Value
                );

            var accountId = Guid.NewGuid();

            var userAccount = _ops.AddOne(userId, accountId);

            var model =  new UserBankAccount()
            {
                AccountId = userAccount.AccountId,
                BlockchainAddress = userAccount.BlockchainAddress,
                UserAccountId = userAccount.UserAccountId,
                UserId = userAccount.UserId,
                Created = userAccount.Created
            };

            return View(model);
        }

        // POST: Blockchain/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create(IFormCollection collection)
        {
            try
            {
                // TODO: Add insert logic here

                return RedirectToAction(nameof(Index));
            }
            catch
            {
                return View();
            }
        }
        // POST: Blockchain/Edit/5

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult ProcessInvoice(IFormCollection collection)
        {
            try
            {
                var invoiceId = Guid.Parse(collection["invoiceId"]);
                
                var invoice = _iops.GetOne(invoiceId);
                var transactions = _tops.GetList(invoice.AccountId);
                var balance = transactions.Sum(i => i.Value);

                if(invoice.StatusId==0 && balance >= invoice.Amount)
                {
                    _tops.AddOne(invoice.AccountId, -invoice.Amount, $"invoice #{invoice.InvoiceId}", "Invoice Payment");
                    _iops.UpdageInvoiceStatus(invoice.InvoiceId, 1);
                }
                    

                // TODO: Add update logic here

                return RedirectToAction(nameof(Index));
            }
            catch
            {
                return View();
            }
        }

        // GET: Blockchain/Create
        public ActionResult Charge(Guid accountId)
        {

            var userId = Guid.Parse(HttpContext.User.Claims
                .FirstOrDefault(i => i.Type == "http://schemas.xmlsoap.org/ws/2005/05/identity/claims/nameidentifier").Value
                );

            var model = new BankTransaction()
            {
                AccountId=accountId,
                Amount=0,
                Purpose="Charge"
            };

            return View(model);
        }

        // POST: Blockchain/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Charge(IFormCollection collection)
        {
            try
            {
                var accountId = Guid.Parse(collection["AccountId"]);
                var value = decimal.Parse(collection["Amount"]);
                var comment = collection["Comment"];
                var purpose = collection["Purpose"];

                var transaction = _tops.AddOne(accountId, value, comment, purpose);

                return RedirectToAction(nameof(Index));
            }
            catch(Exception ex)
            {
                return View();
            }
        }

        public ActionResult ChangeAutoPay(int id)
        {
            

            var userId = Guid.Parse(HttpContext.User.Claims
                .FirstOrDefault(i => i.Type == "http://schemas.xmlsoap.org/ws/2005/05/identity/claims/nameidentifier").Value
                );

            var userAccount = _ops.GetOne(id);

            var model = new UserBankAccount()
            {
                AccountId = userAccount.AccountId,
                BlockchainAddress = userAccount.BlockchainAddress,
                UserAccountId = userAccount.UserAccountId,
                UserId = userAccount.UserId,
                Created = userAccount.Created,
                IsAutoPayAllowed=userAccount.IsAutoPayAllowed,
                AutoPaySensorId=userAccount.AutoPaySensorId
            };

            return View("ChangeAutoPay",model);
        }

        // POST: Blockchain/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult ChangeAutoPay(IFormCollection collection)
        {
            try
            {
                var userAccountId = int.Parse(collection["UserAccountId"]);
                var isAutoPayAllowed = bool.Parse(collection["IsAutoPayAllowed"]);
                var autoPaySensorId = Guid.Parse(collection["AutoPaySensorId"]);

                

                var userId = Guid.Parse(HttpContext.User.Claims
                    .FirstOrDefault(i => i.Type == "http://schemas.xmlsoap.org/ws/2005/05/identity/claims/nameidentifier").Value
                    );

                var userAccount = _ops.GetOne(userAccountId);

                _ops.Update(userAccountId, isAutoPayAllowed, autoPaySensorId );


                return RedirectToAction(nameof(Index));
            }
            catch(Exception ex)
            {
                return View();
            }
        }


    }
}