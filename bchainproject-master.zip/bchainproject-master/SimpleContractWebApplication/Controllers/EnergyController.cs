﻿using System;
using System.Collections.Generic;
using System.Linq;
using EnergyConsumption.Business;
using EnergyConsumption.Data;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using SimpleContractWebApplication.Models;

namespace SimpleContractWebApplication.Controllers
{
    [Authorize()]
    public class EnergyController : Controller
    {
        private readonly UserSensorOperations _usops;
        private readonly SensorDataOperations _sdops;
        private readonly TariffOperations _taops;
        private readonly BillingDataOperations _biops;
        private readonly UserManager<IdentityUser> _userManager;

        public EnergyController(UserSensorOperations usops,
                                SensorDataOperations sdops,
                                TariffOperations taops,
                                BillingDataOperations biops,
                                UserManager<IdentityUser> _userManager)
        {
            _usops = usops;
            _sdops = sdops;
            _taops = taops;
            _biops = biops;

            this._userManager = _userManager;
        }
        public IActionResult Index()
        {

            var userId = Guid.Parse(HttpContext.User.Claims.FirstOrDefault(i => i.Type == "http://schemas.xmlsoap.org/ws/2005/05/identity/claims/nameidentifier").Value);

            var dict = new Dictionary<Guid, SensorData>();
            
            var userSensors = _usops.GetList(userId);
            
            foreach(var sid in userSensors.Select(i=>i.SensorId))
            {
                var data = _sdops.GetList(sid).OrderByDescending(i => i.Created).Take(1).FirstOrDefault();

                if(data!=null)
                    dict.Add(sid, data);
            }


            var userEnSensors = userSensors
                .Select(i => new EnergyUserSensor()
                {
                    UserSensorId = i.UserSensorId,
                    UserId = i.UserId,
                    SensorId = i.SensorId,
                    Created = i.Created,
                    SensorText = i.SensorText,
                    LastCounterValue = dict.ContainsKey(i.SensorId) ? dict[i.SensorId].Value : 0,
                    LastCounterValueDateTime = dict.ContainsKey(i.SensorId) ? dict[i.SensorId].Created : DateTime.Now
                }); ;

            var model = new EnergyServiceProfileDetails()
            {
                sensors = userEnSensors
            };

            return View(model);
        }

        // GET: Blockchain/Create
        public ActionResult Create()
        {
            var userId = Guid.Parse(HttpContext.User.Claims.FirstOrDefault(i => i.Type == "http://schemas.xmlsoap.org/ws/2005/05/identity/claims/nameidentifier").Value);

            
            var model = new EnergyUserSensor()
            {
                UserSensorId = 0,
                SensorId = Guid.NewGuid(),
                SensorText="My new smart sensor device(rename me)",
                UserId = userId,
                Created = DateTime.Now
            };

            return View(model);
        }

        // POST: Blockchain/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create(IFormCollection collection)
        {
            try
            {
                var userId = Guid.Parse(HttpContext.User.Claims.FirstOrDefault(i => i.Type == "http://schemas.xmlsoap.org/ws/2005/05/identity/claims/nameidentifier").Value);

                var sensorText = collection["sensorText"];

                var tariffZoneId = byte.Parse(collection["tariffZoneId"]);

                var userSensor = _usops.AddOne(userId, sensorText, tariffZoneId);

                 // TODO: Add insert logic here

                return RedirectToAction(nameof(Index));
            }
            catch(Exception ex)
            {
                return View();
            }
        }
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Delete(int id)
        {
            try
            {
                //var userId = Guid.Parse(HttpContext.User.Claims.FirstOrDefault(i => i.Type == "http://schemas.xmlsoap.org/ws/2005/05/identity/claims/nameidentifier").Value);

                _usops.Delete(id);

                return RedirectToAction(nameof(Index));
            }
            catch(Exception ex)
            {
                return View();
            }
        }

        // GET: Blockchain/Create
        public ActionResult Details(Guid sensorId)
        {
            var userId = Guid.Parse(HttpContext.User.Claims.FirstOrDefault(i => i.Type == "http://schemas.xmlsoap.org/ws/2005/05/identity/claims/nameidentifier").Value);

            var sensor = _usops.GetOne(sensorId, userId);
            
            var data = _sdops.GetList(sensorId).OrderByDescending(i=>i.Created).ToArray();

            var stats = _biops.GetList(sensorId).Select(i => new BillingDataModel()
            {
                SensorId = i.SensorId,
                Year = i.Year,
                Month = i.Month,
                Id = i.Id,
                TotalMonthAmount = i.TotalMonthAmount,
                TotalMonthCosts = i.TotalMonthCosts,
                EstimatedMonthAmount = i.EstimatedMonthAmount,
                EstimatedMonthCosts = i.EstimatedMonthCosts,
                LastUpdated = i.LastUpdated
            }).OrderByDescending(i=>i.Year).ThenByDescending(i=>i.Month);


            var model = new EnergyUserSensorWithData()
            {
                UserSensorId = sensor.UserSensorId,
                SensorId = sensor.SensorId,
                SensorText = sensor.SensorText,
                UserId = sensor.UserId,
                Created = sensor.Created,
                SensorData=data,
                BillingData = stats
            };

            return View("UserSensorDetails",model);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit(IFormCollection collection)
        {
            try
            {

                var userId = Guid.Parse(HttpContext.User.Claims.FirstOrDefault(i => i.Type == "http://schemas.xmlsoap.org/ws/2005/05/identity/claims/nameidentifier").Value);

                var sensorText = collection["sensorText"];

                var sensorId = Guid.Parse(collection["sensorId"]);

                var tariffZoneId = byte.Parse(collection["tariffZoneId"]);

                _usops.UpdateUserSensor(sensorId, sensorText, tariffZoneId);


                // TODO: Add update logic here

                return RedirectToAction(nameof(Index));
            }
            catch(Exception ex)
            {
                return View();
            }
        }
        // GET: Energy/Edit/5
        public ActionResult Edit(Guid id)
        {
            var userId = Guid.Parse(HttpContext.User.Claims.FirstOrDefault(i => i.Type == "http://schemas.xmlsoap.org/ws/2005/05/identity/claims/nameidentifier").Value);

            var sensor = _usops.GetOne(id, userId);

            var tariffZones = _taops.GetList();

            var tzm = tariffZones.Select(i => new TariffZoneModel()
                {TariffZoneId = (byte) i.ZoneId, Text = i.ZoneId.ToString()}).ToList();

            tzm.Add(new TariffZoneModel() {TariffZoneId = 0, Text = "не установлен"});


            ViewBag.tariffZones = tzm;

            var model = new EnergyUserSensor()
            {
                UserSensorId = sensor.UserSensorId,
                SensorId = sensor.SensorId,
                SensorText = sensor.SensorText,
                UserId = sensor.UserId,
                Created = sensor.Created,
                TariffZoneId = sensor.ZoneId
                
            };
            return View(model);
        }

        public ActionResult BillingStats(Guid sensorId)
        {
            var stats = _biops.GetList(sensorId).Select(i => new BillingDataModel()
            {
                SensorId = i.SensorId,
                Year = i.Year,
                Month = i.Month,
                Id = i.Id,
                TotalMonthAmount = i.TotalMonthAmount,
                TotalMonthCosts = i.TotalMonthCosts,
                EstimatedMonthAmount = i.EstimatedMonthAmount,
                EstimatedMonthCosts = i.EstimatedMonthCosts,
                LastUpdated = i.LastUpdated
            });

            return View("BillingStats", stats);
        }


    }
}