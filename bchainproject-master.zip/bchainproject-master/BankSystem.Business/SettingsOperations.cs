﻿using BankSystem.Data;
using Common;
using Dapper;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;


namespace BankSystem.Business
{
    public class SettingsOperations : BaseDapperConnection
    {
        private readonly IDapperConnectionStringProvider _provider;
        public SettingsOperations(IDapperConnectionStringProvider provider) : base(provider)
        {
        }

        public Settings Get()
        {
            return
                ExecuteQuery(
                    db =>
                        db.Query<Settings>("select top 1 * from dbo.[Settings]")?.FirstOrDefault())??new Settings();
        }
        public void Add(DateTime? invoicePreview1Date, DateTime? invoicePreview2Date, DateTime? invoiceFinalDate)
        {
            Execute(
                (db) =>
                    db.Execute(
                        "delete from Settings; insert Settings(invoicePreview1Date,invoicePreview2Date,invoiceFinalDate) values(@invoicePreview1Date, @invoicePreview2Date, @invoiceFinalDate)",
                                            new { invoicePreview1Date, invoicePreview2Date, invoiceFinalDate }));
        }
   


    }
}
