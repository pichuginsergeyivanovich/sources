﻿using BankSystem.Data;
using Common;
using Dapper;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;


namespace BankSystem.Business
{
    public class InvoiceTextOperations : BaseDapperConnection
    {
        public InvoiceTextOperations(IDapperConnectionStringProvider provider) : base(provider)
        {
        }

        public IEnumerable<InvoiceText> GetList()
        {
            return
                ExecuteQuery(
                    db =>
                        db.Query<InvoiceText>("select * from dbo.[InvoiceStatus] (nolock)"))?.ToArray();
        }
    }
}
