﻿/****** Script for SelectTopNRows command from SSMS  ******/
CREATE proc [dbo].[sp_generate_sensor_power_consumption_values] as
with cte as(
select Rank() over(partition by s.SensorId order by sd.created desc)rnk, 
s.SensorId , s.ZoneId,  isnull(sd.created,getdate()) Created ,isnull(sd.value,0) Value
from dbo.UserSensor s(nolock)
left join dbo.SensorData sd(nolock) on sd.SensorId=s.SensorId
)
insert SensorData(SensorId,ZoneId,Value)
select SensorId, ZoneId,
case when Value=0 then RAND()*10 else Value+datediff(minute,Created,getdate())+10*RAND()  end Value

from cte 
where rnk=1
--select  * from SensorData order by Created desc


