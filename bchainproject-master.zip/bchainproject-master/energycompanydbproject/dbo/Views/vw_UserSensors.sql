﻿

CREATE view [dbo].[vw_UserSensors] as
with cte as(
select Rank() over(partition by s.SensorId order by sd.created desc)rnk, 
s.SensorId ,sd.ZoneId, sd.SensorDataId, isnull(sd.created,getdate()) Created ,isnull(sd.value,0) Value
from dbo.UserSensor s(nolock)
left join dbo.SensorData sd(nolock) on sd.SensorId=s.SensorId
)
select * from cte where rnk=1


--backup database energycompany to disk='c:\dev\ec.bak'
