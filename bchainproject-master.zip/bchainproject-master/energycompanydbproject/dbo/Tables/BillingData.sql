﻿CREATE TABLE [dbo].[BillingData] (
    [Id]                   INT              IDENTITY (1, 1) NOT NULL,
    [SensorId]             UNIQUEIDENTIFIER NOT NULL,
    [Year]                 SMALLINT         NOT NULL,
    [Month]                TINYINT          NOT NULL,
    [TotalMonthAmount]     INT              NOT NULL,
    [TotalMonthCosts]      MONEY            NOT NULL,
    [EstimatedMonthAmount] INT              NOT NULL,
    [EstimatedMonthCosts]  MONEY            NOT NULL,
    [Created]              DATETIME         CONSTRAINT [DF_BillingData_Created] DEFAULT (getdate()) NOT NULL,
    [LastUpdated]          DATETIME         CONSTRAINT [DF_BillingData_LastUpdated] DEFAULT (getdate()) NOT NULL,
    CONSTRAINT [PK_BillingData] PRIMARY KEY CLUSTERED ([Id] ASC)
);


GO
CREATE UNIQUE NONCLUSTERED INDEX [IX_BillingData_SensorId_Year_Month]
    ON [dbo].[BillingData]([SensorId] ASC, [Year] ASC, [Month] ASC);

