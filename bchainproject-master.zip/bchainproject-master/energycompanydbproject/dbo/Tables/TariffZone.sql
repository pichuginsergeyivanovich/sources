﻿CREATE TABLE [dbo].[TariffZone] (
    [TariffZoneId] INT      IDENTITY (1, 1) NOT NULL,
    [RatePer1000]  INT      NOT NULL,
    [Created]      DATETIME CONSTRAINT [DF_TariffZone_Created] DEFAULT (getdate()) NOT NULL,
    CONSTRAINT [PK_TariffZone] PRIMARY KEY CLUSTERED ([TariffZoneId] ASC)
);

