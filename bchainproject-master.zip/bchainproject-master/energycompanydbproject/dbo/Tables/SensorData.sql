﻿CREATE TABLE [dbo].[SensorData] (
    [SensorDataId] UNIQUEIDENTIFIER CONSTRAINT [DF_SensorData_SensorDataId] DEFAULT (newid()) NOT NULL,
    [Value]        INT              CONSTRAINT [DF_SensorData_Value] DEFAULT ((0)) NOT NULL,
    [SensorId]     UNIQUEIDENTIFIER NOT NULL,
    [Created]      DATETIME         CONSTRAINT [DF_SensorData_Created] DEFAULT (getdate()) NOT NULL,
    [ZoneId]       TINYINT          CONSTRAINT [DF_SensorData_ZoneId] DEFAULT ((1)) NOT NULL,
    CONSTRAINT [PK_SensorData] PRIMARY KEY CLUSTERED ([SensorDataId] ASC)
);





