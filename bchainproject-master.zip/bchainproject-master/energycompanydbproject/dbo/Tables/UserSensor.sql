﻿CREATE TABLE [dbo].[UserSensor] (
    [UserSensorId]      INT              IDENTITY (1, 1) NOT NULL,
    [UserId]            UNIQUEIDENTIFIER NOT NULL,
    [SensorId]          UNIQUEIDENTIFIER NOT NULL,
    [BlockchainAddress] VARBINARY (20)   NULL,
    [SensorText]        NVARCHAR (50)    NULL,
    [Created]           DATETIME         CONSTRAINT [DF_UserSensor_Created] DEFAULT (getdate()) NOT NULL,
    [ZoneId]            TINYINT          CONSTRAINT [DF_UserSensor_ZoneId] DEFAULT ((1)) NOT NULL,
    CONSTRAINT [PK_UserSensor] PRIMARY KEY CLUSTERED ([UserSensorId] ASC)
);





