﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using Common;
using Nethereum.ABI.FunctionEncoding.Attributes;
using Nethereum.Hex.HexTypes;
using Nethereum.RPC.Eth.DTOs;

namespace Blockchain.Business
{
    public class BankingContractOperations : MediatorContractOperations
    {
        public BankingContractOperations(ContractOperations cop) : base(cop)
        {

        }

        public async Task<TransactionReceipt> insertBankAccount1744256201(uint userAccountId, Guid autopaySensorId)
        {
            try
            {
                var f = _contract.GetFunction("insertBankAccount");

                var r = await f.SendTransactionAndWaitForReceiptAsync(_account.Address,
                    new HexBigInteger(2000000), new HexBigInteger(0), default, userAccountId,
                    autopaySensorId);

                return r;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        [FunctionOutput]
        public class GetBankAccountOutput
        {
            [Parameter("uint32", "user_account_id", 1)]
            public virtual uint UserAccountId { get; set; }

            [Parameter("bytes16", "autopay_sensor_id", 2)]
            public virtual Guid AutoPaySensorId { get; set; }
        }

        public async Task<dynamic> getBankAccount1755393193(uint userAccountId)
        {
            var f = _contract.GetFunction("getBankAccount");

            return await f.CallDeserializingToObjectAsync<GetBankAccountOutput>(userAccountId);
        }

        public async Task<TransactionReceipt> InsertBankAccount(uint userAccountId, Guid autopaySensorId)
        {
            try
            {
                var f = _contract.GetFunction("insertBankAccount");

                var r = await f.SendTransactionAndWaitForReceiptAsync(_account.Address,
                    new Nethereum.Hex.HexTypes.HexBigInteger(2000000), new HexBigInteger(0), default, 
                    userAccountId, autopaySensorId);

                return r;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async Task<GetBankAccountOutput> GetBankAccount(uint userAccountId)
        {
            var f = _contract.GetFunction("getBankAccount");

            return await f
                .CallDeserializingToObjectAsync<BankingContractOperations.GetBankAccountOutput>(userAccountId);
        }
    }
}

