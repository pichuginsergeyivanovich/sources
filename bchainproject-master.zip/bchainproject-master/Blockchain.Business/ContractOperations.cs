﻿using System;
using System.Diagnostics;
using System.IO;
using System.Threading.Tasks;
using Common;
using Nethereum.ABI.FunctionEncoding.Attributes;
using Nethereum.Contracts;
using Nethereum.Hex.HexTypes;
using Nethereum.RPC.Eth.DTOs;
using Nethereum.Web3;
using Nethereum.Web3.Accounts;

namespace Blockchain.Business
{
    public class ContractOperations
    {
        /*
        [FunctionOutput]
        public class GetCurrentInvoiceOutput
        {
            [Parameter("uint32", "user_account_id", 1)]
            public virtual uint UserAccountId { get; set; }

            [Parameter("uint64", "value", 2)] public virtual long Value { get; set; }
        }

        public async Task<dynamic> getCurrentInvoice(uint userAccountId)
        {
            var f = _contract.GetFunction("getCurrentInvoice");

            return await f.CallDeserializingToObjectAsync<GetCurrentInvoiceOutput>(userAccountId);
        }

        public async Task<TransactionReceipt> insertLastSensorCounters(Guid sensorId, Guid sensorDataId,
            long lastCountersValue, DateTime lastCountersDateTime)
        {
            var f = _contract.GetFunction("insertLastSensorCounters");

            return await f.SendTransactionAndWaitForReceiptAsync(_account.Address,
                new Nethereum.Hex.HexTypes.HexBigInteger(2000000), new HexBigInteger(0), default, sensorId,
                sensorDataId, lastCountersValue, lastCountersDateTime.ToBinary());
        }

        [FunctionOutput]
        public class GetLastSensorCountersOutput
        {
            [Parameter("bytes16", "_sensorDataId", 1)]
            public virtual Guid SensorDataId { get; set; }

            [Parameter("uint64", "_lastCountersValue", 2)]
            public virtual long LastCountersValue { get; set; }

            [Parameter("uint256", "_lastCountersDateTime", 3)]
            public virtual long LastCountersDateTime { get; set; }
        }

        //bytes16 _sensorDataId, uint64 _lastCountersValue, uint256 _lastCountersDateTime
        public async Task<dynamic> getLastSensorCounters(Guid sensorId)
        {
            var f = _contract.GetFunction("getLastSensorCounters");

            return await f.CallDeserializingToObjectAsync<GetLastSensorCountersOutput>(sensorId);
        }

        public async Task<TransactionReceipt> insertSensor(Guid sensorId)
        {
            var f = _contract.GetFunction("insertSensor");


            return await f.SendTransactionAndWaitForReceiptAsync(_account.Address,
                new Nethereum.Hex.HexTypes.HexBigInteger(2000000), new HexBigInteger(0), default, sensorId);
        }

        [FunctionOutput]
        public class GetSensorOutput
        {
            [Parameter("bytes16", "_sensor_id", 1)]
            public virtual Guid SensorId { get; set; }

            [Parameter("uint8", "_zone_id", 2)] public virtual byte Zone_id { get; set; }

            [Parameter("int64", "_sensor_data_hash", 3)]
            public virtual long Sensor_data_hash { get; set; }
        }

        public async Task<dynamic> getSensor(Guid sensorId)
        {
            try
            {
                var f = _contract.GetFunction("getSensor");

                return await f.CallDeserializingToObjectAsync<GetSensorOutput>(sensorId);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async Task<long> getSensorDataChkSum(Guid sensorId)
        {
            return await _contract.GetFunction("getSensorDataHash").CallAsync<dynamic>(sensorId);
        }

        public async Task<TransactionReceipt> setSensorDataChkSum(Guid sensorId, long chksum)
        {
            var f = _contract.GetFunction("setSensorDataHash");

            return await f.SendTransactionAndWaitForReceiptAsync(_account.Address,
                new Nethereum.Hex.HexTypes.HexBigInteger(2000000), new HexBigInteger(0), default, sensorId, chksum);
        }

        public async Task<dynamic> getSensorChkSum(Guid sensorId)
        {
            try
            {
                var f = _contract.GetFunction("getSensorHash");

                return await f.CallAsync<dynamic>(sensorId);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async Task<TransactionReceipt> setSensorChkSum(Guid sensorId, long chksum)
        {
            var f = _contract.GetFunction("setSensorHash");

            return await f.SendTransactionAndWaitForReceiptAsync(_account.Address,
                new Nethereum.Hex.HexTypes.HexBigInteger(2000000), new HexBigInteger(0), default, sensorId, chksum);
        }
        */
        private readonly string _url;
        private readonly string _privateKey;
        private readonly string _contractAddress;
        private readonly Web3 _web3;
        private readonly Account _account;
        private readonly Contract _contract;

        public static string _abi
        {
            get
            {
                var abiFromFile = File.Exists("./abi.txt") ? File.ReadAllText("./abi.txt") : "";

                return abiFromFile;
            }
        }

        public static string _byteCode
        {
            get
            {
                var bcFromFile = File.Exists("./bc.txt") ? File.ReadAllText("./bc.txt") : "";

                return bcFromFile.Trim();
            }
        }

        public ContractOperations(IContractConnectionProvider provider):this(provider.Url, provider.PrivateKey, provider.Address)
        {
        }

        public ContractOperations(string url, string privateKey, string contractAddress)
        {
            _url = url;

            _privateKey = privateKey;

            _contractAddress = contractAddress;

            _account = new Nethereum.Web3.Accounts.Account(privateKey);

            _web3 = new Web3(_account, url);

            var abiFromFile = File.Exists("./abi.txt") ? File.ReadAllText("./abi.txt") : "";

            //Debug.Assert(abiFromFile=="");

            _contract = _web3.Eth.GetContract(abiFromFile, contractAddress);

        }

        public Contract Contract => _contract;

        public Web3 Web3 => _web3;

        public Account Account => _account;

}
}
