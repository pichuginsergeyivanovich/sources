﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using Nethereum.Contracts;
using Nethereum.Hex.HexTypes;
using Nethereum.RPC.Eth.DTOs;
using Nethereum.Web3.Accounts;

namespace Blockchain.Business
{
    public class MediatorContractOperations
    {
        private readonly ContractOperations _cop;

        public MediatorContractOperations(ContractOperations cop)
        {
            _cop = cop;
        }

        protected MediatorContractOperations()
        {
        }

        protected Account _account => _cop.Account;
        protected Contract _contract => _cop.Contract;






    }
}
