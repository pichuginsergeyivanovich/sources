﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using Nethereum.Contracts;
using Nethereum.Hex.HexTypes;
using Nethereum.RPC.Eth.DTOs;
using Nethereum.Web3.Accounts;

namespace Blockchain.Business
{
    public class TariffContractOperation :MediatorContractOperations
    {

        public TariffContractOperation(ContractOperations cop):base(cop)
        {
        }

        public async Task<long> GetTariffZonesChkSum()
        {
            return await _contract.GetFunction("getTariffZoneChkSum").CallAsync<long>();
        }
        public async Task<TransactionReceipt> SetTariffZoneChkSum(long chksum)
        {
            var f = _contract.GetFunction("setTariffZoneChkSum");

            return await f.SendTransactionAndWaitForReceiptAsync(_account.Address, new Nethereum.Hex.HexTypes.HexBigInteger(2000000), new HexBigInteger(0), default, chksum);
        }
        public async Task<TransactionReceipt> EmptyTariffZones()
        {
            var f = _contract.GetFunction("emptyTariffZoneChkSum");

            return await f.SendTransactionAndWaitForReceiptAsync(_account.Address, new Nethereum.Hex.HexTypes.HexBigInteger(2000000), new HexBigInteger(0), default);
        }



        public async Task<int> GetTariffZonesCount()
        {
            return await _contract.GetFunction("getTariffZones").CallAsync<int>();
        }

        //loadTariffZone
        public async Task<TransactionReceipt> LoadTariffZone(int zoneId, long ratePer1000)
        {
            var f = _contract.GetFunction("loadTariffZone");

            //var receipt = web3.Eth.DeployContract.SendRequestAndWaitForReceiptAsync(
            //    ContractOperations._abi,
            //    ContractOperations._contractByteCode,
            //    senderAddress,
            //    new Nethereum.Hex.HexTypes.HexBigInteger(2000000),
            //    //0,
            //    default)

            return await f.SendTransactionAndWaitForReceiptAsync(_account.Address,
                new Nethereum.Hex.HexTypes.HexBigInteger(2000000), new HexBigInteger(0), default, zoneId, ratePer1000);
        }




    }
}
