﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using Common;
using Nethereum.ABI.FunctionEncoding.Attributes;
using Nethereum.Hex.HexTypes;
using Nethereum.RPC.Eth.DTOs;

namespace Blockchain.Business
{
    public class SensorContractOperations : MediatorContractOperations 
    {
        public SensorContractOperations(ContractOperations cop):base(cop)
        {

        }
        public async Task<TransactionReceipt> AddData(Guid sensorId, byte zoneId, long value, DateTime created)
        {
            try
            {
                var f = _contract.GetFunction("add_data");

                var r = await f.SendTransactionAndWaitForReceiptAsync(_account.Address,
                    new Nethereum.Hex.HexTypes.HexBigInteger(2000000), new HexBigInteger(0), default,
                    sensorId.ToByteArray(), zoneId, value, created.Year, created.Month, created.Day);

                return r;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public async Task<dynamic> GetData(Guid sensorId, short year, byte month, long index)
        {
            var f = _contract.GetFunction("get_data");

            return await f.CallAsync<dynamic>(sensorId.ToByteArray(), year, month, index);
        }
        public async Task<dynamic> GetDataLength(Guid sensorId, short year, byte month)
        {
            var f = _contract.GetFunction("get_data_len");

            return await f.CallAsync<dynamic>(sensorId.ToByteArray(), year, month);
        }

    }
}
