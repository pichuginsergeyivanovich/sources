﻿using Nethereum.Hex.HexTypes;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using Common;
using Nethereum.ABI.FunctionEncoding.Attributes;
using Nethereum.RPC.Eth.DTOs;

namespace Blockchain.Business
{
    public class SettingsContractOperations : MediatorContractOperations
    {
        public SettingsContractOperations(ContractOperations cop) : base(cop)
        {
            //function set_settings(uint _final_invoice_date, uint _pre1_invoice_date, uint _pre2_invoice_date) public
            //function get_settings() public view returns (uint final_invoice_date, uint pre1_invoice_date, uint pre2_invoice_date ) 
        }

        public async Task<TransactionReceipt> SetSettings(DateTime finalInvoiceDate, DateTime pre1InvoiceDate, DateTime pre2InvoiceDate)
        {
            try
            {
                var f = _contract.GetFunction("set_settings");

                var r = await f.SendTransactionAndWaitForReceiptAsync(_account.Address,
                    new Nethereum.Hex.HexTypes.HexBigInteger(2000000), new HexBigInteger(0), default,
                    finalInvoiceDate.ToUnixTime(),
                    pre1InvoiceDate.ToUnixTime(),
                    pre2InvoiceDate.ToUnixTime());

                return r;
            }
            catch (Exception ex)
            {
                throw ex;

            }
        }

        [FunctionOutput]
        public class GetSettingsOutput
        {
            [Parameter("uint", "final_invoice_date", 1)]
            public virtual long _finalInvoiceDate { get; set; }
            [Parameter("uint", "pre1_invoice_date", 1)]
            public virtual long _pre1InvoiceDate { get; set; }
            [Parameter("uint", "pre2_invoice_date", 1)]
            public virtual long _pre2InvoiceDate{ get; set; }


            public DateTime FinalInvoiceDate => _finalInvoiceDate.FromUnixTime();
            public DateTime Pre1InvoiceDate => _pre1InvoiceDate.FromUnixTime();
            public DateTime Pre2InvoiceDate => _pre2InvoiceDate.FromUnixTime();

            public override string ToString()
            {
                return $"FinalInvoiceDate:{FinalInvoiceDate}\r\nPre1InvoiceDate:{Pre1InvoiceDate}\r\nPre2InvoiceDate:{Pre2InvoiceDate}";
            }
        }
       // returns(uint final_invoice_date, uint pre1_invoice_date, uint pre2_invoice_date)

        public async Task<GetSettingsOutput> GetSettings()
        {
            var f = _contract.GetFunction("get_settings");

            return await f.CallDeserializingToObjectAsync<GetSettingsOutput>();
        }

    }
}
