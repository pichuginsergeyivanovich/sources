﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using Common;
using Nethereum.ABI.FunctionEncoding.Attributes;
using Nethereum.Hex.HexTypes;
using Nethereum.RPC.Eth.DTOs;

namespace Blockchain.Business
{
    public class BillingContractOperations : MediatorContractOperations 
    {
        public BillingContractOperations(ContractOperations cop):base(cop)
        {

        }
        public async Task<TransactionReceipt> ProcessBilling(Guid sensorId)
        {
            try
            {
                var f = _contract.GetFunction("process_billing");

                var r = await f.SendTransactionAndWaitForReceiptAsync(_account.Address,
                    new Nethereum.Hex.HexTypes.HexBigInteger(2000000), new HexBigInteger(0), default, sensorId.ToByteArray());

                return r;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        //returns(uint total_month_amount, uint estimated_month_amount, uint total_month_costs, uint estimated_month_costs){
        [FunctionOutput]
        public class GetBillingDataOutput
        {
            [Parameter("uint", "total_month_amount", 1)]
            public virtual System.Numerics.BigInteger TotalMonthAmount { get; set; }
            [Parameter("uint", "estimated_month_amount", 1)]
            public virtual System.Numerics.BigInteger EstimatedMonthAmount { get; set; }
            [Parameter("uint", "total_month_costs", 2)]
            public virtual System.Numerics.BigInteger TotalMonthCosts { get; set; }
            [Parameter("uint", "estimated_month_costs", 2)]
            public virtual System.Numerics.BigInteger EstimatedMonthCosts { get; set; }

            public override string ToString()
            {
                return $"TotalMonthAmount:{TotalMonthAmount}, EstimatedMonthAmount:{EstimatedMonthAmount}, TotalMonthCosts:{TotalMonthCosts}, EstimatedMonthCosts:{EstimatedMonthCosts}";
            }
        }
        public async Task<GetBillingDataOutput> GetBillingData(Guid sensorId, DateTime date)
        {
            var f = _contract.GetFunction("get_billing_data");

            return await f.CallDeserializingToObjectAsync<GetBillingDataOutput>(sensorId.ToByteArray(), date.ToUnixTime());
        }

    }
}
