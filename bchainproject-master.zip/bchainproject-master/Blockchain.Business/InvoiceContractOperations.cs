﻿using Nethereum.Hex.HexTypes;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using Common;
using Nethereum.ABI.FunctionEncoding.Attributes;
using Nethereum.RPC.Eth.DTOs;

namespace Blockchain.Business
{
    public class InvoiceContractOperation : MediatorContractOperations
    {
        public InvoiceContractOperation(ContractOperations cop) : base(cop)
        {
            //function process_invoices(bytes16 _sensor_id, uint16 _year, uint8 _month)
        }

        public async Task<TransactionReceipt> ProcessInvoices(int userAccountId, DateTime date)
        {
            return await ProcessInvoices(userAccountId, (short)date.Year, (byte)date.Month, (byte)date.Day);
        }
        public async Task<TransactionReceipt> ProcessInvoices(int userAccountId, short year, byte month, byte day)
        {
            try
            {
                var f = _contract.GetFunction("process_invoices");

                var r = await f.SendTransactionAndWaitForReceiptAsync(_account.Address,
                    new Nethereum.Hex.HexTypes.HexBigInteger(2000000), new HexBigInteger(0), default,
                    (uint)userAccountId, year, month, day);

                return r;
            }
            catch (Exception ex)
            {
                throw ex;

            }
        }
        [FunctionOutput]
        public class GetInvoiceOutput
        {
            [Parameter("uint", "created", 1)]
            public virtual long _Created { get; set; }
            [Parameter("uint", "total_month_amount", 1)]
            public virtual System.Numerics.BigInteger TotalMonthAmount { get; set; }
            [Parameter("uint", "estimated_month_amount", 1)]
            public virtual System.Numerics.BigInteger EstimatedMonthAmount { get; set; }
            [Parameter("uint", "total_month_costs", 2)]
            public virtual System.Numerics.BigInteger TotalMonthCosts { get; set; }
            [Parameter("uint", "estimated_month_costs", 2)]
            public virtual System.Numerics.BigInteger EstimatedMonthCosts { get; set; }
            [Parameter("bool", "is_completed", 2)]
            public virtual bool IsCompleted { get; set; }

            public DateTime Created => _Created.FromUnixTime();

            public override string ToString()
            {
                return $"Created:{Created}(unix:{_Created.FromUnixTime()})\r\n" +
                       $"TotalMonthAmount:{TotalMonthAmount}\r\n" +
                       $"EstimatedMonthAmount:{EstimatedMonthAmount}\r\n" +
                       $"TotalMonthCosts:{TotalMonthCosts}\r\n" +
                       $"EstimatedMonthCosts:{EstimatedMonthCosts}\r\n"+
                       $"IsCompleted:{IsCompleted}";
            }
        }
        //function get_invoice(uint32 _bank_account_id, uint16 _year, uint8 _month, uint8 _type) public view
        //   returns(uint created, uint total_month_amount, uint estimated_month_amount, uint total_month_costs, uint estimated_month_costs)

        public async Task<GetInvoiceOutput> GetInvoice(uint bankAccountId, short year, byte month, byte type)
        {
            var f = _contract.GetFunction("get_invoice");

            return await f.CallDeserializingToObjectAsync<GetInvoiceOutput>(
                bankAccountId, year, month, type);
        }

        public async Task<TransactionReceipt> CompleteInvoice(uint userAccountId, short year, byte month, Guid? transactionId)
        {
            try
            {
                var txBytes = transactionId.HasValue ? transactionId.Value.ToByteArray() : new byte[0];

                var f = _contract.GetFunction("complete_invoice");

                var r = await f.SendTransactionAndWaitForReceiptAsync(_account.Address,
                    new Nethereum.Hex.HexTypes.HexBigInteger(2000000), new HexBigInteger(0), default,
                    userAccountId, year, month, txBytes);

                return r;
            }
            catch (Exception ex)
            {
                throw ex;

            }
        }
    }
}
