﻿

using Common;
using Dapper;
using EnergyConsumption.Data;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;

namespace EnergyConsumption.Business
{
    public class BillingDataOperations : BaseDapperConnection
    {
        public BillingDataOperations(IDapperConnectionStringProvider provider) : base(provider)
        {
        }
        public IEnumerable<BillingData> GetList(Guid sensorId)
        {
            return
                ExecuteQuery(
                    db =>
                        db.Query<BillingData>("select * from dbo.[BillingData] (nolock) where SensorId=@sensorId",
                            new { sensorId }))?.ToArray();
        }

        public void Add(Guid sensorId, short year, byte month, long totalMonthAmount, decimal totalMonthCosts, long estimatedMonthAmount, decimal estimatedMonthCosts)
        {
            var bd = new BillingData()
            {
                SensorId = sensorId,
                Year = year,
                Month = month,
                TotalMonthAmount = totalMonthAmount,
                TotalMonthCosts = totalMonthCosts,
                EstimatedMonthAmount = estimatedMonthAmount,
                EstimatedMonthCosts = estimatedMonthCosts
            };

            Execute(
                (db) =>
                    db.Execute("insert into dbo.[BillingData] (SensorId, Year, Month, TotalMonthAmount, TotalMonthCosts, EstimatedMonthAmount, EstimatedMonthCosts) values(@sensorId, @year, @month, @totalMonthAmount, @totalMonthCosts, @estimatedMonthAmount, @estimatedMonthCosts)", bd));

    }

    public void Update(Guid sensorId, short year, byte month, long totalMonthAmount, decimal totalMonthCosts,
            long estimatedMonthAmount, decimal estimatedMonthCosts)
        {
            var bd = new BillingData()
            {
                SensorId = sensorId,
                Year = year,
                Month = month,
                TotalMonthAmount = totalMonthAmount,
                TotalMonthCosts = totalMonthCosts,
                EstimatedMonthAmount = estimatedMonthAmount,
                EstimatedMonthCosts = estimatedMonthCosts
            };

            Execute(
                (db) =>
                    db.Execute(
                        "update dbo.[BillingData] set TotalMonthAmount = @totalMonthAmount, TotalMonthCosts = @totalMonthCosts, EstimatedMonthAmount = @estimatedMonthAmount, EstimatedMonthCosts = @estimatedMonthCosts, LastUpdated = getdate() " +
                        "where SensorId = @sensorId and Year = @year and Month = @month", bd));
        }

        public bool Exists(Guid sensorId, short year, byte month)
        {
            return ExecuteQuery(db => db.Query<BillingData>(
                       "select * from dbo.[BillingData] (nolock) where SensorId = @sensorId and Year = @year and Month = @month",
                       new {sensorId, year, month}))?.FirstOrDefault() != null;
        }

        public void AddOrUpdate(Guid sensorId, short year, byte month, long totalMonthAmount, decimal totalMonthCosts,
            long estimatedMonthAmount, decimal estimatedMonthCosts)
        {
            if (Exists(sensorId, year, month))

                Update(sensorId, year, month, totalMonthAmount, totalMonthCosts, estimatedMonthAmount, estimatedMonthCosts);
            
            else
                
                Add(sensorId, year, month, totalMonthAmount, totalMonthCosts, estimatedMonthAmount, estimatedMonthCosts);
        }
    }

}
