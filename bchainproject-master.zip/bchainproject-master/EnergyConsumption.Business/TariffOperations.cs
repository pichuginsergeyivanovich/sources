﻿

using Common;
using Dapper;
using EnergyConsumption.Data;
using System;
using System.Collections.Generic;
using System.Linq;

namespace EnergyConsumption.Business
{
    public class TariffOperations : BaseDapperConnection
    {
        public TariffOperations(IDapperConnectionStringProvider provider) : base(provider)
        {
        }

        public long GetTariffZoneCheckSum()
        {
            return GetTableChecksum("TariffZone");
        }

        public IEnumerable<TariffZone> GetList()
        {
            return ExecuteQuery(db => db.Query<TariffZone>("select TariffZoneId ZoneId, RatePer1000, Created from dbo.[TariffZone] (nolock)"))?.ToArray();
        }

        public void AddTariffZoneIfNotExist(int zoneId, int ratePer1000)
        {
            Execute(
                (db) =>
                    db.Execute("if not exists(select * from dbo.TariffZone where TariffZoneId=@zoneId) begin insert into dbo.[TariffZone] (TariffZoneId, RatePer1000) values(@zoneId, @ratePer1000) end else begin update dbo.[TariffZone] set RatePer1000 = @ratePer1000 where TariffZoneId = @zoneId end", new{zoneId, ratePer1000}));
        }
    }
}

