﻿

using Common;
using Dapper;
using EnergyConsumption.Data;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Data.Common;
using System.IO;
using System.Linq;
using System.Text;

namespace EnergyConsumption.Business
{
    public class JsonTariffOperations 
    {
        private readonly ITariffZonesJsonProvider _provider;

        public JsonTariffOperations(ITariffZonesJsonProvider provider)
        {
            _provider = provider;
        }
        long GetChecksum(string s)
        {
            long checksum = 0;

            byte[] binary = Encoding.Unicode.GetBytes(s);

            foreach (byte b in binary)
            {
                checksum = ((checksum + b) & 0xFF);
            }
            checksum = (((checksum ^ 0xFF) + 1) & 0xFF);
            
            return checksum;
        }
        public long GetTariffZoneCheckSum()
        {
            var json = File.ReadAllText(_provider.Filename);

            return GetChecksum(json);
        }

        public IEnumerable<TariffZone> GetList()
        {
            var json = File.ReadAllText(_provider.Filename);

           var items = JsonConvert.DeserializeObject<List<TariffZone>>(json);

            return items;
        }


    }
}

