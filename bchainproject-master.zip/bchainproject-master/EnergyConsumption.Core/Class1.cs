﻿using System;

namespace EnergyConsumption.Core
{
    public class Class1
    {
    }
}
