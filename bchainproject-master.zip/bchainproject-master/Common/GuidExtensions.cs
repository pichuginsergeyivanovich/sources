﻿using System;
using System.Collections.Generic;
using System.Numerics;
using System.Text;

namespace Common
{
    public static class GuidExtensions
    {
        public static string ToBinary(this Guid value)
        {
            string hex = BitConverter.ToString(value.ToByteArray());
            hex = hex.Replace("-", "");
            return hex;
        }
        public static BigInteger ToBigInteger(this Guid value)
        {
            string hex = BitConverter.ToString(value.ToByteArray());
            hex = hex.Replace("-", "");
            return BigInteger.Parse(hex);
        }

        public static long ToUnixTime(this DateTime value)
        {
            return (long)value.Subtract(new DateTime(1970, 1, 1)).TotalSeconds;
        }
        public static DateTime FromUnixTime(this long value)
        {
            return new DateTime(1970, 1, 1).AddSeconds(value);
        }

    }
}
