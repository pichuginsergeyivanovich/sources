﻿namespace Common
{
    public interface IContractConnectionProvider
    {
        string Url { get; }
        string Address { get; }
        string PrivateKey { get; }
    }
}