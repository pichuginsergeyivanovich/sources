﻿namespace Common
{
    public interface ITariffZonesJsonProvider
    {
        string Filename { get; } 
    }
}