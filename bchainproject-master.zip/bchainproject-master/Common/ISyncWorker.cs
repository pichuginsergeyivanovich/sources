﻿using System.Threading;
using System.Threading.Tasks;

namespace Common
{
    public interface ISyncWorker
    {
        void Run(CancellationToken cancellationToken, object locker);
        Task SyncCycle(System.Threading.CancellationToken cancellationToken, object locker);
        Task SyncFunction(object locker);
    }

}
