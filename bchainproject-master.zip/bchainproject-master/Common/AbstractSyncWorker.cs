﻿using System;
using System.Threading;
using System.Threading.Tasks;

namespace Common
{
    public abstract class AbstractSyncWorker: ISyncWorker
    {
        public void Run(CancellationToken cancellationToken,object locker)
        {
            Task.Factory.StartNew(async () => await SyncCycle(cancellationToken, locker), cancellationToken);
        }

        public async Task SyncCycle(CancellationToken cancellationToken, object locker)
        {
            while (!cancellationToken.IsCancellationRequested)
            {
                Console.WriteLine("=======================================");
                
                Console.WriteLine($"{TaskName}: cycle begins");

                await SyncFunction(locker);

                Console.WriteLine($"{TaskName}: cycle completes");

                await Task.Delay(1000 * 15 * 1, cancellationToken);
            }
        }

        public abstract string TaskName {get;}

        public abstract Task SyncFunction(object locker);
    }
}
