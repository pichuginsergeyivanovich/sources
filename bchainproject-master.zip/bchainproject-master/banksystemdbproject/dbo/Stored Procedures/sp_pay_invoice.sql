﻿/****** Script for SelectTopNRows command from SSMS  ******/
CREATE proc [dbo].[sp_pay_invoice](@invoiceId uniqueidentifier, @txId uniqueidentifier)
as
begin

set xact_abort on

begin try
begin tran

insert dbo.[Transaction] (TransactionId, AccountId, Value, StatusId, Comment, Purpose)
SELECT 
TransactionId = @txId,
i.AccountId, 
Value = -i.Amount,
StatusId = 1,
Comment = N'invoice #{'+cast(i.InvoiceId as nvarchar(max))+N'}',
Purpose = 'Invoice Payment'

FROM [dbo].[Invoice] i 
inner join 
(
	select AccountId, sum(Value) Value
	from dbo.[Transaction] 
	group by AccountId
)t on t.AccountId=i.AccountId
WHERE  i.InvoiceId=@invoiceId and t.Value>=i.Amount

update dbo.Invoice set TransactionId = @txId, StatusId = 1, StatusChanged = getdate() where InvoiceId = @invoiceId

commit tran

end try
begin catch

if(XACT_STATE()=-1)
	if @@TRANCOUNT>0
		rollback

if(XACT_STATE()=1)
	if @@TRANCOUNT>0
		commit

end catch
end
