﻿--exec sp_addOrUpdateInvoice
CREATE proc sp_addOrUpdateInvoice(
@userAccountId int=2,
@amount money=1234567,
@issuerName nvarchar(50)=N'SimpleContract',
@issuerAddress varchar(20) = 'SimpleContractAddress',
@issueDate datetime='2019-11-09',
@invoiceType int =1,
@year smallint= 2019,
@month tinyint= 11
)
as begin
if not exists(
	select * from Invoice i
	inner join UserAccount a on a.AccountId=i.AccountId
	where UserAccountId=@userAccountId and i.TypeId=@invoiceType and i.[Year]=@year and i.[Month]=@month and i.IssueDate=@issueDate and i.IssuerName=@issuerName
)
begin
	insert Invoice (AccountId, IssuerName, IssuerAddress, Amount, PaymentAccountId, IssueDate, TypeId, [Year], [Month])
	select 
		AccountId,
		IssuerName=@issuerName,
		IssuerAddress=@issuerAddress,
		Amount=@amount,
		PaymentAccountId='DFE1F4AE-0732-49E2-BA16-61FD49F8F804',
		IssueDate=@issueDate,
		[TypeId]=@invoiceType,
		[Year]=@year,
		[Month]=@month
	from UserAccount
	where UserAccountId=@userAccountId
end
else

begin	

	update Invoice 
		set Amount = @amount
	from Invoice i
	inner join UserAccount a on a.AccountId=i.AccountId
	where a.UserAccountId = @userAccountId
		and i.TypeId=@invoiceType 
		and i.[Year]=@year 
		and i.[Month]=@month 
		and i.IssueDate=@issueDate 
		and i.IssuerName=@issuerName

end

end