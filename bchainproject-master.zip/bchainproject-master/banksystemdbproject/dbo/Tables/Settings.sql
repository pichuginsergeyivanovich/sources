﻿CREATE TABLE [dbo].[Settings] (
    [Id]                  INT      IDENTITY (1, 1) NOT NULL,
    [InvoicePreview1Date] DATETIME NULL,
    [InvoicePreview2Date] DATETIME NULL,
    [InvoiceFinalDate]    DATETIME NULL,
    CONSTRAINT [PK_Settings] PRIMARY KEY CLUSTERED ([Id] ASC)
);

