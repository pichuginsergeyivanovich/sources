﻿CREATE TABLE [dbo].[Invoice] (
    [InvoiceId]        UNIQUEIDENTIFIER CONSTRAINT [DF_Invoice_InvoiceId] DEFAULT (newid()) NOT NULL,
    [AccountId]        UNIQUEIDENTIFIER NOT NULL,
    [IssuerName]       NVARCHAR (50)    NOT NULL,
    [IssuerAddress]    VARCHAR (20)     NOT NULL,
    [Amount]           MONEY            CONSTRAINT [DF_Invoice_Amount] DEFAULT ((0)) NOT NULL,
    [PaymentAccountId] UNIQUEIDENTIFIER NOT NULL,
    [IssueDate]        DATETIME         NOT NULL,
    [Created]          DATETIME         CONSTRAINT [DF_Invoice_Created] DEFAULT (getdate()) NOT NULL,
    [StatusId]         TINYINT          CONSTRAINT [DF_Invoice_StatusId] DEFAULT ((0)) NOT NULL,
    [StatusChanged]    DATETIME         NULL,
    [TypeId]           TINYINT          NULL,
    [Year]             SMALLINT         NULL,
    [Month]            TINYINT          NULL,
    [TransactionId]    UNIQUEIDENTIFIER NULL,
    CONSTRAINT [PK_Invoice] PRIMARY KEY CLUSTERED ([InvoiceId] ASC)
);

