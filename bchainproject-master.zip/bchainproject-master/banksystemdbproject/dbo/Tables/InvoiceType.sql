﻿CREATE TABLE [dbo].[InvoiceType] (
    [Id]   TINYINT      NOT NULL,
    [Text] VARCHAR (50) NOT NULL,
    CONSTRAINT [PK_InvoiceType] PRIMARY KEY CLUSTERED ([Id] ASC)
);

