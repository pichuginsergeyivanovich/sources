﻿CREATE TABLE [dbo].[Account] (
    [AccountId] UNIQUEIDENTIFIER CONSTRAINT [DF_Account_AccountId] DEFAULT (newid()) NOT NULL,
    [Balance]   MONEY            CONSTRAINT [DF_Account_Balance] DEFAULT ((0)) NOT NULL,
    [Created]   DATETIME         CONSTRAINT [DF_Account_Created] DEFAULT (getdate()) NOT NULL,
    [Modified]  DATETIME         NULL,
    CONSTRAINT [PK_Account_1] PRIMARY KEY CLUSTERED ([AccountId] ASC)
);

