﻿CREATE TABLE [dbo].[User] (
    [UserId]       UNIQUEIDENTIFIER NOT NULL,
    [UserName]     VARCHAR (50)     NOT NULL,
    [PasswordHash] VARCHAR (50)     NOT NULL,
    [Created]      DATETIME         CONSTRAINT [DF_User_Created] DEFAULT (getdate()) NOT NULL,
    CONSTRAINT [PK_User] PRIMARY KEY CLUSTERED ([UserId] ASC)
);

