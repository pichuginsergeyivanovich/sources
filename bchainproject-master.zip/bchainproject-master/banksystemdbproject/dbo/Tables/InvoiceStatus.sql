﻿CREATE TABLE [dbo].[InvoiceStatus] (
    [Id]   TINYINT       NOT NULL,
    [Text] NVARCHAR (50) NOT NULL,
    CONSTRAINT [PK_InvoiceStatus] PRIMARY KEY CLUSTERED ([Id] ASC)
);

