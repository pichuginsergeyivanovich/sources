﻿CREATE TABLE [dbo].[UserAccount] (
    [UserAccountId]     INT              IDENTITY (1, 1) NOT NULL,
    [UserId]            UNIQUEIDENTIFIER NOT NULL,
    [AccountId]         UNIQUEIDENTIFIER NOT NULL,
    [BlockchainAddress] VARBINARY (20)   NULL,
    [Created]           DATETIME         CONSTRAINT [DF_UserAccount_Created] DEFAULT (getdate()) NOT NULL,
    [IsAutoPayAllowed]  BIT              CONSTRAINT [DF_UserAccount_SettingAllowAutoPay] DEFAULT ((0)) NOT NULL,
    [AutoPaySensorId]   UNIQUEIDENTIFIER NULL,
    CONSTRAINT [PK_UserAccount] PRIMARY KEY CLUSTERED ([UserAccountId] ASC)
);

