﻿CREATE TABLE [dbo].[Transaction] (
    [TransactionId] UNIQUEIDENTIFIER CONSTRAINT [DF_Transaction_TransactionId] DEFAULT (newid()) NOT NULL,
    [AccountId]     UNIQUEIDENTIFIER NOT NULL,
    [Value]         MONEY            NOT NULL,
    [StatusId]      TINYINT          CONSTRAINT [DF_Transaction_StatusId] DEFAULT ((0)) NOT NULL,
    [Comment]       NVARCHAR (MAX)   NULL,
    [Purpose]       NVARCHAR (MAX)   NULL,
    [Created]       DATETIME         CONSTRAINT [DF_Transaction_Created] DEFAULT (getdate()) NOT NULL,
    CONSTRAINT [PK_Transaction] PRIMARY KEY CLUSTERED ([TransactionId] ASC)
);

