﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using BankSystem.BankingService.Providers;
using BankSystem.BankingService.Tasks;
using BankSystem.Business;
using Blockchain.Business;
using Common;
using Contracts;
using Microsoft.Extensions.Configuration;
using Newtonsoft.Json.Serialization;

namespace BankSystem.BankingService
{
    //приложение сервиса
    public class ConsoleApplication
    {
        private readonly SyncBankAccountWorker _workerSyncBankAccount;
        private readonly SyncSettingsWorker _workerSyncSettings;
        private readonly SyncPayedInvoicesWorker _workerSyncPayedInvoices;
        private readonly BankResolveUnpaidInvoicesWorker _bankResolveUnpaidTask;
        private readonly ProcessInvoicesWorker _workerProcessInvoices;
        private readonly SyncInvoicesWorker _workerInvoices;

        public ConsoleApplication(
            SyncBankAccountWorker workerSyncBankAccount,
            SyncSettingsWorker workerSyncSettings,
            SyncInvoicesWorker workerInvoices,
            SyncPayedInvoicesWorker workerSyncPayedInvoices,
            BankResolveUnpaidInvoicesWorker bankResolveUnpaidTask,
            ProcessInvoicesWorker workerProcessInvoices)
        {
            _workerSyncBankAccount = workerSyncBankAccount;
            _workerSyncSettings = workerSyncSettings;
            _workerSyncPayedInvoices = workerSyncPayedInvoices;
            _bankResolveUnpaidTask = bankResolveUnpaidTask;
            _workerProcessInvoices = workerProcessInvoices;
            _workerInvoices = workerInvoices;
        }
        private readonly object _locker=new object();
        //запускная ф-я приложение
        public void RunApplication()
        {
            Console.WriteLine("Banking System Service");

            CancellationTokenSource cancelTokenSource = new CancellationTokenSource();

            try
            {
                _workerSyncBankAccount.Run(cancelTokenSource.Token, _locker);
                
                //_workerSyncSettings.Run(cancelTokenSource.Token, _locker);

                //_workerInvoices.Run(cancelTokenSource.Token, _locker);

                //_bankResolveUnpaidTask.Run(cancelTokenSource.Token, _locker);

                //_workerSyncPayedInvoices.Run(cancelTokenSource.Token, _locker);

                //_workerProcessInvoices.Run(cancelTokenSource.Token, _locker);
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }

            //по esc всё нужно остановить
            if (Console.ReadKey().Key == ConsoleKey.Escape)
            {
                cancelTokenSource.Cancel();
            }

            Console.WriteLine("End of work detected. Press any key to exit");
            Console.ReadLine();

        }
    }
}
