﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using BankSystem.Business;
using Blockchain.Business;
using Common;

namespace BankSystem.BankingService.Tasks
{
    
    public class SyncBankAccountWorker : AbstractSyncWorker
    {
        private readonly UserAccountOperations _uaops;
        private readonly BankingContractOperations _bacops;


        public SyncBankAccountWorker(UserAccountOperations uaops, BankingContractOperations bacops)
        {
            _uaops = uaops;
            _bacops = bacops;
        }

        public override string TaskName => "syncBankAccountsTask";

        public override async Task SyncFunction(object locker)
        {
            lock (locker)
            {
                var accounts = _uaops.GetListWithLinkedSensors();

                foreach (var a in accounts)
                {
                    try
                    {
                        var res = _bacops.GetBankAccount((uint)a.UserAccountId).Result;

                        if(a.IsAutoPayAllowed && a.AutoPaySensorId==res.AutoPaySensorId && a.UserAccountId==res.UserAccountId)
                            continue;

                        Console.WriteLine(
                            $"syncBankAccountsTask: process account: {a.AccountId}, uaid={a.UserId}, linked sensor={a.AutoPaySensorId}");

                        var tx = _bacops.InsertBankAccount((uint) a.UserAccountId, a.AutoPaySensorId).Result;

                        Console.WriteLine($"syncBankAccountsTask: tx: {tx.TransactionHash}");

                        
                    }
                    catch (Exception ex)
                    {
                        Console.WriteLine($"{TaskName}: {ex}");
                    }
                }
            }

            await Task.CompletedTask;
        }
    }
}
