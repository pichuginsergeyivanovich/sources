﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using BankSystem.Business;
using Blockchain.Business;
using Common;

namespace BankSystem.BankingService.Tasks
{
    
    public class SyncPayedInvoicesWorker : AbstractSyncWorker
    {
        private readonly UserAccountOperations _uaops;
        private readonly InvoiceContractOperation _icops;
        private readonly InvoiceOperations _iops;


        public SyncPayedInvoicesWorker(UserAccountOperations uaops, InvoiceContractOperation icops, InvoiceOperations iops)
        {
            _uaops = uaops;
            _icops = icops;
            _iops = iops;
        }

        public override string TaskName => "syncPayedInvoicesTask";

        public override async Task SyncFunction(object locker)
        {
            var paidInvoices = _iops.GetByTypeAndStatus(3, 1);

            foreach (var inv in paidInvoices)
            {
                try
                {
                    lock (locker)
                    {
                        if (inv == null)
                            continue;

                        var userAccount = _uaops.GetOneByAccountId(inv.AccountId);

                        if (userAccount == null)
                            continue;

                        var bcinv =  _icops.GetInvoice((uint) userAccount.UserAccountId, (short) inv.Year,
                            (byte) inv.Month, 3).Result;

                        var tx = _icops.CompleteInvoice((uint) userAccount.UserAccountId, (short) inv.Year,
                            (byte) inv.Month, inv.TransactionId).Result;

                        bcinv = _icops.GetInvoice((uint) userAccount.UserAccountId, (short) inv.Year,
                            (byte) inv.Month, 3).Result;

                        Console.WriteLine($"{TaskName}: complete invoice {inv.InvoiceId} in blockchain. tx:{tx}");
                    }

                    await Task.CompletedTask;
                }
                catch (Exception ex)
                {
                    Console.WriteLine($"{TaskName}: {ex}");
                }
            }

        }
    }
}
