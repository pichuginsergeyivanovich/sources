﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using BankSystem.Business;
using Blockchain.Business;
using Common;

namespace BankSystem.BankingService.Tasks
{

    public class ProcessInvoicesWorker : AbstractSyncWorker
    {
        private readonly UserAccountOperations _uaops;
        private readonly InvoiceContractOperation _icops;
        
        public ProcessInvoicesWorker(UserAccountOperations uaops, InvoiceContractOperation icops)
        {
            _uaops = uaops;
            _icops = icops;
        }

        public override string TaskName => "processInvoicesTask";

        public override async Task SyncFunction(object locker)
        {
            var accounts = _uaops.GetListWithLinkedSensors();

            foreach (var a in accounts)
            {
                lock (locker)
                {
                    try
                    {
                        Console.WriteLine($"{TaskName}: process invoices");

                        var txp = _icops.ProcessInvoices(a.UserAccountId, DateTime.Now).Result;

                        Console.WriteLine($"{TaskName}: {txp.TransactionHash}");
                    }
                    catch (Exception ex)
                    {
                        Console.WriteLine($"{TaskName}: {ex}");
                    }
                }
                await Task.CompletedTask;
            }
        }
    }
}
