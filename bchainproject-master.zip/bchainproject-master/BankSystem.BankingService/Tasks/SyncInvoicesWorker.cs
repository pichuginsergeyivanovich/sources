﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using BankSystem.Business;
using Blockchain.Business;
using Common;

namespace BankSystem.BankingService.Tasks
{
    
    public class SyncInvoicesWorker : AbstractSyncWorker
    {
        private readonly UserAccountOperations _uaops;
        private readonly InvoiceContractOperation _icops;
        private readonly InvoiceOperations _iops;
        private readonly IContractConnectionProvider _ccp;


        public SyncInvoicesWorker(UserAccountOperations uaops, 
            InvoiceContractOperation icops, 
            InvoiceOperations iops, 
            IContractConnectionProvider ccp)
        {
            _uaops = uaops;
            _icops = icops;
            _iops = iops;
            _ccp = ccp;
        }

        public override string TaskName => "syncInvoicesTask";

        public override async Task SyncFunction(object locker)
        {
            var accounts = _uaops.GetListWithLinkedSensors();

            foreach (var a in accounts)
            {
                lock (locker)
                {
                    //current month
                    Console.WriteLine($"{TaskName}: ---------------------------------------");
                    Console.WriteLine($"{TaskName}: current month bill info({DateTime.Now})");

                    for (byte i = 1; i <= 3; i++)
                    {
                        InvoiceContractOperation.GetInvoiceOutput info = null;
                        try
                        {
                            Console.WriteLine($"{TaskName}: looking for invoice type{i}");

                            info = _icops.GetInvoice((uint) a.UserAccountId, (short) DateTime.Now.Year,
                                (byte) DateTime.Now.Month, i).Result;

                            if (info._Created > 0)
                                Console.WriteLine($"{TaskName}: invoice is ready\r\n {info}");
                        }
                        catch (Exception ex)
                        {
                            Console.WriteLine($"{TaskName}: {ex}");
                        }

                        if (info == null || info?._Created == 0)
                        {
                            Console.WriteLine($"{TaskName}: no invoices of type {i}\r\n {info}");
                            continue;
                        }


                        try
                        {
                            if (info._Created > 0)
                            {
                                _iops.AddOrUpdateInvoice(
                                    a.UserAccountId,
                                    (decimal) info.TotalMonthCosts / (decimal) 1000.0,
                                    "smart contract",
                                    _ccp.Address,
                                    info._Created.FromUnixTime(),
                                    i,
                                    (short) DateTime.Now.Year,
                                    (byte) DateTime.Now.Month);

                                Console.WriteLine($"{TaskName}: invoice synced.");
                            }
                        }
                        catch (Exception ex)
                        {
                            Console.WriteLine($"{TaskName}: {ex}");
                        }
                    }
                    //prev month close
                    DateTime pbd = DateTime.Now.AddMonths(-1);
                    Console.WriteLine($"{TaskName}: ---------------------------------------");
                    Console.WriteLine($"{TaskName}: prev month close info({pbd})");
                    byte prev_i = 3;
                    
                    
                    {
                        InvoiceContractOperation.GetInvoiceOutput info = null;
                        try
                        {
                            Console.WriteLine($"{TaskName}: looking for invoice type{prev_i}");

                            info = _icops.GetInvoice((uint)a.UserAccountId, (short)pbd.Year, (byte)pbd.Month, prev_i).Result;

                            if (info._Created > 0)
                                Console.WriteLine($"{TaskName}: invoice is ready\r\n {info}");
                        }
                        catch (Exception ex)
                        {
                            Console.WriteLine($"{TaskName}: {ex}");
                        }

                        if (info == null || info?._Created == 0)
                        {
                            Console.WriteLine($"{TaskName}: no invoices of type {prev_i}\r\n {info}");
                            continue;
                        }
                        try
                        {
                            if (info._Created > 0)
                            {
                                _iops.AddOrUpdateInvoice(
                                    a.UserAccountId,
                                    (decimal)info.TotalMonthCosts / (decimal)1000.0,
                                    "smart contract",
                                    _ccp.Address,
                                    info._Created.FromUnixTime(),
                                    prev_i,
                                    (short)pbd.Year,
                                    (byte)pbd.Month);

                                Console.WriteLine($"{TaskName}: invoice synced.");
                            }
                        }
                        catch (Exception ex)
                        {
                            Console.WriteLine($"{TaskName}: {ex}");
                        }
                    }
                }
            }

            await Task.CompletedTask;
        }
    }
}
