﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using BankSystem.Business;
using Blockchain.Business;
using Common;

namespace BankSystem.BankingService.Tasks
{
    
    public class BankResolveUnpaidInvoicesWorker : AbstractSyncWorker
    {
        private readonly InvoiceOperations _iops;


        public BankResolveUnpaidInvoicesWorker(InvoiceOperations iops)
        {
            _iops = iops;
        }

        public override string TaskName => "BankResolveUnpaidInvoicesTask";

        public override async Task SyncFunction(object locker)
        {
            var unpaidFactedInvoices = _iops.GetByTypeAndStatus(3, 0);

            foreach (var inv in unpaidFactedInvoices)
            {
                try
                {
                    var txId = Guid.NewGuid();

                    _iops.PayInvoice(inv.InvoiceId, txId);

                    Console.WriteLine($"{TaskName}: invoice {inv.InvoiceId} resolved");

                }
                catch (Exception ex)
                {
                    Console.WriteLine($"{TaskName}: Error resolve invoice {inv.InvoiceId}. {ex}");
                }
            }

            await Task.CompletedTask;
        }


    }
}
