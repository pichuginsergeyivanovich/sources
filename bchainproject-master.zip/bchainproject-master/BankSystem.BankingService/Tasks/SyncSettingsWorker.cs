﻿using System;
using System.Collections.Generic;
using System.Reflection.Metadata.Ecma335;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using BankSystem.Business;
using Blockchain.Business;
using Common;

namespace BankSystem.BankingService.Tasks
{
    public class SyncSettingsWorker: AbstractSyncWorker
    {
        private readonly SettingsContractOperations _secops;
        private readonly SettingsOperations _seops;

        public SyncSettingsWorker(SettingsContractOperations secops, SettingsOperations seops)
        {
            _secops = secops;
            _seops = seops;
        }
        public override string TaskName => "syncSettingsTask";

        public override async Task SyncFunction(object locker)
        {
            try
            {
                lock (locker)
                {
                    var dbSettings = _seops.Get();

                if (!dbSettings.InvoiceFinalDate.HasValue || !dbSettings.InvoicePreview1Date.HasValue ||
                    !dbSettings.InvoicePreview2Date.HasValue)
                {
                    Console.WriteLine($"{TaskName}: Error.Settings not set or incomplete.");
                    return;

                }


                var s = _secops.GetSettings().Result;

                if (s.FinalInvoiceDate.Date == dbSettings.InvoiceFinalDate.Value.Date &&
                    s.Pre1InvoiceDate.Date == dbSettings.InvoicePreview1Date.Value.Date &&
                    s.Pre2InvoiceDate.Date == dbSettings.InvoicePreview2Date.Value.Date)
                {
                }
                else
                {

                        var tx_s = _secops.SetSettings(dbSettings.InvoiceFinalDate.Value,
                            dbSettings.InvoicePreview1Date.Value, dbSettings.InvoicePreview2Date.Value).Result;

                        //считываем для проверки
                        var s1 = _secops.GetSettings().Result;

                        Console.WriteLine(
                            $"{TaskName}: {s1.FinalInvoiceDate}, {s1.Pre1InvoiceDate}, {s1.Pre2InvoiceDate}");

                    }

                }

                await Task.CompletedTask;
            }
            catch (Exception ex)
            {
                Console.WriteLine($"{TaskName}: {ex}");
            }
        }









    }
}
