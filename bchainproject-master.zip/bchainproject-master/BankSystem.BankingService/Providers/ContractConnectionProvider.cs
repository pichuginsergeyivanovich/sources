﻿using Common;
using Microsoft.Extensions.Configuration;

namespace BankSystem.BankingService.Providers
{
    public class ContractConnectionProvider : IContractConnectionProvider
    {
        public ContractConnectionProvider(IConfiguration config)
        {
            Url = config.GetSection("Contract")["Url"];

            Address = config.GetSection("Contract")["Address"];

            PrivateKey = config.GetSection("Contract")["PrivateKey"];
        }

        public string Url { get; }

        public string Address { get; }

        public string PrivateKey { get; }
    }
}
