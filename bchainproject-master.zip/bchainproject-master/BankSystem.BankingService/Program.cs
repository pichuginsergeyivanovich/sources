﻿using Contracts;
using System;
using System.IO;
using System.Threading;
using System.Threading.Tasks;
using BankSystem.BankingService.Providers;
using BankSystem.Business;
using Blockchain.Business;
using Common;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using BankSystem.BankingService.Tasks;
using Microsoft.Extensions.DependencyInjection.Extensions;

namespace BankSystem.BankingService
{

   public  class Program
    {
        private static IServiceCollection ConfigureServices()
        {
	    //создаём и настраиваем контейнер зависимостей
            IServiceCollection services = new ServiceCollection();
            
            var config = LoadConfiguration();
            
            services.AddSingleton(config);
            
            services.AddTransient<DapperBankSystemConnectionStringProvider>();

            services.AddTransient<DapperEnergyServicesConnectionStringProvider>();

            services.AddTransient<DapperUsersConnectionStringProvider>();

            //services.AddSingleton<IDapperConnectionStringProvider, DapperBankSystemConnectionStringProvider>();

            services.AddTransient<UserAccountOperations>((s)=>new UserAccountOperations(s.GetService<DapperBankSystemConnectionStringProvider>()));

            services.AddTransient<InvoiceOperations>((s) => new InvoiceOperations(s.GetService<DapperBankSystemConnectionStringProvider>()));

            services.AddTransient<TransactionOperations>((s) => new TransactionOperations(s.GetService<DapperBankSystemConnectionStringProvider>()));

            services.AddTransient<SettingsOperations>((s) => new SettingsOperations(s.GetService<DapperBankSystemConnectionStringProvider>()));

            services.AddTransient<IContractConnectionProvider,ContractConnectionProvider>();

            services.AddTransient<TariffContractOperation>();

            services.AddTransient<SensorContractOperations>();

            services.AddTransient<BillingContractOperations>();

            services.AddTransient<BankingContractOperations>();

            services.AddTransient<InvoiceContractOperation>();

            services.AddTransient<SettingsContractOperations>();

            services.AddTransient<ContractOperations>();

            services.AddTransient<SyncBankAccountWorker>();

            services.AddTransient<SyncSettingsWorker>();

            services.AddTransient<SyncInvoicesWorker>();

            services.AddTransient<BankResolveUnpaidInvoicesWorker>();

            services.AddTransient<SyncPayedInvoicesWorker>();

            services.AddTransient<ProcessInvoicesWorker>();

            services.AddTransient<ConsoleApplication>();

            return services;
        }


        public static IConfiguration LoadConfiguration()
        {
            var builder = new ConfigurationBuilder()
                .SetBasePath(Directory.GetCurrentDirectory())
                .AddJsonFile("appconfig.json", optional: true,
                    reloadOnChange: true);
            return builder.Build();
        }
        static void Main(string[] args)
        {
            var services = ConfigureServices().BuildServiceProvider();

	    //получаем из контейнера наше приложение и запускаем его
            var app = services.GetService<ConsoleApplication>();

            app.RunApplication();

        }
    }
}
