﻿using System;
using System.Collections.Generic;
using System.Text;

namespace BankSystem.Data
{
    public class InvoiceText
    {
        public byte Id { get; set; }
        public string Text { get; set; }
    }
}
