﻿using System;
using System.Collections.Generic;
using System.Text;

namespace BankSystem.Data
{
    public class Settings
    {
        public DateTime? InvoicePreview1Date { get; set; }
        public DateTime? InvoicePreview2Date { get; set; }
        public DateTime? InvoiceFinalDate { get; set; }
    }
}
