﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Contracts
{
    public class Account
    {
        public string Address { get; set; }
        public string PrivateKey { get; set; }
    }
}
