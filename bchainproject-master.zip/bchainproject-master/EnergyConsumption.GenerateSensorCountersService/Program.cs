﻿using Contracts;
using EnergyConsumption.Business;
using System;
using System.IO;
using System.Numerics;
using System.Threading;
using System.Threading.Tasks;
using EnergyConsumption.GenerateSensorCountersService.Providers;
using Blockchain.Business;
using Common;
using EnergyConsumption.GenerateSensorCountersService.Task;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;

namespace EnergyConsumption.GenerateSensorCountersService
{
    class Program
    {
        private static IServiceCollection ConfigureServices()
        {
            IServiceCollection services = new ServiceCollection();

            var config = LoadConfiguration();

            services.AddSingleton(config);

            services.AddTransient<DapperBankSystemConnectionStringProvider>();

            services.AddTransient<DapperEnergyServicesConnectionStringProvider>();

            services.AddTransient<DapperUsersConnectionStringProvider>();

            //services.AddSingleton<IDapperConnectionStringProvider, DapperBankSystemConnectionStringProvider>();

            services.AddTransient<UserSensorOperations>((s) => new UserSensorOperations(s.GetService<DapperEnergyServicesConnectionStringProvider>()));

            services.AddTransient<SensorDataOperations>((s) => new SensorDataOperations(s.GetService<DapperEnergyServicesConnectionStringProvider>()));

            services.AddTransient<TariffOperations>((s) => new TariffOperations(s.GetService<DapperEnergyServicesConnectionStringProvider>()));

            services.AddTransient<IContractConnectionProvider, ContractConnectionProvider>();

            services.AddTransient<ITariffZonesJsonProvider,TariffZonesJsonProvider>();

            services.AddTransient<JsonTariffOperations>();

            services.AddTransient<BillingDataOperations>((s) => new BillingDataOperations(s.GetService<DapperEnergyServicesConnectionStringProvider>()));

            services.AddTransient<TariffContractOperation>();

            services.AddTransient<SensorContractOperations>();

            services.AddTransient<BillingContractOperations>();

            services.AddTransient<BankingContractOperations>();

            services.AddTransient<InvoiceContractOperation>();

            services.AddTransient<SettingsContractOperations>();

            services.AddTransient<ContractOperations>();

            services.AddTransient<ConsoleApplication>();

            services.AddTransient<EnergyConsumptionTaskWorker>();

            services.AddTransient<SyncTariffZonesWorker>();

            services.AddTransient<SyncSensorDataWorker>();

            services.AddTransient<SyncBillingDataWorker>();

            return services;
        }


        public static IConfiguration LoadConfiguration()
        {
            var builder = new ConfigurationBuilder()
                .SetBasePath(Directory.GetCurrentDirectory())
                .AddJsonFile("appconfig.json", optional: true, reloadOnChange: true)
                ; 
            return builder.Build();
        }

        
        static void Main(string[] args)
        {

            var services = ConfigureServices().BuildServiceProvider();

            var app = services.GetService<ConsoleApplication>();

            app.RunApplication();


        }
    }
}
