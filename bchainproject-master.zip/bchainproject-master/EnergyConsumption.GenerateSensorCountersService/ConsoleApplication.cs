﻿using System;
using System.Threading;
using EnergyConsumption.GenerateSensorCountersService.Task;

namespace EnergyConsumption.GenerateSensorCountersService
{
    public class ConsoleApplication
    {
        private readonly EnergyConsumptionTaskWorker _workerEnergyConsumption;
        private readonly SyncTariffZonesWorker _workerSyncTariffZones;
        private readonly SyncSensorDataWorker _workerSyncSensorData;
        private readonly SyncBillingDataWorker _workerSyncBilling;

        public ConsoleApplication(
            EnergyConsumptionTaskWorker workerEnergyConsumption,
            SyncTariffZonesWorker workerSyncTariffZones,
            SyncSensorDataWorker workerSyncSensorData,
            SyncBillingDataWorker workerSyncBilling
            )
        {
            _workerEnergyConsumption = workerEnergyConsumption;
            _workerSyncTariffZones = workerSyncTariffZones;
            _workerSyncSensorData = workerSyncSensorData;
            _workerSyncBilling = workerSyncBilling;
        }
        private readonly object _locker = new object();
        public void RunApplication()
        {
            CancellationTokenSource cancelTokenSource = new CancellationTokenSource();

            try
            {
                _workerEnergyConsumption.Run(cancelTokenSource.Token, _locker);

                _workerSyncTariffZones.Run(cancelTokenSource.Token, _locker);

                _workerSyncSensorData.Run(cancelTokenSource.Token, _locker);

                _workerSyncBilling.Run(cancelTokenSource.Token, _locker);
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }



            if (Console.ReadKey().Key == ConsoleKey.Escape)
            {
                cancelTokenSource.Cancel();
            }

            Console.WriteLine("End of work detected. Press any key to exit");

            Console.ReadLine();
        }
    }
}
