﻿using System;
using Blockchain.Business;
using Common;
using EnergyConsumption.Business;
using EnergyConsumption.GenerateSensorCountersService.Providers;

namespace EnergyConsumption.GenerateSensorCountersService.Task
{
    public class SyncBillingDataWorker : AbstractSyncWorker
    {
        private readonly UserSensorOperations _usops;
        private readonly BillingContractOperations _bicops;
        private readonly BillingDataOperations _biops;

        public SyncBillingDataWorker(UserSensorOperations usops, BillingContractOperations bicops, BillingDataOperations biops)
        {
            _usops = usops;
            _bicops = bicops;
            _biops = biops;
        }
        public override string TaskName => "syncBillingDataTask";

        public override async System.Threading.Tasks.Task SyncFunction(object locker)
        {
            try
            {
                var sensors = _usops.GetList();

                foreach (var s in sensors)
                {
                    try
                    {
                        lock (locker)
                        {
                            var g = s.SensorId;

                            var tx = _bicops.ProcessBilling(g).Result;


                            Console.WriteLine($"{TaskName}: sensor {g}: processed, tx: {tx.TransactionHash}");

                            var billing = _bicops.GetBillingData(g, DateTime.Now).Result;

                            Console.WriteLine($"{TaskName}: sensor {g}: data: {billing}");
                        }
                    }
                    catch (Exception ex)
                    {
                        Console.WriteLine($"{TaskName}: {ex}");
                    }


                    //sync billing data from b/c into energy consumption db
                    try
                    {
                        lock (locker)
                        {
                            for (var dm = 0; dm < 12; dm++)
                            {
                                var d = DateTime.Now.AddMonths(-dm);

                                Console.WriteLine($"{TaskName}: import billing stats on {d}");

                                var billing = _bicops.GetBillingData(s.SensorId, d).Result;

                                var isEmptyBilling = billing.TotalMonthAmount == 0 && billing.EstimatedMonthAmount == 0;

                                if (isEmptyBilling)
                                    continue;


                                _biops.AddOrUpdate(s.SensorId, (short)d.Year, (byte)d.Month, 
                                    (long)billing.TotalMonthAmount,
                                    (decimal)billing.TotalMonthCosts/(decimal)1000.0,
                                    (long)billing.EstimatedMonthAmount, 
                                    (decimal)billing.EstimatedMonthCosts / (decimal)1000.0);
                            }
                        }
                    }
                    catch (Exception ex)
                    {
                        Console.WriteLine($"{TaskName}: {ex}");
                    }
                }

                await System.Threading.Tasks.Task.CompletedTask;
            }
            catch (Exception ex)
            {
                Console.WriteLine($"{TaskName}: {ex}");
            }
        }
    }
}
