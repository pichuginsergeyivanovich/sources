﻿using System;
using System.Threading;
using Blockchain.Business;
using Common;
using EnergyConsumption.Business;

namespace EnergyConsumption.GenerateSensorCountersService.Task
{
    public class SyncTariffZonesWorker : AbstractSyncWorker
    {
        private readonly TariffOperations _tzops;
        private readonly JsonTariffOperations _jtzops;
        private readonly TariffContractOperation _tcops;

        public SyncTariffZonesWorker(TariffOperations tzops,JsonTariffOperations jtzops, TariffContractOperation tcops)
        {
            _tzops = tzops;
            _jtzops = jtzops;
            _tcops = tcops;
        }

        public override string TaskName => "syncTariffZonesTask";

        public override async System.Threading.Tasks.Task SyncFunction(object locker)
        {
            try
            {
                var bcTariffChkSum = await _tcops.GetTariffZonesChkSum();

                var dbTariffChkSum = _jtzops.GetTariffZoneCheckSum();
                
                if(bcTariffChkSum != dbTariffChkSum)
                {
                    Console.WriteLine($"{TaskName}: changes detected, need to sync");

                    var tariffs = _jtzops.GetList();

                    foreach (var t in tariffs)
                    {
                        lock (locker)
                        {

                            try
                            {
                                var tx =  _tcops.LoadTariffZone(t.ZoneId, t.RatePer1000).Result;

                                Console.WriteLine($"{TaskName}: sync to b/c(tx: {tx.TransactionHash})");
                            }
                            catch (Exception ex)
                            {
                                Console.WriteLine($"{TaskName}: {ex}");
                            }

                            try
                            {
                                Console.WriteLine($"{TaskName}: sync to db");

                                _tzops.AddTariffZoneIfNotExist(t.ZoneId, t.RatePer1000);
                            }
                            catch (Exception ex)
                            {
                                Console.WriteLine($"{TaskName}: {ex}");
                            }
                        }
                    }

                    try
                    {
                        lock (locker)
                        {
                            var res1 = _tcops.SetTariffZoneChkSum(dbTariffChkSum).Result;

                            Console.WriteLine($"{TaskName}: write chksum, tx: {res1.TransactionHash}");
                        }
                    }
                    catch (Exception ex)
                    {
                        Console.WriteLine($"{TaskName}: {ex}");
                    }
                }
                else Console.WriteLine($"{TaskName}: no changes in tariffs");
            }
            catch (Exception ex)
            {
                Console.WriteLine($"{TaskName}: {ex}");
            }
        }
    }
}
