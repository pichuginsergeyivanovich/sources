﻿using System;
using Common;
using EnergyConsumption.Business;

namespace EnergyConsumption.GenerateSensorCountersService.Task
{
    public class EnergyConsumptionTaskWorker : AbstractSyncWorker
    {
        private readonly UserSensorOperations _usops;

        public EnergyConsumptionTaskWorker(UserSensorOperations usops)
        {
            _usops = usops;
        }
        public override string TaskName => "energyConsumptionTask";

        public override async System.Threading.Tasks.Task SyncFunction(object locker)
        {
            try
            {
                _usops.GeneratePowerConsumptionCycle();

                await System.Threading.Tasks.Task.CompletedTask;
            }
            catch (Exception ex)
            {
                Console.WriteLine($"{TaskName}: {ex}");
            }
        }
    }
}
