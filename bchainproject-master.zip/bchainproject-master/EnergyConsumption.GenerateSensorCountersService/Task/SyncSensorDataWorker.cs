﻿using System;
using Blockchain.Business;
using Common;
using EnergyConsumption.Business;

namespace EnergyConsumption.GenerateSensorCountersService.Task
{
    public class SyncSensorDataWorker : AbstractSyncWorker
    {
        private readonly UserSensorOperations _usops;
        private readonly SensorContractOperations _scops;

        public SyncSensorDataWorker(UserSensorOperations usops, SensorContractOperations scops)
        {
            _usops = usops;
            _scops = scops;
        }
        public override string TaskName => "syncSensorDataTask";

        public override async System.Threading.Tasks.Task SyncFunction(object locker)
        {
            try
            {
                var sensors = _usops.GetList();

                foreach (var s in sensors)
                {
                    try
                    {
                        lock (locker)
                        {
                            var lastCounters = _usops.GetLastCounters(s.SensorId);

                            var tx =  _scops.AddData(s.SensorId, lastCounters.ZoneId, lastCounters.Value,
                                lastCounters.Created).Result;


                            var len = _scops.GetDataLength(s.SensorId, (short) lastCounters.Created.Year,
                                (byte) lastCounters.Created.Month).Result;

                            Console.WriteLine($"SensorData inserted");
                            Console.WriteLine($"Sensor {s.SensorId} data:");

                            for (var i = 0; i < len; i++)
                            {
                                var data = _scops.GetData(s.SensorId, (short) lastCounters.Created.Year,
                                    (byte) lastCounters.Created.Month, i).Result;

                                Console.WriteLine($"{data}");
                            }
                        }
                    }
                    catch (Exception ex)
                    {
                        Console.WriteLine($"{TaskName}: {ex}");
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"{TaskName}: {ex}");
            }
        }
    }
}
