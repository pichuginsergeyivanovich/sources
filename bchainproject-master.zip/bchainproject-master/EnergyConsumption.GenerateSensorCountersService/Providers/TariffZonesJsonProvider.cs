﻿using Common;
using Microsoft.Extensions.Configuration;

namespace EnergyConsumption.GenerateSensorCountersService.Providers
{
    public class TariffZonesJsonProvider : ITariffZonesJsonProvider
    {
        public TariffZonesJsonProvider(IConfiguration config)
        {
            Filename = config.GetSection("TariffZonesFileName").Value;
        }

        public string Filename { get; }

    }
}
