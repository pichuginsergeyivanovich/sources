﻿using Common;
using Microsoft.Extensions.Configuration;

namespace EnergyConsumption.GenerateSensorCountersService.Providers
{
    public class DapperUsersConnectionStringProvider : IDapperConnectionStringProvider
    {
        public DapperUsersConnectionStringProvider(IConfiguration config)
        {
            ConnectionString = config.GetConnectionString("DefaultConnection");
        }
        public string ConnectionString { get; }
    }
}
