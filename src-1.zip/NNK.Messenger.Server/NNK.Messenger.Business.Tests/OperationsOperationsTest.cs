﻿using System;
using System.Linq;
using System.Text;
using System.Transactions;
using Dapper;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using NNK.Messenger.Core;
using NNK.Messenger.Data;

namespace NNK.Messenger.Business.Tests
{
    [TestClass]
    public class OperationsOperationsTest
    {
        public class DapperConnectionStringProvider : IDapperConnectionStringProvider
        {
            public string ConnectionString => "Data Source = 10.1.41.60; Initial Catalog = NNK.Messenger.Test; Integrated Security = False; User Id=test; Password=test; ";
        }

        [TestMethod]
        public void Add_Success()
        {
            var dp = new DapperConnectionStringProvider();

            var oo = new Dapper.OperationsOperations(dp);

            var id = "register";

            var method = "sms";

            var data= "{\"login\":\"testlogin777\",\"password\":\"testlogin777password\",\"confirm_password\":\"testlogin777password\",\"phone\":\"79168888888\"}";

            Guid? testId = null;

            using (TransactionScope scope = new TransactionScope())
            {
                var oo1 = new Dapper.OperationsOperations(dp);

                var test = oo1.Add(id, method, Convert.ToBase64String(Encoding.UTF8.GetBytes(data)));

                Assert.IsNotNull(test);

                Assert.IsNotNull(test.ID);

                testId = test.ID;

                Assert.AreEqual(test.Name, id);

                Assert.AreEqual(test.Method, method);

            }

            var test0 = oo.ExecuteQuery(db => db.Query<Operation>("select * from dbo.Operation(nolock) where ID=@ID", new { ID = testId })?.FirstOrDefault());

            Assert.IsNull(test0);

        }

        [TestMethod]
        public void Confirm_Success()
        {
            var dp = new DapperConnectionStringProvider();

            var oo = new Dapper.OperationsOperations(dp);

            var id = "register";

            var method = "sms";

            var data = "{\"login\":\"testlogin777\",\"password\":\"testlogin777password\",\"confirm_password\":\"testlogin777password\",\"phone\":\"79168888888\"}";

            Guid? testId = null;

            using (TransactionScope scope = new TransactionScope())
            {
                var oo1 = new Dapper.OperationsOperations(dp);

                var test = oo1.Add(id, method, Convert.ToBase64String(Encoding.UTF8.GetBytes(data)));

                Assert.IsNotNull(test);

                Assert.IsNotNull(test.ID);

                testId = test.ID;

                Assert.AreEqual(test.Name, id);

                Assert.AreEqual(test.Method, method);

                oo1.Execute(db => db.Execute("exec sp_gen_code"));

                var genc= oo1.GetById(testId.Value);

                Assert.IsNotNull(genc);

                Assert.IsNotNull(genc.GenCode);

                var testc = oo1.Confirm(testId.ToString(), genc.GenCode);

                Assert.IsNotNull(testc);

                Assert.AreEqual(testc.ConfirmCode, genc.GenCode);

                Assert.IsNotNull(testc.ConfirmCodeCreated);

                Assert.AreEqual(testc.ConfirmCodeCreated.Value.Date, DateTime.Now.Date);
            }

            var test0 = oo.ExecuteQuery(db => db.Query<Operation>("select * from dbo.Operation(nolock) where ID=@ID", new { ID = testId })?.FirstOrDefault());

            Assert.IsNull(test0);

        }

        [TestMethod]
        public void OperationProcessedCreated_Success()
        {
            var dp = new DapperConnectionStringProvider();

            var oo = new Dapper.OperationsOperations(dp);

            var id = "register";

            var method = "sms";

            var data = "{\"login\":\"testlogin777\",\"password\":\"testlogin777password\",\"confirm_password\":\"testlogin777password\",\"phone\":\"79168888888\"}";

            Guid? testId = null;

            using (TransactionScope scope = new TransactionScope())
            {
                var oo1 = new Dapper.OperationsOperations(dp);

                var test = oo1.Add(id, method, Convert.ToBase64String(Encoding.UTF8.GetBytes(data)));

                Assert.IsNotNull(test);

                Assert.IsNotNull(test.ID);

                testId = test.ID;

                Assert.AreEqual(test.Name, id);

                Assert.AreEqual(test.Method, method);

                oo1.OperationProcessedCreated(testId);

                var res = oo1.GetById(testId.Value);

                Assert.IsNotNull(res);

                Assert.IsNotNull(res.OperationProcessedCreated);

                Assert.AreEqual(res.OperationProcessedCreated.Value.Date, DateTime.Now.Date);

            }

            var test0 = oo.ExecuteQuery(db => db.Query<Operation>("select * from dbo.Operation(nolock) where ID=@ID", new { ID = testId })?.FirstOrDefault());

            Assert.IsNull(test0);
        }

        [TestMethod]
        public void GetConfirmSecretCode_Success()
        {
            var dp = new DapperConnectionStringProvider();

            var oo = new Dapper.OperationsOperations(dp);

            var id = "register";

            var method = "sms";

            var data = "{\"login\":\"testlogin777\",\"password\":\"testlogin777password\",\"confirm_password\":\"testlogin777password\",\"phone\":\"79168888888\"}";

            Guid? testId = null;

            using (TransactionScope scope = new TransactionScope())
            {
                var oo1 = new Dapper.OperationsOperations(dp);

                var test = oo1.Add(id, method, Convert.ToBase64String(Encoding.UTF8.GetBytes(data)));

                Assert.IsNotNull(test);

                Assert.IsNotNull(test.ID);

                testId = test.ID;

                Assert.AreEqual(test.Name, id);

                Assert.AreEqual(test.Method, method);

                oo1.Execute(db => db.Execute("exec sp_gen_code"));

                var genc = oo1.GetById(testId.Value);

                Assert.IsNotNull(genc);

                Assert.IsNotNull(genc.GenCode);

                int val;

                Assert.IsTrue(int.TryParse(genc.GenCode,out val));
            }

            var test0 = oo.ExecuteQuery(db => db.Query<Operation>("select * from dbo.Operation(nolock) where ID=@ID", new { ID = testId })?.FirstOrDefault());

            Assert.IsNull(test0);

        }

        [TestMethod]
        public void GetById_Success()
        {
            var dp = new DapperConnectionStringProvider();

            var oo = new Dapper.OperationsOperations(dp);

            var id = "register";

            var method = "sms";

            var data = "{\"login\":\"testlogin777\",\"password\":\"testlogin777password\",\"confirm_password\":\"testlogin777password\",\"phone\":\"79168888888\"}";

            Guid? testId = null;

            using (TransactionScope scope = new TransactionScope())
            {
                var oo1 = new Dapper.OperationsOperations(dp);

                var test = oo1.Add(id, method, Convert.ToBase64String(Encoding.UTF8.GetBytes(data)));

                Assert.IsNotNull(test);

                Assert.IsNotNull(test.ID);

                testId = test.ID;

                Assert.AreEqual(test.Name, id);

                Assert.AreEqual(test.Method, method);

                var genc = oo1.GetById(testId.Value);

                Assert.IsNotNull(genc);

            }

            var test0 = oo.ExecuteQuery(db => db.Query<Operation>("select * from dbo.Operation(nolock) where ID=@ID", new { ID = testId })?.FirstOrDefault());

            Assert.IsNull(test0);
        }

        [TestMethod]
        public void DeleteOperation_Success()
        {
            var dp = new DapperConnectionStringProvider();

            var oo = new Dapper.OperationsOperations(dp);

            var id = "register";

            var method = "sms";

            var data = "{\"login\":\"testlogin777\",\"password\":\"testlogin777password\",\"confirm_password\":\"testlogin777password\",\"phone\":\"79168888888\"}";

            Guid? testId = null;

            using (TransactionScope scope = new TransactionScope())
            {
                var oo1 = new Dapper.OperationsOperations(dp);

                var test = oo1.Add(id, method, Convert.ToBase64String(Encoding.UTF8.GetBytes(data)));

                Assert.IsNotNull(test);

                Assert.IsNotNull(test.ID);

                testId = test.ID;

                Assert.AreEqual(test.Name, id);

                Assert.AreEqual(test.Method, method);

                oo1.DeleteOperation(testId.Value);

                var testd = oo.ExecuteQuery(db => db.Query<Operation>("select * from dbo.Operation(nolock) where ID=@ID", new { ID = testId })?.FirstOrDefault());

                Assert.IsNull(testd);


            }

            var test0 = oo.ExecuteQuery(db => db.Query<Operation>("select * from dbo.Operation(nolock) where ID=@ID", new { ID = testId })?.FirstOrDefault());

            Assert.IsNull(test0);
        }


    }
}
