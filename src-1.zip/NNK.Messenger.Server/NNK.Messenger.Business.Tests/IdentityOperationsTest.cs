﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Transactions;
using Dapper;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using NNK.Messenger.Core;
using NNK.Messenger.Data;

namespace NNK.Messenger.Business.Tests
{
    [TestClass]
    public class IdentityOperationsTest
    {
        public class DapperConnectionStringProvider : IDapperConnectionStringProvider
        {
            public string ConnectionString => "Data Source = 10.1.41.60; Initial Catalog = NNK.Messenger.Test; Integrated Security = False; User Id=test; Password=test; ";
        }

        [TestMethod]
        public void Get_Success()
        {
            var dp = new DapperConnectionStringProvider();

            var idops = new Dapper.IdentityOperations(dp);

            var existingIId = idops.ExecuteQuery(db => db.Query<Identity>("select top 1 * from dbo.[Identity](nolock)"))?.FirstOrDefault();

            Assert.IsNotNull(existingIId);

            var test = idops.Get(existingIId.ObjectId);

            Assert.IsNotNull(test);

            Assert.AreEqual(test.ObjectId, existingIId.ObjectId);

            Assert.AreEqual(Convert.ToBase64String(test.IdentityKey), Convert.ToBase64String(existingIId.IdentityKey));

            Assert.AreEqual(test.CreateOn, existingIId.CreateOn);

        }

        [TestMethod]
        public void RegisterUserKeys_IsNew_Success()
        {
            var dp = new DapperConnectionStringProvider();

            var idops = new Dapper.IdentityOperations(dp);

            int uid = 9999;

            byte[] identityKey=new byte[] {1};

            byte[] signedPreKey = new byte[] { 1 };

            byte[] signedPreKeyHash = new byte[] { 1 };

            Queue<byte[]> oneTimeKeyQueue = null;

            using (TransactionScope scope = new TransactionScope())
            {
                var idops1 = new Dapper.IdentityOperations(dp);

                idops1.RegisterUserKeys(uid, identityKey, signedPreKey, signedPreKeyHash, oneTimeKeyQueue);

                var test = idops1.Get(uid);

                Assert.IsNotNull(test);

                Assert.IsTrue(test.IdentityKey.Length == 1);

                Assert.IsTrue(Convert.ToBase64String(test.IdentityKey) == Convert.ToBase64String(new byte[] {1}));
            }
            var test1 = idops.Get(uid);

            Assert.IsNull(test1);

        }
        [TestMethod]
        public void RegisterUserKeys_Existing_Success()
        {
            var dp = new DapperConnectionStringProvider();

            var idops = new Dapper.IdentityOperations(dp);

            int uid = 9999;

            byte[] identityKey = new byte[] { 1 };

            byte[] signedPreKey = new byte[] { 1 };

            byte[] signedPreKeyHash = new byte[] { 1 };

            Queue<byte[]> oneTimeKeyQueue = null;

            using (TransactionScope scope = new TransactionScope())
            {
                var idops1 = new Dapper.IdentityOperations(dp);

                idops1.RegisterUserKeys(uid, identityKey, signedPreKey, signedPreKeyHash, oneTimeKeyQueue);

                var test = idops1.Get(uid);

                Assert.IsNotNull(test);

                Assert.IsTrue(test.IdentityKey.Length == 1);

                Assert.IsTrue(Convert.ToBase64String(test.IdentityKey) == Convert.ToBase64String(new byte[] { 1 }));


                identityKey = new byte[] {2, 2};


                idops1.RegisterUserKeys(uid, identityKey, signedPreKey, signedPreKeyHash, oneTimeKeyQueue);

                var test2 = idops1.Get(uid);

                Assert.IsNotNull(test2);

                Assert.IsTrue(test2.IdentityKey.Length == 2);

                Assert.IsTrue(Convert.ToBase64String(test2.IdentityKey) == Convert.ToBase64String(new byte[] { 2,2 }));

            }
            var test1 = idops.Get(uid);

            Assert.IsNull(test1);

        }
    }
}
