﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Transactions;
using Dapper;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using NNk.Messenger.Api.Providers;
using NNK.Messenger.Core;
using NNK.Messenger.Data;

namespace NNK.Messenger.Business.Tests
{
    [TestClass]
    public class ChatOperationsTest
    {
        public class DapperConnectionStringProvider : IDapperConnectionStringProvider
        {
            public string ConnectionString => "Data Source = 10.1.41.60; Initial Catalog = NNK.Messenger.Test; Integrated Security = False; User Id=test; Password=test; ";
        }

        [TestMethod]
        public void Get_Success()
        {
            var dp = new DapperConnectionStringProvider();

            var po=new Dapper.PartyOperations(dp);

            var co=new Dapper.ChatOperations(dp, po);

            var chat0 = po.ExecuteQuery(db => db.Query<Chat>("select top 1 * from dbo.Chat(nolock)")?.FirstOrDefault());

            Assert.IsNotNull(chat0);

            var chat = co.Get(chat0.ID);

            Assert.IsNotNull(chat);

            Assert.AreEqual(chat0.ID,chat.ID);
            Assert.AreEqual(chat0.Author, chat.Author);
            Assert.AreEqual(chat0.Created, chat.Created);
            Assert.AreEqual(chat0.Party, chat.Party);
            Assert.AreEqual(chat0.Title, chat.Title);
        }

        [TestMethod]
        public void IsUserChat_Success()
        {
            var dp = new DapperConnectionStringProvider();

            var po = new Dapper.PartyOperations(dp);

            var co = new Dapper.ChatOperations(dp, po);

            var chat = co.ExecuteQuery(db => db.Query<Chat>("select top 1 * from dbo.Chat(nolock)")?.FirstOrDefault());

            Assert.IsNotNull(chat);

            var usernames = chat.Party.Split(new[] {","}, StringSplitOptions.RemoveEmptyEntries);

            Assert.IsTrue(usernames.Any());

            var res = co.IsUserChat(chat.ID, usernames.FirstOrDefault());

            Assert.IsNotNull(res);

            Assert.IsTrue(res);

            var bad = co.IsUserChat(chat.ID, "@idcockodudledu");

            Assert.IsNotNull(bad);

            Assert.IsFalse(bad);
        }

        [TestMethod]
        public void KillChat_Success()
        {
            var dp = new DapperConnectionStringProvider();
            var po = new Dapper.PartyOperations(dp);

            Guid? chatId = null;

            using (TransactionScope scope = new TransactionScope())
            {
                
                var co = new Dapper.ChatOperations(dp,po);

                chatId = co.ExecuteQuery(db => db.Query<Guid>("select top 1 ID from dbo.Chat(nolock)")?.FirstOrDefault());

                Assert.IsNotNull(chatId);

                co.KillChat(chatId.Value);

                var chat = co.ExecuteQuery(db =>db.Query<Chat>("select * from dbo.Chat(nolock) where Id=@chatId", new {chatId = chatId.Value}))?.FirstOrDefault();

                Assert.IsNull(chat);
            }
            var co1 = new Dapper.ChatOperations(dp, po);

            var chat1 = co1.ExecuteQuery(db => db.Query<Chat>("select * from dbo.Chat(nolock) where Id=@chatId", new { chatId = chatId.Value }))?.FirstOrDefault();

            Assert.IsNotNull(chat1);

        }
        [TestMethod]
        public void UpdateChatParty_Success()
        {
            var dp = new DapperConnectionStringProvider();
            var po = new Dapper.PartyOperations(dp);

            Chat chat = null;

            using (TransactionScope scope = new TransactionScope())
            {

                var co = new Dapper.ChatOperations(dp, po);

                chat = co.ExecuteQuery(db => db.Query<Chat>("select top 1 * from dbo.Chat(nolock)")?.FirstOrDefault());

                Assert.IsNotNull(chat);

                co.UpdateChatParty(chat.ID,"@iddqd");

                var partyChat = co.ExecuteQuery(db => db.Query<Chat>("select * from dbo.Chat(nolock) where Id=@chatId", new { chatId = chat.ID }))?.FirstOrDefault();

                Assert.IsNotNull(partyChat);

                Assert.IsTrue(partyChat.Party.Contains("@iddqd"));

            }
            var co1 = new Dapper.ChatOperations(dp, po);

            var partyChat1 = co1.ExecuteQuery(db => db.Query<Chat>("select * from dbo.Chat(nolock) where Id=@chatId", new { chatId = chat.ID }))?.FirstOrDefault();

            Assert.IsNotNull(partyChat1);

            Assert.IsTrue(!partyChat1.Party.Contains("@iddqd"));

        }
        [TestMethod]
        public void RemoveChatUser_Success()
        {
            var dp = new DapperConnectionStringProvider();
            var po = new Dapper.PartyOperations(dp);

            Chat chat = null;

            using (TransactionScope scope = new TransactionScope())
            {

                var co = new Dapper.ChatOperations(dp, po);

                chat = co.ExecuteQuery(db => db.Query<Chat>("select top 1 * from dbo.Chat(nolock)")?.FirstOrDefault());

                Assert.IsNotNull(chat);

                co.UpdateChatParty(chat.ID, "@iddqd");

                var partyChat = co.ExecuteQuery(db => db.Query<Chat>("select * from dbo.Chat(nolock) where Id=@chatId", new { chatId = chat.ID }))?.FirstOrDefault();

                Assert.IsNotNull(partyChat);

                Assert.IsTrue(partyChat.Party.Contains("@iddqd"));

                co.RemoveChatUser(partyChat.ID, "@iddqd");

                partyChat = co.ExecuteQuery(db => db.Query<Chat>("select * from dbo.Chat(nolock) where Id=@chatId", new { chatId = chat.ID }))?.FirstOrDefault();

                Assert.IsNotNull(partyChat);

                Assert.IsTrue(!partyChat.Party.Contains("@iddqd"));


            }
            var co1 = new Dapper.ChatOperations(dp, po);

            var partyChat1 = co1.ExecuteQuery(db => db.Query<Chat>("select * from dbo.Chat(nolock) where Id=@chatId", new { chatId = chat.ID }))?.FirstOrDefault();

            Assert.IsNotNull(partyChat1);

            Assert.IsTrue(!partyChat1.Party.Contains("@iddqd"));
        }

        [TestMethod]
        public void GetChatParty_Success()
        {
            var dp = new DapperConnectionStringProvider();

            var po = new Dapper.PartyOperations(dp);

            var co = new Dapper.ChatOperations(dp, po);

            var chat0 = po.ExecuteQuery(db => db.Query<Chat>("select top 1 * from dbo.Chat(nolock)")?.FirstOrDefault());

            var party0 = chat0.Party.Split(new[] {","}, StringSplitOptions.RemoveEmptyEntries);

            Assert.IsNotNull(chat0);

            Assert.IsNotNull(party0);

            Assert.IsTrue(party0.Any());

            var party = co.GetChatParty(chat0.ID);

            Assert.IsNotNull(party);

            Assert.IsTrue(party.Any());

            Assert.AreEqual(party.Length, party0.Length);

            foreach (var p in party)
            {
                Assert.IsTrue(party0.Contains(p));
            }
        }

        [TestMethod]
        public void GetChatIDsList_Success()
        {
            var dp = new DapperConnectionStringProvider();

            var po = new Dapper.PartyOperations(dp);

            var co = new Dapper.ChatOperations(dp, po);

            var chatListItem =
                co.ExecuteQuery(
                    db => db.Query<vw_user_chat_list>("select top 1 * from dbo.vw_user_chat_list")?.FirstOrDefault());

            Assert.IsNotNull(chatListItem);

            var list = co.GetChatIDsList(chatListItem.user);

            Assert.IsNotNull(list);

            Assert.IsTrue(list.Any());

            Assert.IsTrue(list.Contains(chatListItem.chat_id.ToString()));

        }

        [TestMethod]
        public void GetAllChatsList_timeLabelIsNull_Success()
        {
            var dp = new DapperConnectionStringProvider();

            var po = new Dapper.PartyOperations(dp);

            var co = new Dapper.ChatOperations(dp, po);

            var chatListItem =
                co.ExecuteQuery(
                    db => db.Query<vw_user_chat_list>("select top 1 * from dbo.vw_user_chat_list")?.FirstOrDefault());

            Assert.IsNotNull(chatListItem);

            var list = co.GetAllChatsList(chatListItem.user);

            Assert.IsNotNull(list);

            Assert.IsTrue(list.Any());

            Assert.IsTrue(list.Select(i=>i.ID).ToList().Contains(chatListItem.chat_id));

        }


        [TestMethod]
        public void GetAllParty_Success()
        {
            var dp = new DapperConnectionStringProvider();

            var po = new Dapper.PartyOperations(dp);

            var co = new Dapper.ChatOperations(dp, po);

            var chatListItem =
                co.ExecuteQuery(
                    db => db.Query<vw_user_chat_list>("select * from dbo.vw_user_chat_list"))?.FirstOrDefault();

            Assert.IsNotNull(chatListItem);

            var chatIds = co.ExecuteQuery(db => db.Query<Guid>("select chat_id from dbo.vw_user_chat_list where [user]=@user",new {user=chatListItem.user}));

            var chatIdsString = string.Join(",", chatIds.Select(i => $"'{i}'"));

            var allParty =
                co.ExecuteQuery(
                    db => db.Query<Party>($"select * from dbo.Party where ChatID in({chatIdsString}) "));

            Assert.IsNotNull(allParty);
            Assert.IsTrue(allParty.Any());

        }

        [TestMethod]
        public void GetChatList_Success()
        {
            var dp = new DapperConnectionStringProvider();

            var po = new Dapper.PartyOperations(dp);

            var co = new Dapper.ChatOperations(dp, po);

            var chatListItem =
                co.ExecuteQuery(
                    db => db.Query<vw_user_chat_list>("select top 1 * from dbo.vw_user_chat_list")?.FirstOrDefault());

            Assert.IsNotNull(chatListItem);

            var list = co.GetChatList(chatListItem.user);

            Assert.IsNotNull(list);

            Assert.IsTrue(list.Any());

            Assert.IsTrue(list.Select(i => i.chat_id).ToList().Contains(chatListItem.chat_id));

        }

        [TestMethod]
        public void GetChatByParty_Success()
        {
            var dp = new DapperConnectionStringProvider();

            var po = new Dapper.PartyOperations(dp);

            var co = new Dapper.ChatOperations(dp, po);

            var chat0 = po.ExecuteQuery(db => db.Query<Chat>("select top 1 * from dbo.Chat(nolock)")?.FirstOrDefault());

            var party0 = chat0.Party.Split(new[] { "," }, StringSplitOptions.RemoveEmptyEntries);

            Assert.IsNotNull(chat0);

            Assert.IsNotNull(party0);

            Assert.IsTrue(party0.Any());

            var party = co.GetChatParty(chat0.ID);

            Assert.IsNotNull(party);

            Assert.IsTrue(party.Any());

            Assert.AreEqual(party.Length, party0.Length);

            foreach (var p in party)
            {
                Assert.IsTrue(party0.Contains(p));
            }
        }

        [TestMethod]
        public void CreateChat_Success()
        {
            var dp = new DapperConnectionStringProvider();
            var po = new Dapper.PartyOperations(dp);

            var key = Guid.NewGuid();

            var chat = new Chat
            {
                ID = key,
                Author = "@iddqd",
                Created = DateTime.Now.ToUniversalTime(),
                Party = "@iddqd,@idkfa",
                Title = "Title",
                Tags = "Tags",
                IsHidden = false,
            };

            using (TransactionScope scope = new TransactionScope())
            {

                var co = new Dapper.ChatOperations(dp, po);

                var inserted = co.CreateChat(chat);

                chat.ID = inserted.ID;

                var chat1 = co.ExecuteQuery(db => db.Query<Chat>("select * from dbo.Chat(nolock) where Id=@chatId", new { chatId = inserted.ID }))?.FirstOrDefault();

                Assert.IsNotNull(chat1);

                Assert.AreEqual(inserted.ID, chat1.ID);

                Assert.AreEqual(chat.Author, chat1.Author);

                Assert.AreEqual(chat.Party, chat1.Party);

                Assert.AreEqual(chat.Title, chat1.Title);
            }
            var co1 = new Dapper.ChatOperations(dp, po);

            var chat2 = co1.ExecuteQuery(db => db.Query<Chat>("select * from dbo.Chat(nolock) where Id=@chatId", new { chatId = chat.ID }))?.FirstOrDefault();

            Assert.IsNull(chat2);

        }
        [TestMethod]
        public void UpdateChatTitle_Success()
        {
            var dp = new DapperConnectionStringProvider();
            var po = new Dapper.PartyOperations(dp);

            Chat chat = null;

            using (TransactionScope scope = new TransactionScope())
            {
                var newtitle = Guid.NewGuid().ToString();

                var co = new Dapper.ChatOperations(dp, po);

                chat = co.ExecuteQuery(db => db.Query<Chat>("select top 1 * from dbo.Chat(nolock)")?.FirstOrDefault());

                Assert.IsNotNull(chat);

                co.UpdateChatTitle(chat.ID, newtitle);

                var updatedChat = co.ExecuteQuery(db => db.Query<Chat>("select * from dbo.Chat(nolock) where Id=@chatId", new { chatId = chat.ID }))?.FirstOrDefault();

                Assert.IsNotNull(updatedChat);

                Assert.AreEqual(updatedChat.Title, newtitle);

            }
            var co1 = new Dapper.ChatOperations(dp, po);

            var partyChat1 = co1.ExecuteQuery(db => db.Query<Chat>("select * from dbo.Chat(nolock) where Id=@chatId", new { chatId = chat.ID }))?.FirstOrDefault();

            Assert.IsNotNull(partyChat1);

            Assert.IsTrue(!partyChat1.Party.Contains("@iddqd"));

        }
    }
}
