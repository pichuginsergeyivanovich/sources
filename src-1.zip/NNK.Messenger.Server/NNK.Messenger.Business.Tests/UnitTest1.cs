﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using NNk.Messenger.Api.Providers;
using NNK.Messenger.Business.Dapper;
using System.IO;

namespace NNK.Messenger.Business.Tests
{
    [TestClass]
    public class UnitTest1
    {
        [TestMethod]
        public void TestMethod1()
        {
            var dp = new DapperConnectionStringProvider();


            var idops = new IdentityOperations(dp);

            var idp = new DapperAspNetIdentityConnectionStringProvider();

            var uops = new UserOperations(idp);
            var pushOps = new PushOperations(idops, uops);

            var cert = File.ReadAllBytes(@"X:\inetpub\wwwroot\api.messenger.test\Resources\Certificates.p12");

            pushOps.SendPush("Text", new[]
            {
                "066957CCFB8E9078F26F471F29382C41A250446599ABD388E7C1B00AA4C2CD32",
                "595AE7DF969E703E7049CF62411F0A2F407BA2A343B55190C3D2C69F32C56F7E"
            }, cert, "");


        }
    }
}
