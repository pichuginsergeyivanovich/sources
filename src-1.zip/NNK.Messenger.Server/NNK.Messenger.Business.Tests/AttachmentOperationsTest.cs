﻿using System;
using System.Linq;
using System.Transactions;
using Dapper;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using NNK.Messenger.Core;
using NNK.Messenger.Data;

namespace NNK.Messenger.Business.Tests
{
    [TestClass]
    public class AttachmentOperationsTest
    {
        public class DapperConnectionStringProvider : IDapperConnectionStringProvider
        {
            public string ConnectionString => "Data Source = 10.1.41.60; Initial Catalog = NNK.Messenger.Test; Integrated Security = False; User Id=test; Password=test; ";
        }

        [TestMethod]
        public void LinkToMessage_Success()
        {
            var dp = new DapperConnectionStringProvider();

            var fso = new Dapper.FileStoreOperations(dp);

            var ao1 = new Dapper.AttachmentOperations(fso, dp);

            var existingStreamId = ao1.ExecuteQuery(db => db.Query<Guid>("select top 1 stream_id from dbo.FileStore(nolock)"))?.FirstOrDefault();

            Assert.IsNotNull(existingStreamId);

            var msid = Guid.NewGuid();

            var item = new FileStore_Add_Result()
            {
                stream_id = existingStreamId.Value,
                unc_path = "\\\\testserver\\uncshare\\testfilename.secret"
            };

            using (TransactionScope scope = new TransactionScope())
            {
                var ao = new Dapper.AttachmentOperations(fso, dp);

                ao.LinkToMessage(msid, new[] {item} );

                var test = ao.ExecuteQuery(db => db.Query<Attach>("select * from dbo.Attach(nolock) where MessageID=@msid", new { msid }))?.FirstOrDefault();

                Assert.IsNotNull(test);

                Assert.AreEqual(test.FilePath,item.unc_path);

                Assert.AreEqual(test.stream_id, item.stream_id);

            }

            

            var test1 = ao1.ExecuteQuery(db => db.Query<Attach>("select * from dbo.Attach(nolock) where MessageID=@msid", new { msid }))?.FirstOrDefault();

            Assert.IsNull(test1);

        }

        [TestMethod]
        public void AddAttachment_Success()
        {
            var dp = new DapperConnectionStringProvider();

            var fso = new Dapper.FileStoreOperations(dp);

            var ao1 = new Dapper.AttachmentOperations(fso, dp);

            var existingStreamId = ao1.ExecuteQuery(db => db.Query<Guid>("select top 1 stream_id from dbo.FileStore(nolock)"))?.FirstOrDefault();

            Assert.IsNotNull(existingStreamId);

            var msid = Guid.NewGuid();

            var fileName = $"testfilename_{Guid.NewGuid()}.test";

            var fileData = new byte[0];

            using (TransactionScope scope = new TransactionScope())
            {
                var ao = new Dapper.AttachmentOperations(fso, dp);

                ao.AddAttachment(msid, fileName, fileData);

                var test = ao.ExecuteQuery(db => db.Query<Attach>("select * from dbo.Attach(nolock) where MessageID=@msid", new { msid }))?.FirstOrDefault();

                Assert.IsNotNull(test);

                Assert.IsTrue(test.FilePath.Contains(fileName));

                var testfs = ao.ExecuteQuery(db => db.Query<dynamic>("select * from dbo.FileStore(nolock) where name=@fileName", new { fileName }))?.FirstOrDefault();

                Assert.IsNotNull(testfs);

                Assert.AreEqual(testfs.stream_id, test.stream_id);

            }

            var test1 = ao1.ExecuteQuery(db => db.Query<Attach>("select * from dbo.Attach(nolock) where MessageID=@msid", new { msid }))?.FirstOrDefault();

            Assert.IsNull(test1);

            var testfs1 = ao1.ExecuteQuery(db => db.Query<dynamic>("select * from dbo.FileStore(nolock) where name=@fileName", new { fileName }))?.FirstOrDefault();

            Assert.IsNull(testfs1);

        }


        [TestMethod]
        public void GetMessageAttachments_Success()
        {
            var dp = new DapperConnectionStringProvider();

            var fso = new Dapper.FileStoreOperations(dp);

            var ao1 = new Dapper.AttachmentOperations(fso, dp);

            var existingStreamId = ao1.ExecuteQuery(db => db.Query<Guid>("select top 1 stream_id from dbo.FileStore(nolock)"))?.FirstOrDefault();

            Assert.IsNotNull(existingStreamId);

            var msid = Guid.NewGuid();

            var fileName = $"testfilename_{Guid.NewGuid()}.test";

            var fileData = new byte[0];

            using (TransactionScope scope = new TransactionScope())
            {
                var ao = new Dapper.AttachmentOperations(fso, dp);

                ao.AddAttachment(msid, fileName, fileData);

                var test = ao.ExecuteQuery(db => db.Query<Attach>("select * from dbo.Attach(nolock) where MessageID=@msid", new { msid }))?.FirstOrDefault();

                Assert.IsNotNull(test);

                Assert.IsTrue(test.FilePath.Contains(fileName));

                var testfs = ao.ExecuteQuery(db => db.Query<dynamic>("select * from dbo.FileStore(nolock) where name=@fileName", new { fileName }))?.FirstOrDefault();

                Assert.IsNotNull(testfs);

                Assert.AreEqual(testfs.stream_id, test.stream_id);

                var atts = ao.GetMessageAttachments(msid);

                Assert.IsNotNull(atts);

                Assert.IsTrue(atts.Any());

            }

            var test1 = ao1.ExecuteQuery(db => db.Query<Attach>("select * from dbo.Attach(nolock) where MessageID=@msid", new { msid }))?.FirstOrDefault();

            Assert.IsNull(test1);

            var testfs1 = ao1.ExecuteQuery(db => db.Query<dynamic>("select * from dbo.FileStore(nolock) where name=@fileName", new { fileName }))?.FirstOrDefault();

            Assert.IsNull(testfs1);

        }

        [TestMethod]
        public void GetAttachIds_Success()
        {
            var dp = new DapperConnectionStringProvider();

            var fso = new Dapper.FileStoreOperations(dp);

            var ao = new Dapper.AttachmentOperations(fso, dp);

            var test =
                ao.ExecuteQuery(db => db.Query<Guid>("select distinct top 10 MessageID from dbo.Attach(nolock)"))?
                    .ToArray();

            Assert.IsNotNull(test);

            Assert.IsTrue(test.Any());

            var attids = ao.GetAttachIds(test);

            Assert.IsNotNull(attids);

            Assert.IsTrue(attids.Any());

        }

        [TestMethod]
        public void KillChatMessageAttaches_Success()
        {
            var dp = new DapperConnectionStringProvider();

            var fso = new Dapper.FileStoreOperations(dp);

            var ao = new Dapper.AttachmentOperations(fso, dp);

            var test =
                ao.ExecuteQuery(db => db.Query<Guid>("select distinct top 10 MessageID from dbo.Attach(nolock)"))?
                    .ToArray();

            Assert.IsNotNull(test);

            Assert.IsTrue(test.Any());

            using (TransactionScope scope = new TransactionScope())
            {
                var ao1 = new Dapper.AttachmentOperations(fso, dp);

                ao1.KillChatMessageAttaches(test);

                var test1 = ao1.ExecuteQuery(db => db.Query<Guid>("select MessageID from dbo.Attach where MessageID in (@msgids)",new { msgids =string.Join(",",test)}));

                Assert.IsTrue(test1 ==null || !test1.Any());

            }
            var test2 = ao.ExecuteQuery(db => db.Query<Guid>("select MessageID from dbo.Attach where MessageID in (@msgids)", new { msgids = string.Join(",", test) }));

            Assert.IsTrue(test2 != null && test2.Any());


        }
    }
}
