﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Transactions;
using Dapper;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using NNk.Messenger.Api.Providers;
using NNK.Messenger.Core;
using NNK.Messenger.Data;

namespace NNK.Messenger.Business.Tests
{
    [TestClass]
    public class NotificationOperationsTest
    {
        public class DapperConnectionStringProvider : IDapperConnectionStringProvider
        {
            public string ConnectionString => "Data Source = 10.1.41.60; Initial Catalog = NNK.Messenger.Test; Integrated Security = False; User Id=test; Password=test; ";
        }

        [TestMethod]
        public void GetChangeStatusSids_Success()
        {
            var dp = new DapperConnectionStringProvider();

            var no=new Dapper.NotificationOperations(dp);

            var statusCh = no.GetChangeStatusSids(Guid.Parse("8A88198C-4582-428E-998E-E08C68D9BCEC"));

            Assert.IsNotNull(statusCh);

            Assert.IsTrue(statusCh.Any());
         }
        [TestMethod]
        public void GetNotificationsBySid_Success()
        {
            var dp = new DapperConnectionStringProvider();

            var no = new Dapper.NotificationOperations(dp);

            var messageIdWithNotification = no.ExecuteQuery(db => db.Query<Notification>("select top 1 * from dbo.Notification(nolock)")?.FirstOrDefault());

            Assert.IsNotNull(messageIdWithNotification);

            var notifications = no.GetNotifications(messageIdWithNotification.messageId);

            Assert.IsNotNull(notifications);

            Assert.IsTrue(notifications.Any());
        }
        [TestMethod]
        public void GetNotificationsBySidAndType_Success()
        {
            var dp = new DapperConnectionStringProvider();

            var no = new Dapper.NotificationOperations(dp);

            var messageIdWithNotification = no.ExecuteQuery(db => db.Query<Notification>("select top 1 * from dbo.Notification(nolock)")?.FirstOrDefault());

            Assert.IsNotNull(messageIdWithNotification);

            var notifications = no.GetNotifications(messageIdWithNotification.messageId, (NotificationTypeEnum)messageIdWithNotification.type);

            Assert.IsNotNull(notifications);

            Assert.IsTrue(notifications.Any());
        }
        
        [TestMethod]
        public void KillChatMessageNotifications_Success()
        {
            var dp = new DapperConnectionStringProvider();

            IEnumerable<Notification> rows = null;

            string msgIdsString;

            using (TransactionScope scope = new TransactionScope())
            {
                var no = new Dapper.NotificationOperations(dp);

                var msgIds = no.ExecuteQuery(db => db.Query<Guid>("select top 10 messageId from dbo.Notification(nolock)"))?.ToArray();

                Assert.IsNotNull(msgIds);

                Assert.IsTrue(msgIds.Any());

                no.KillChatMessageNotifications(msgIds);

                msgIdsString = string.Join(",", msgIds.Select(i => $"{i}"));

                rows =
                    no.ExecuteQuery(
                        db =>
                            db.Query<Notification>("select * from dbo.Notification(nolock) where messageId in (@msgIdsString)",new { msgIdsString }));

                Assert.IsTrue(!rows.Any() || rows == null);
            }
            var no1 = new Dapper.NotificationOperations(dp);

            rows =
                no1.ExecuteQuery(
                    db =>
                        db.Query<Notification>("select * from dbo.Notification(nolock) where messageId in (@msgIdsString)", new { msgIdsString }));


            Assert.IsNotNull(rows);

            Assert.IsTrue(rows.Any());

        }
        [TestMethod]
        public void AddBulkNotification_Success()
        {

            var dp = new DapperConnectionStringProvider();

            IEnumerable<Notification> rows = null;
            IEnumerable<Notification> rowsByUsers = null;

            using (TransactionScope scope = new TransactionScope())
            {
                var no = new Dapper.NotificationOperations(dp);

                var chatId = no.ExecuteQuery(db => db.Query<Guid>("select top 1 ChatID from dbo.Message(nolock)"))?.FirstOrDefault();

                Assert.IsNotNull(chatId);

                rowsByUsers =
                  no.ExecuteQuery(
                      db =>
                          db.Query<Notification>(
                              "select * from dbo.Notification(nolock) where username = @username and type=@type",
                              new { username = "@iddqd", type = (byte)NotificationTypeEnum.NT_READ }))?.ToArray();

                Assert.IsTrue(!rowsByUsers.Any());

                var result = no.AddBulkNotification(NotificationTypeEnum.NT_READ, chatId.Value, DateTime.Now, "clientDescrs", "0.0.0.0", "@iddqd").Distinct().ToArray();

                rowsByUsers =
                 no.ExecuteQuery(
                     db =>
                         db.Query<Notification>(
                             "select * from dbo.Notification(nolock) where username = @username and type=@type",
                             new { username = "@iddqd", type = (byte)NotificationTypeEnum.NT_READ }))?.ToArray();

                Assert.IsTrue(rowsByUsers.Any());

            }
            var no1 = new Dapper.NotificationOperations(dp);

            rows =
                no1.ExecuteQuery(
                    db =>
                        db.Query<Notification>(
                            "select * from dbo.Notification(nolock) where username = @username and type=@type",
                            new {username = "@iddqd", type = (byte) NotificationTypeEnum.NT_READ}))?.ToArray();

            Assert.IsTrue(!rows.Any());

        }
        [TestMethod]
        public void AddNotification_Success()
        {
            var dp = new DapperConnectionStringProvider();

            IEnumerable<Notification> rows = null;

            var msid = Guid.NewGuid();

            using (TransactionScope scope = new TransactionScope()){

                var po = new Dapper.NotificationOperations(dp);

                po.AddNotification(NotificationTypeEnum.NT_READ, msid, DateTime.Now, "client descr", "0.0.0.0", "@iddqd");

                rows =
                    po.ExecuteQuery(
                            db =>
                                db.Query<Notification>(
                                    "select * from dbo.Notification(nolock) where messageId=@msid and username=@username",
                                    new {msid, username = "@iddqd"}))
                        .ToArray();

                Assert.IsNotNull(rows);

                Assert.AreEqual(rows.Count(),1);
            }
            var po1 = new Dapper.NotificationOperations(dp);

            rows =
                po1.ExecuteQuery(
                        db =>
                            db.Query<Notification>(
                                "select * from dbo.Notification(nolock) where messageId=@msid", new { msid}))
                    .ToArray();

            Assert.IsNotNull(rows);

            Assert.IsTrue(!rows.Any());
        }
    }
}
