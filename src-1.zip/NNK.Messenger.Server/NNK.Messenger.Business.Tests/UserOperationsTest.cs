﻿using System.Linq;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using NNK.Messenger.Core;

namespace NNK.Messenger.Business.Tests
{
    [TestClass]
    public class UserOperationsTest
    {
        public class DapperConnectionStringProvider : IDapperConnectionStringProvider
        {
            public string ConnectionString => "Data Source = 10.1.41.60; Initial Catalog = AspNet.Identity.Test; Integrated Security = False; User Id=test; Password=test; ";
        }

        [TestMethod]
        public void GetList_Success()
        {
            var dp = new DapperConnectionStringProvider();

            var uo = new Dapper.UserOperations(dp);

            var list = uo.GetList();

            Assert.IsNotNull(list);

            Assert.IsTrue(list.Any());

        }

        [TestMethod]
        public void GetListForSync_Success()
        {
            var dp = new DapperConnectionStringProvider();

            var uo = new Dapper.UserOperations(dp);

            var list = uo.GetListForSync();

            Assert.IsNotNull(list);

            Assert.IsTrue(list.Any());

        }

        [TestMethod]
        public void GetByLogin_Success()
        {
            var dp = new DapperConnectionStringProvider();

            var uo = new Dapper.UserOperations(dp);

            var existUser = uo.GetByLogin("putin");

            Assert.IsNotNull(existUser);

            Assert.IsTrue(existUser);
        }

        [TestMethod]
        public void GetByPhone_Success()
        {
            var dp = new DapperConnectionStringProvider();

            var uo = new Dapper.UserOperations(dp);

            var existUser = uo.GetByPhone("79169266143");

            Assert.IsNotNull(existUser);

            Assert.IsTrue(existUser);
        }

        [TestMethod]
        public void GetByEmail_Success()
        {
            var dp = new DapperConnectionStringProvider();

            var uo = new Dapper.UserOperations(dp);

            var existUser = uo.GetByEmail("putin@putin.ru");

            Assert.IsNotNull(existUser);

            Assert.IsTrue(existUser);
        }

        [TestMethod]
        public void GetByName_Success()
        {
            var dp = new DapperConnectionStringProvider();

            var uo = new Dapper.UserOperations(dp);

            var user = uo.GetByName("@putin");

            Assert.IsNotNull(user);

            Assert.AreEqual(user.UserName, "putin");
        }


    }
}
