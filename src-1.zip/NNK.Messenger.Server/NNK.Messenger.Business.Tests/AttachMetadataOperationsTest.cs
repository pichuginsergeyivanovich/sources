﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Transactions;
using Dapper;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Newtonsoft.Json.Linq;
using NNk.Messenger.Api.Providers;
using NNK.Messenger.Core;
using NNK.Messenger.Data;

namespace NNK.Messenger.Business.Tests
{
    [TestClass]
    public class AttachMetadataOperationsTest
    {
        public class DapperConnectionStringProvider : IDapperConnectionStringProvider
        {
            public string ConnectionString => "Data Source = 10.1.41.60; Initial Catalog = NNK.Messenger.Test; Integrated Security = False; User Id=test; Password=test; ";
        }

        [TestMethod]
        public void GetMetadata_Success()
        {
            var dp = new DapperConnectionStringProvider();

            var amo = new Dapper.AttachMetadataOperations(dp);

            var metadata0 = amo.ExecuteQuery(db => db.Query<AttachMedatada>("select top 1 * from dbo.AttachMedatada(nolock)")?.FirstOrDefault());

            Assert.IsNotNull(metadata0);

            var metadata = amo.GetMetadata(metadata0.MessageID);

            Assert.IsNotNull(metadata);

            Assert.AreEqual(metadata, metadata0.AttachMetadata);
        }
        
        [TestMethod]
        public void AddAttachMetadata_Success()
        {
            var dp = new DapperConnectionStringProvider();

            var item = new AttachMedatada
            {
                ID = Guid.NewGuid(),
                MessageID = Guid.NewGuid(),
                AttachMetadata = "[{\"name\":\"1518343373 - 0.jpg\",\"size\":947055,\"type\":\"image / jpeg\",\"attachId\":235}]"
            };

            using (TransactionScope scope = new TransactionScope())
            {
                var amo = new Dapper.AttachMetadataOperations(dp);

                amo.AddAttachMetadata(item.AttachMetadata, item.MessageID);

                var md = amo.ExecuteQuery(db => db.Query<AttachMedatada>("select top 1 * from dbo.AttachMedatada(nolock) where MessageID = @MessageID", new { MessageID=item.MessageID})?.FirstOrDefault());

                Assert.IsNotNull(md);

                Assert.AreEqual(md.MessageID, item.MessageID);

                Assert.AreEqual(md.AttachMetadata, item.AttachMetadata);
            }
            var amo1 = new Dapper.AttachMetadataOperations(dp);

            var md1 = amo1.ExecuteQuery(db => db.Query<AttachMedatada>("select top 1 * from dbo.AttachMedatada(nolock) where MessageID = @MessageID", new { MessageID = item.MessageID })?.FirstOrDefault());

            Assert.IsNull(md1);
        }
        [TestMethod]
        public void LinkAttachMetadata_Success()
        {
            var dp = new DapperConnectionStringProvider();

            Guid? messageId = null;
            int? attachId = null;

            using (TransactionScope scope = new TransactionScope())
            {
                var amo = new Dapper.AttachMetadataOperations(dp);

                var a = amo.ExecuteQuery(db => db.Query<Attach>("select top 1 * from dbo.Attach(nolock)")?.FirstOrDefault());

                messageId = a.MessageID;

                attachId = 77777;
                a.ID = 77777;

                Assert.IsNotNull(a);

                amo.LinkAttachMetadata(a);

                var md = amo.ExecuteQuery(db => db.Query<AttachMedatada>("select top 1 * from dbo.AttachMedatada(nolock) where MessageID = @MessageID", new { MessageID = a.MessageID })?.FirstOrDefault());

                Assert.IsNotNull(md);

                Assert.IsTrue(md.AttachMetadata.Contains($"\"attachId\":{attachId}"));
                
            }
            var amo1 = new Dapper.AttachMetadataOperations(dp);

            var md1 = amo1.ExecuteQuery(db => db.Query<AttachMedatada>("select top 1 * from dbo.AttachMedatada(nolock) where MessageID = @MessageID", new { MessageID = messageId })?.FirstOrDefault());

            Assert.IsTrue( md1==null || (md1!=null && !md1.AttachMetadata.Contains($"\"attachId\":{attachId}")));

        }

        [TestMethod]
        public void Test()
        {
            var a = "[{\"id\":123,\"name\":\"1518343373 - 0.jpg\",\"size\":947055,\"type\":\"image / jpeg\",\"attachId\":235}, {\"id\":124,\"name\":\"1518343374 - 4.jpg\",\"size\":9470554,\"type\":\"image / jpeg\",\"attachId\":4}]";

            var jobj = JArray.Parse(a);

            var list = new List<int>();

            for (var i = 0; i < jobj.Count; i++)
            {
                var j = jobj[i] as JObject;

                if (j==null)
                    continue;

                var id = (string)j.GetValue("id");

                if (id == null)
                    continue;

                int num;

                if(int.TryParse(id,out num))
                    list.Add(num);

            }
        }

    }
}
