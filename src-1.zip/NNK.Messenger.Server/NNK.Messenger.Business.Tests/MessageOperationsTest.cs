﻿using System;
using System.Linq;
using System.Transactions;
using Dapper;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using NNk.Messenger.Api.Providers;
using NNK.Messenger.Core;
using NNK.Messenger.Data;

namespace NNK.Messenger.Business.Tests
{
    [TestClass]
    public class MessageOperationsTest
    {
        public class DapperConnectionStringProvider : IDapperConnectionStringProvider
        {
            public string ConnectionString => "Data Source = 10.1.41.60; Initial Catalog = NNK.Messenger.Test; Integrated Security = False; User Id=test; Password=test; ";
        }
        //        [TestMethod]
        //        public void TestMethod1()
        //        {
        //            var dp = new MessageOperationsTest.DapperConnectionStringProvider();
        //            var co = new Dapper.ChatOperations(dp);
        //            var mo = new Dapper.MessageOperations(dp, co);
        //
        //
        //            var i = mo.Get(Guid.Parse("B4F2F443-AB0A-4C6B-A6F9-00B62C63F8E1"));
        //
        //            Assert.IsNotNull(i);
        //        }

        [TestMethod]
        public void GetMessages_ChatIdOnly_Success()
        {
            var dp = new DapperConnectionStringProvider();

            var pops = new Dapper.PartyOperations(dp);

            

            var co = new Dapper.ChatOperations(dp, pops);

            var amo = new Dapper.AttachMetadataOperations(dp);

            var mo = new Dapper.MessageOperations(dp, co, amo);

            var chatIdWithMessagesRow = mo.ExecuteQuery(db => db.Query<Guid>("select top 1 ChatID from dbo.Message(nolock)")?.FirstOrDefault());

            Assert.IsNotNull(chatIdWithMessagesRow);

            var messages = mo.GetMessages(chatIdWithMessagesRow.Value);

            Assert.IsNotNull(messages);

            Assert.IsTrue(messages.Any());
        }
        [TestMethod]
        public void GetMessages_ChatIdWithMsgChkSum_Success()
        {
            var dp = new DapperConnectionStringProvider();

            var pops = new Dapper.PartyOperations(dp);

            var co = new Dapper.ChatOperations(dp, pops);

            var amo = new Dapper.AttachMetadataOperations(dp);

            var mo = new Dapper.MessageOperations(dp, co, amo);


            var chatMessagesRow = mo.ExecuteQuery(db => db.Query<Message>("select top 1 * from dbo.Message(nolock)")?.FirstOrDefault());

            Assert.IsNotNull(chatMessagesRow);

            var messages = mo.GetMessages(chatMessagesRow.ChatID,null, chatMessagesRow.MsgChkSum.ToString());

            Assert.IsNotNull(messages);

            Assert.IsTrue(messages.Any());
        }
        [TestMethod]
        public void GetChatMessagesIDs_Success()
        {
            var dp = new DapperConnectionStringProvider();
            
            var pops=new Dapper.PartyOperations(dp);

            var co=new Dapper.ChatOperations(dp,pops);

            var amo = new Dapper.AttachMetadataOperations(dp);

            var mo = new Dapper.MessageOperations(dp, co, amo);


            var chatIdWithMessagesRow = mo.ExecuteQuery(db => db.Query<Guid>("select top 1 ChatID from dbo.Message(nolock)")?.FirstOrDefault());

            Assert.IsNotNull(chatIdWithMessagesRow);

            var messages = mo.GetChatMessagesIDs(chatIdWithMessagesRow);

            Assert.IsNotNull(messages);

            Assert.IsTrue(messages.Any());
        }
        [TestMethod]
        public void GetChatMessagesIDs_Failed_NonExistentChatID()
        {
            var dp = new DapperConnectionStringProvider();

            var pops = new Dapper.PartyOperations(dp);

            var co = new Dapper.ChatOperations(dp, pops);

            var amo = new Dapper.AttachMetadataOperations(dp);

            var mo = new Dapper.MessageOperations(dp, co, amo);


            var chatIdWithMessagesRow = Guid.Empty;

            Assert.IsNotNull(chatIdWithMessagesRow);

            var messages = mo.GetChatMessagesIDs(chatIdWithMessagesRow);

            Assert.IsNotNull(messages);

            Assert.IsTrue(!messages.Any());
        }
        [TestMethod]
        public void GetChatMessagesIDs_Failed_ChatIDIsNull()
        {
            var dp = new DapperConnectionStringProvider();

            var pops = new Dapper.PartyOperations(dp);

            var co = new Dapper.ChatOperations(dp, pops);

            var amo = new Dapper.AttachMetadataOperations(dp);

            var mo = new Dapper.MessageOperations(dp, co, amo);


            Guid? chatIdWithMessagesRow = null;

            Assert.IsNull(chatIdWithMessagesRow);

        }
        [TestMethod]
        public void KillMessages_Success()
        {
            var dp = new DapperConnectionStringProvider();

            var pops = new Dapper.PartyOperations(dp);

            Guid? chatIdWithMessagesRow = null;

            using (TransactionScope scope = new TransactionScope())
            {
                

                var co = new Dapper.ChatOperations(dp, pops);

                var amo = new Dapper.AttachMetadataOperations(dp);

                var mo = new Dapper.MessageOperations(dp, co, amo);


                chatIdWithMessagesRow =
                    mo.ExecuteQuery(
                        db => db.Query<Guid>("select top 1 ChatID from dbo.Message(nolock)")?.FirstOrDefault());

                Assert.IsNotNull(chatIdWithMessagesRow);

                mo.KillMessages(chatIdWithMessagesRow.Value);

                var chatMessagesAfterDelete = mo.GetChatMessagesIDs(chatIdWithMessagesRow);

                Assert.IsTrue(!chatMessagesAfterDelete.Any());

            }
            var co1 = new Dapper.ChatOperations(dp, pops);

            var amo1 = new Dapper.AttachMetadataOperations(dp);

            var mo1 = new Dapper.MessageOperations(dp, co1, amo1);


            var chatMessagesAfterDeleteOutOfTran = mo1.GetChatMessagesIDs(chatIdWithMessagesRow);

            Assert.IsNotNull(chatMessagesAfterDeleteOutOfTran);

        }


        [TestMethod]
        public void UpdateMessageText_Success()
        {
            var dp = new DapperConnectionStringProvider();

            var pops = new Dapper.PartyOperations(dp);

            Message MessageRow = null;

            using (TransactionScope scope = new TransactionScope())
            {
                var co = new Dapper.ChatOperations(dp, pops);

                var amo = new Dapper.AttachMetadataOperations(dp);

                var mo = new Dapper.MessageOperations(dp, co, amo);


                MessageRow =
                    mo.ExecuteQuery(
                        db => db.Query<Message>("select top 1 * from dbo.Message(nolock)")?.FirstOrDefault());

                Assert.IsNotNull(MessageRow);

                mo.UpdateMessageText(MessageRow.ID, "Данное сообщение удалено");

                var MessageRowUpdated =
                                   mo.ExecuteQuery(
                                       db => db.Query<Message>("select top 1 * from dbo.Message(nolock) where ID=@id", new { id = MessageRow.ID })?.FirstOrDefault());

                Assert.IsNotNull(MessageRowUpdated);

                Assert.AreNotEqual(MessageRow.Text, MessageRowUpdated.Text);

                Assert.AreEqual("Данное сообщение удалено", MessageRowUpdated.Text);

            }
            var co1 = new Dapper.ChatOperations(dp, pops);

            var amo1 = new Dapper.AttachMetadataOperations(dp);

            var mo1 = new Dapper.MessageOperations(dp, co1, amo1);


            var MessageAfterUpdateOutOfTran = mo1.Get(MessageRow.ID);

            Assert.IsNotNull(MessageAfterUpdateOutOfTran);

            Assert.AreEqual(MessageAfterUpdateOutOfTran.Text, MessageRow.Text);

        }
    }
}
