﻿using System;
using System.Linq;
using System.Transactions;
using Dapper;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using NNK.Messenger.Core;
using NNK.Messenger.Data;

namespace NNK.Messenger.Business.Tests
{
    [TestClass]
    public class InviteOperationsTest
    {
        public class DapperConnectionStringProvider : IDapperConnectionStringProvider
        {
            public string ConnectionString => "Data Source = 10.1.41.60; Initial Catalog = NNK.Messenger.Test; Integrated Security = False; User Id=test; Password=test; ";
        }

        [TestMethod]
        public void CreateInvite_Success()
        {
            var dp = new DapperConnectionStringProvider();

            var io1 = new Dapper.InviteOperations(dp);

            var inviter = "@inviter";
            var invited = "@invited";

            Guid? inviteID = null;

            var existingChatId = io1.ExecuteQuery(db => db.Query<Guid>("select top 1 ID from dbo.Chat(nolock)")?.FirstOrDefault());

            Assert.IsNotNull(existingChatId);

            using (TransactionScope scope = new TransactionScope())
            {
                var io = new Dapper.InviteOperations(dp);

                var test = io.CreateInvite(existingChatId.Value, inviter, invited);

                inviteID = test.ID;

                Assert.IsNotNull(test);

                Assert.IsNotNull(test.ID);

                Assert.AreEqual(invited, test.Invited);

                Assert.AreEqual(inviter, test.Inviter);

                Assert.AreEqual(existingChatId.Value, test.ChatId);

            }

            var test0 = io1.ExecuteQuery(db => db.Query<Invite>("select * from dbo.Invite(nolock) where ID=@ID",new {ID=inviteID.Value})?.FirstOrDefault());

            Assert.IsNull(test0);
        }

        [TestMethod]
        public void GetAllByUser_Success()
        {
            var dp = new DapperConnectionStringProvider();

            var io = new Dapper.InviteOperations(dp);

            var test0 = io.ExecuteQuery(db => db.Query<Invite>("select top 1 * from dbo.Invite(nolock)")?.FirstOrDefault());

            Assert.IsNotNull(test0);

            var user = test0.Invited;

            Assert.IsNotNull(user);

            var invites = io.GetAllByUser(user);

            Assert.IsNotNull(invites);

            Assert.IsTrue(invites.Any());
        }
        [TestMethod]
        public void Get_Success()
        {
            var dp = new DapperConnectionStringProvider();

            var io = new Dapper.InviteOperations(dp);

            var test0 = io.ExecuteQuery(db => db.Query<Invite>("select top 1 * from dbo.Invite(nolock)")?.FirstOrDefault());

            Assert.IsNotNull(test0);

            Assert.IsNotNull(test0.ID);

            var invite = io.Get(test0.ID);

            Assert.IsNotNull(invite);

            Assert.AreEqual(invite.ID, test0.ID);
        }


        [TestMethod]
        public void AcceptInvite_Success()
        {
            var dp = new DapperConnectionStringProvider();

            var io1 = new Dapper.InviteOperations(dp);

            var inviter = "@inviter";
            var invited = "@invited";

            Guid? inviteID = null;

            var existingChatId = io1.ExecuteQuery(db => db.Query<Guid>("select top 1 ID from dbo.Chat(nolock)")?.FirstOrDefault());

            Assert.IsNotNull(existingChatId);

            using (TransactionScope scope = new TransactionScope())
            {
                var io = new Dapper.InviteOperations(dp);

                var test = io.CreateInvite(existingChatId.Value, inviter, invited);

                inviteID = test.ID;

                Assert.IsNotNull(test);

                Assert.IsNotNull(test.ID);

                Assert.AreEqual(invited, test.Invited);

                Assert.AreEqual(inviter, test.Inviter);

                Assert.AreEqual(existingChatId.Value, test.ChatId);

                var testacc = io.AcceptInvite(test);

                Assert.IsNotNull(testacc);

                Assert.IsTrue(testacc.IsInviteAccept);

                Assert.IsNotNull(testacc.Accepted);

                Assert.AreEqual(DateTime.Now.Date, testacc.Accepted.Value.Date);
            }

            var test1 = io1.ExecuteQuery(db => db.Query<Invite>("select * from dbo.Invite(nolock) where ID=@ID", new { ID = inviteID.Value })?.FirstOrDefault());

            Assert.IsNull(test1);
        }

        [TestMethod]
        public void RejectInvite_Success()
        {
            var dp = new DapperConnectionStringProvider();

            var io1 = new Dapper.InviteOperations(dp);

            var inviter = "@inviter";
            var invited = "@invited";

            Guid? inviteID = null;

            var existingChatId = io1.ExecuteQuery(db => db.Query<Guid>("select top 1 ID from dbo.Chat(nolock)")?.FirstOrDefault());

            Assert.IsNotNull(existingChatId);

            using (TransactionScope scope = new TransactionScope())
            {
                var io = new Dapper.InviteOperations(dp);

                var test = io.CreateInvite(existingChatId.Value, inviter, invited);

                inviteID = test.ID;

                Assert.IsNotNull(test);

                Assert.IsNotNull(test.ID);

                Assert.AreEqual(invited, test.Invited);

                Assert.AreEqual(inviter, test.Inviter);

                Assert.AreEqual(existingChatId.Value, test.ChatId);

                var testacc = io.RejectInvite(test);

                Assert.IsNotNull(testacc);

                Assert.IsFalse(testacc.IsInviteAccept);

                Assert.IsNotNull(testacc.Accepted);

                Assert.AreEqual(DateTime.Now.Date, testacc.Accepted.Value.Date);
            }

            var test1 = io1.ExecuteQuery(db => db.Query<Invite>("select * from dbo.Invite(nolock) where ID=@ID", new { ID = inviteID.Value })?.FirstOrDefault());

            Assert.IsNull(test1);
        }

        [TestMethod]
        public void Delete_Success()
        {
            var dp = new DapperConnectionStringProvider();

            var io1 = new Dapper.InviteOperations(dp);

            var test1 = io1.ExecuteQuery(db => db.Query<Invite>("select top 1 * from dbo.Invite(nolock)")?.FirstOrDefault());

            Assert.IsNotNull(test1);

            Assert.IsNotNull(test1.ID);

            using (TransactionScope scope = new TransactionScope())
            {
                var io = new Dapper.InviteOperations(dp);

                io.Delete(test1.ID);

                var test2 = io1.ExecuteQuery(db => db.Query<Invite>("select * from dbo.Invite(nolock) where ID=@ID", new { ID = test1.ID })?.FirstOrDefault());

                Assert.IsNull(test2);
            }
            var test3 = io1.ExecuteQuery(db => db.Query<Invite>("select * from dbo.Invite(nolock) where ID=@ID", new { ID = test1.ID })?.FirstOrDefault());

            Assert.IsNotNull(test3);

        }


    }
}

