﻿using NNK.RabbitMQ.Core;
using RabbitMQ.Client;

namespace NNK.Messenger.Business.Tests
{
    public class RabbitMqConnectionFactoryProvider: IRabbitMqConnectionFactoryProvider
    {
        readonly IRabbitMqSettingsProvider _settingsProvider;

        public RabbitMqConnectionFactoryProvider(IRabbitMqSettingsProvider settingsProvider)
        {
            _settingsProvider = settingsProvider;
        }

        public ConnectionFactory CreateConnectionFactory()
        {
            var factory = new ConnectionFactory()
            {
                HostName = "10.1.34.64",
                UserName = "operator",
                Password = "operator",
                AutomaticRecoveryEnabled = true
            };

            return factory;
        }
    }
}
