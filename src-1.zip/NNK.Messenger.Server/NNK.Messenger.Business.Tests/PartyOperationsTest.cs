﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Transactions;
using Dapper;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using NNk.Messenger.Api.Providers;
using NNK.Messenger.Core;
using NNK.Messenger.Data;

namespace NNK.Messenger.Business.Tests
{
    [TestClass]
    public class PartyOperationsTest
    {
        public class DapperConnectionStringProvider : IDapperConnectionStringProvider
        {
            public string ConnectionString => "Data Source = 10.1.41.60; Initial Catalog = NNK.Messenger.Test; Integrated Security = False; User Id=test; Password=test; ";
        }

        [TestMethod]
        public void GetChatParty_Success()
        {
            var dp = new DapperConnectionStringProvider();

            var po=new Dapper.PartyOperations(dp);

            var chatId = po.ExecuteQuery(db => db.Query<Guid>("select top 1 ChatID from dbo.Party(nolock)")?.FirstOrDefault());

            Assert.IsNotNull(chatId);

            var party = po.GetChatParty(chatId);

            Assert.IsNotNull(party);

            Assert.IsTrue(party.Any());
         }
        
        [TestMethod]
        public void GetChatUserParty_Success()
        {
            var dp = new DapperConnectionStringProvider();

            var po = new Dapper.PartyOperations(dp);

            var party = po.ExecuteQuery(db => db.Query<Party>("select * from dbo.Party(nolock)")?.FirstOrDefault());

            Assert.IsNotNull(party);

            var user = party.User;

            Assert.IsTrue(!string.IsNullOrEmpty(user));

            var chatId = party.ChatID;

            Assert.IsNotNull(chatId);

            Assert.AreNotEqual(chatId, Guid.Empty);

            var partyResult = po.GetChatUserParty(chatId, user);

            Assert.IsNotNull(partyResult);

            Assert.AreEqual(partyResult.ChatID, party.ChatID);

            Assert.AreEqual(partyResult.User, party.User);
        }

        [TestMethod]
        public void KillParty_Success()
        {
            var dp = new DapperConnectionStringProvider();

            IEnumerable<Party> rows = null;
            Guid? chatId = null;

            using (TransactionScope scope = new TransactionScope())
            {
                var po = new Dapper.PartyOperations(dp);

                chatId = po.ExecuteQuery(db => db.Query<Guid>("select top 1 ChatID from dbo.Party(nolock)")?.FirstOrDefault());

                Assert.IsNotNull(chatId);

                po.KillParty(chatId.Value);

                rows =
                    po.ExecuteQuery(
                        db =>
                            db.Query<Party>("select * from dbo.Party(nolock) where chatId=@chatId",
                                new {chatId = chatId.Value}));

                Assert.IsTrue(!rows.Any() || rows == null);
            }
            var po1 = new Dapper.PartyOperations(dp);

            rows =
                po1.ExecuteQuery(
                    db =>
                        db.Query<Party>("select * from dbo.Party(nolock) where chatId=@chatId",
                            new { chatId = chatId.Value }));


            Assert.IsNotNull(rows);

            Assert.IsTrue(rows.Any());

        }
        [TestMethod]
        public void LinkPartyToChat_Success()
        {
            var dp = new DapperConnectionStringProvider();

            IEnumerable<Party> rows = null;
            IEnumerable<Party> party = null;
            Guid? chatId = null;

            using (TransactionScope scope = new TransactionScope())
            {
                var po = new Dapper.PartyOperations(dp);

                var q= po.ExecuteQuery(db => db.Query<Party>("select * from dbo.Party(nolock)"))
                        .ToArray();

                Assert.IsNotNull(q);

                Assert.IsTrue(q.Any());

                chatId = q.FirstOrDefault()?.ChatID;

                Assert.IsNotNull(chatId);

                party = q.Where(i => i.ChatID == chatId.Value).ToArray();

                po.LinkPartyToChat(new [] { "@iddqd", "@idkfa" },chatId.Value);

                rows =
                    po.ExecuteQuery(
                        db =>
                            db.Query<Party>("select * from dbo.Party(nolock) where chatId=@chatId",
                                new { chatId = chatId.Value }))
                                    .ToArray();

                Assert.IsNotNull(rows);

                Assert.IsTrue(rows.Any());

                Assert.AreEqual(party.Count() + 2, rows.Count());
            }
            var po1 = new Dapper.PartyOperations(dp);

            rows =
                po1.ExecuteQuery(
                    db =>
                        db.Query<Party>("select * from dbo.Party(nolock) where chatId=@chatId",
                            new { chatId = chatId.Value })).ToArray();

            Assert.IsNotNull(rows);

            Assert.IsTrue(rows.Any());

            Assert.AreEqual(party.Count(), rows.Count());

        }
        [TestMethod]
        public void RemoveChatUser_Success()
        {
            var dp = new DapperConnectionStringProvider();

            IEnumerable<Party> rows = null;
            IEnumerable<Party> party = null;
            Guid? chatId = null;

            using (TransactionScope scope = new TransactionScope())
            {
                var po = new Dapper.PartyOperations(dp);

                var q = po.ExecuteQuery(db => db.Query<Party>("select * from dbo.Party(nolock)"))
                        .ToArray();

                Assert.IsNotNull(q);

                Assert.IsTrue(q.Any());

                chatId = q.FirstOrDefault()?.ChatID;

                var user = q.FirstOrDefault()?.User;

                Assert.IsNotNull(chatId);

                Assert.IsTrue(!string.IsNullOrEmpty(user));

                party = q.Where(i => i.ChatID == chatId.Value).ToArray();

                po.RemoveChatUser(user, chatId);

                rows =
                    po.ExecuteQuery(
                        db =>
                            db.Query<Party>("select * from dbo.Party(nolock) where chatId=@chatId",
                                new { chatId = chatId.Value }))
                                    .ToArray();

                Assert.IsNotNull(rows);

                Assert.AreEqual(party.Count() - 1, rows.Count());
            }
            var po1 = new Dapper.PartyOperations(dp);

            rows =
                po1.ExecuteQuery(
                    db =>
                        db.Query<Party>("select * from dbo.Party(nolock) where chatId=@chatId",
                            new { chatId = chatId.Value })).ToArray();

            Assert.IsNotNull(rows);

            Assert.IsTrue(rows.Any());

            Assert.AreEqual(party.Count(), rows.Count());

        }
    }
}
