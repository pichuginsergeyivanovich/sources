﻿using System;
using System.Linq;
using System.Transactions;
using Dapper;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using NNK.Messenger.Core;

namespace NNK.Messenger.Business.Tests
{
    [TestClass]
    public class FileStoreOperationsTest
    {
        public class DapperConnectionStringProvider : IDapperConnectionStringProvider
        {
            public string ConnectionString => "Data Source = 10.1.41.60; Initial Catalog = NNK.Messenger.Test; Integrated Security = False; User Id=test; Password=test; ";
        }

        [TestMethod]
        public void AddFile_Success()
        {
            var dp = new DapperConnectionStringProvider();

            var fso = new Dapper.FileStoreOperations(dp);

            var fileName = $"testfile_{Guid.NewGuid()}.test";

            var fileData = new byte[1];

            Guid? streamId=null;

            using (TransactionScope scope = new TransactionScope())
            {
                var fso1 = new Dapper. FileStoreOperations(dp);

                var testResult = fso1.AddFile(fileName, fileData);

                streamId = testResult.stream_id;

                Assert.IsNotNull(testResult);

                Assert.IsNotNull(testResult.stream_id);

                var test = fso1.ExecuteQuery(db => db.Query<dynamic>("select * from dbo.FileStore(nolock) where stream_id=@stream_id", new { stream_id= streamId }))?.FirstOrDefault();
                
                Assert.IsNotNull(test);

                Assert.AreEqual(test.stream_id, testResult.stream_id);

            }
            
            var test1 = fso.ExecuteQuery(db => db.Query<dynamic>("select * from dbo.FileStore(nolock) where stream_id=@stream_id", new { stream_id= streamId }))?.FirstOrDefault();

            Assert.IsNull(test1);

        }



        [TestMethod]
        public void DeleteFile_Success()
        {
            var dp = new DapperConnectionStringProvider();

            var fso = new Dapper.FileStoreOperations(dp);

            var test =
                fso.ExecuteQuery(db => db.Query<Guid>("select top 1 stream_id from dbo.FileStore(nolock)"))
                    ?.FirstOrDefault();

            Assert.IsNotNull(test);

            using (TransactionScope scope = new TransactionScope())
            {
                var fso1 = new Dapper.FileStoreOperations(dp);

                fso1.DeleteFile(test.Value);

                var test1 = fso1.ExecuteQuery(db => db.Query<Guid>("select top 1 stream_id from dbo.FileStore(nolock) where stream_id=@stream_id", new { stream_id = test}));

                Assert.IsTrue(test1 ==null || !test1.Any());

            }
            var test2 = fso.ExecuteQuery(db => db.Query<Guid>("select top 1 stream_id from dbo.FileStore(nolock) where stream_id=@stream_id", new { stream_id = test }));

            Assert.IsTrue(test2 != null && test2.Any());


        }
    }
}
