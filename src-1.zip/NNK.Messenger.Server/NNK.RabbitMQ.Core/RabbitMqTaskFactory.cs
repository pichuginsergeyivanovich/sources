﻿namespace NNK.RabbitMQ.Core
{
    public class RabbitMqTaskFactory
    {
        static RabbitMqTaskFactory _instance;

        static object _locker = new object();
        public static RabbitMqTaskFactory Instance
        {
            get
            {
                if (_instance != null)
                    return _instance;

                lock (_locker)
                {
                    if (_instance == null)
                        _instance = new RabbitMqTaskFactory();

                    return _instance;
                }
            }
        }

        public IRabbitMqTask DeserializeTask(byte[]buffer)
        {
            var bs = new RabbitMqTaskSerializer();

            return bs.Deserialize(buffer);
        }

        public byte[] SerializeTask(IRabbitMqTask task)
        {

            var bs = new RabbitMqTaskSerializer();

            return bs.Serialize(task);

        }
    }
}
