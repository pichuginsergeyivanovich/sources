﻿

using RabbitMQ.Client;

namespace NNK.RabbitMQ.Core
{
    public interface IRabbitMqConnectionFactoryProvider
    {
        ConnectionFactory CreateConnectionFactory();
    }
}
