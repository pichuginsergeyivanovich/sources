﻿namespace NNK.RabbitMQ.Core
{
    public class RabbitMqTaskSerializer:GenericSerializer<IRabbitMqTask>
    {
    }
}
