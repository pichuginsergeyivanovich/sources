﻿namespace NNK.RabbitMQ.Core
{
    public interface IRabbitMqTask
    {
        
    }
}
