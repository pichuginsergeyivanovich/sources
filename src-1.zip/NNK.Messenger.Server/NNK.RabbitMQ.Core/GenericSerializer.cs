﻿using System.IO;
using System.Runtime.Serialization.Formatters.Binary;

namespace NNK.RabbitMQ.Core
{
    public class GenericSerializer<T> 
    {
        public T Deserialize(byte[] message)
        {
            var binForm = new BinaryFormatter();

            using (var memStream = new MemoryStream())
            {
                memStream.Seek(0, SeekOrigin.Begin);

                memStream.Write(message, 0, message.Length);

                memStream.Position = 0;

                return (T)binForm.Deserialize(memStream);

            }
        }
        public byte[] Serialize(T task)
        {
            if (task == null)
                return null;

            var bf = new BinaryFormatter();

            using (var ms = new MemoryStream())
            {
                bf.Serialize(ms, task);

                return ms.ToArray();
            }

        }
    }
}
