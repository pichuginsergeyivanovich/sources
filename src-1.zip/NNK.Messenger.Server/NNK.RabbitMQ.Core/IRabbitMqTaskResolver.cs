﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using RabbitMQ.Client;
using RabbitMQ.Client.Events;

namespace NNK.RabbitMQ.Core
{
    public interface  IRabbitMqTaskResolver
    {
        void ResolveTask(object sender, BasicDeliverEventArgs ea);
        void ResolveTask(BasicGetResult result);
    }
}
