﻿using System;
using System.Threading;
using System.Threading.Tasks;
using NNK.Logging;
using RabbitMQ.Client;
using RabbitMQ.Client.Events;

namespace NNK.RabbitMQ.Core
{
    public class RabbitMqWorker
    {
        readonly IRabbitMqConnectionFactoryProvider _rabbitMqConnectionFactoryProvider;
        private readonly IRabbitMqTaskResolver _resolver;
        private readonly ILogger _logger;
        private readonly string _queue;

        public RabbitMqWorker(
            IRabbitMqConnectionFactoryProvider rabbitMqConnectionFactoryProvider, IRabbitMqTaskResolver resolver, ILogger logger, string queue){

            _rabbitMqConnectionFactoryProvider = rabbitMqConnectionFactoryProvider;

            _resolver = resolver;

            _logger = logger;

            _queue = queue;

        }
        /*
        private void SendPush(PushTask task)
        {

            if (!task.Party.Any())
                return;

            var pushOps = new PushOperations(_idops, _uops);

            var cert = File.ReadAllBytes(Properties.Settings.Default.certFile); 

            foreach (var u in task.Party)
            {
                try
                {

                   // var user = _uops.GetByName(u);

                   // var token = user.SignedPreKey;

//                    if(!_idops.IsDeviceTokenOnUser(user.UserID,token))
//                        continue;


                    _logger.Message($"try send push to user {u}");

                    Task.Factory.StartNew<Task>(async () =>
                    {
                        await pushOps.SendPushAsync(task.Text, u, cert, "",Properties.Settings.Default.ApsnServerEnvProductionOrSandbox, _logger);
                    });

                }
                catch (Exception ex)
                {
                    _logger.Error(ex);
                }
            }
        }*/
        public bool Stopped { get; set; }
        public void Run()
        {
            try
            {
                var factory = _rabbitMqConnectionFactoryProvider.CreateConnectionFactory();

                using (var connection = factory.CreateConnection())
                using (var channel = connection.CreateModel())
                {
                    channel.QueueDeclare(queue: _queue,
                        durable: true,
                        exclusive: false,
                        autoDelete: false,
                        arguments: null);

                    channel.BasicQos(prefetchSize: 0, prefetchCount: 1, global: false);

                    var consumer = new EventingBasicConsumer(channel);

                    consumer.Received += (model, ea) =>
                    {
                        try
                        {
                            
                            _resolver?.ResolveTask(model, ea);

                            channel.BasicAck(deliveryTag: ea.DeliveryTag, multiple: false);
                        }
                        catch (Exception ex)
                        {
                            _logger.Error(ex);
                            throw;
                        }
                    };

                    channel.BasicConsume(_queue, false, consumer);

                    //Console.ReadLine();

                    while (!Stopped)
                    {
                        Thread.Sleep(10000);
                    }
                }
            }

            catch (Exception ex)
            {
                _logger.Error(ex);
            }
        }

        public uint GetQueueTasks(string queueName)
        {
            var factory = _rabbitMqConnectionFactoryProvider.CreateConnectionFactory();
            uint count;
            using (var connection = factory.CreateConnection())
            using (var channel = connection.CreateModel())
            {
                QueueDeclareOk result = channel.QueueDeclarePassive(queueName);
                count = result != null ? result.MessageCount : 0;
            }
            return count;
        }
        public void RunOneByOne()
        {
            var factory = _rabbitMqConnectionFactoryProvider.CreateConnectionFactory();
            using (var connection = factory.CreateConnection())
            using (var channel = connection.CreateModel())
            {

                bool noAck = false;

                BasicGetResult result = channel.BasicGet(_queue, noAck);

                while (result != null)
                {
//
//                    var tasksCount = GetQueueTasks(_queue);
//
//                    _logger.Message("Queue tasks: " + tasksCount);

//                    IBasicProperties props = result.BasicProperties;

                    try
                    {
                        _resolver?.ResolveTask(result);
                    }
                    catch (Exception ex)
                    {
                        _logger.Error(ex);
                    }

                    channel.BasicAck(result.DeliveryTag, false);

                    Thread.Sleep(500);

                    result = channel.BasicGet(_queue, noAck);

                }
            }
        }
    
        
    }
}


