﻿using NNK.Logging;
using System;

namespace NNK.RabbitMQ.Core
{
    public class RabbitMqClient
    {
        private readonly IRabbitMqConnectionFactoryProvider _factoryProvider;

        private ILogger _logger;

        public RabbitMqClient()
        {
            
        }
        public RabbitMqClient(IRabbitMqConnectionFactoryProvider factoryProvider, ILogger logger)
        {
            _factoryProvider = factoryProvider;

            _logger = logger;
        }
        public void AddTask<T>(T task) where T: IRabbitMqTask
        {
            try {

                _logger.Message("try add task to push on rabbit");

                var factory = _factoryProvider.CreateConnectionFactory();

                using (var connection = factory.CreateConnection())
                using (var channel = connection.CreateModel())
                {
                    var gs = new GenericSerializer<T>();

                    var item = gs.Serialize(task);

                    channel.BasicPublish(
                        exchange: "mess_push_ex",
                        routingKey: "",
                        basicProperties: null,
                        body: item,
                        mandatory: false);
                }
            }
            catch(Exception ex)
            {
                _logger.Error(ex);
            }
        }
        public void AddTask<T>(T task, string queueExchange) where T : IRabbitMqTask
        {
            try
            {

                _logger.Message("try add task to push on rabbit");

                var factory = _factoryProvider.CreateConnectionFactory();

                using (var connection = factory.CreateConnection())
                using (var channel = connection.CreateModel())
                {
                    channel.QueueDeclare(queue: "media_p",
                      durable: true,
                      exclusive: false,
                      autoDelete: false,
                      arguments: null);


                    var properties = channel.CreateBasicProperties();
                    properties.Persistent = true;

                    var gs = new GenericSerializer<T>();

                    var item = gs.Serialize(task);

                    channel.BasicPublish(
                        exchange: queueExchange,
                        routingKey: "media_p",
                        basicProperties: properties,
                        body: item,
                        mandatory: false);
                }
            }
            catch (Exception ex)
            {
                _logger.Error(ex);
            }
        }
    }
}
