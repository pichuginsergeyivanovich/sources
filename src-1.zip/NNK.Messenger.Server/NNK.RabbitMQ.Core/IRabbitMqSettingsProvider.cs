﻿namespace NNK.RabbitMQ.Core
{
    public interface IRabbitMqSettingsProvider
    {
        string Host { get;  }

        string User { get;  }

        string Password { get;  }


    }
}
