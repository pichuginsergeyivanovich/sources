﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NNK.Messenger.Data
{
    public static class ExtensionMethods
    {
        public static string[] PartyAsArray(this Chat chat)
        {
            var chatPartyList =
                chat.Party.Split(new[] { "," }, StringSplitOptions.RemoveEmptyEntries)
                    .Select(i => i.Trim())
                    .ToArray();

            return chatPartyList;
        }
    }
}
