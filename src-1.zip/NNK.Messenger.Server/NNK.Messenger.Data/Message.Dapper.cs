﻿using Dapper.Contrib.Extensions;

namespace NNK.Messenger.Data
{
    [Table("Message")]
    public class MessageWrapper
    {
        [Key]
        public System.Guid ID { get; set; }
        public System.Guid ChatID { get; set; }
        public string Text { get; set; }
        public System.DateTime Created { get; set; }
        public string Author { get; set; }
        public bool? StatusSrvDelivered { get; set; }
        public bool? StatusDelivered { get; set; }
        public bool? StatusRead { get; set; }
    }
    
}