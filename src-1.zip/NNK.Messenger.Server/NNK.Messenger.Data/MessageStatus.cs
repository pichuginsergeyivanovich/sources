﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NNK.Messenger.Data
{
    public class MessageStatus
    {
        public Guid messageId { get; set; }

        public byte type { get; set; }

        public DateTime clientDate { get; set; }
        
        public string clientIp { get; set; }

        public string username { get; set; }

    }
}
