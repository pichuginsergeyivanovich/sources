﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NNK.Messenger.Data
{
    public class UserSession
    {
        public Guid ID { get; set; }

        public Guid ConnectionId { get; set; }

        public string Username { get; set; }
    }
}
