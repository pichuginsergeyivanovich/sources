﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Newtonsoft.Json.Linq;

namespace SqlCrypt.Tests
{
    [TestClass]
    public class UnitTest1
    {
        [TestMethod]
        public void SqlCrypt_IsBase64String_Success()
        {
            var res = SqlCrypt.IsBase64String("pr1NXA388sGFf5X6hhSW/SI1BKEXZoHX3HbQZDjZS+5tXP0reEJtfj0CQGT0hrYd");

            Assert.AreEqual(res,true);
        }
        [TestMethod]
        public void SqlCrypt_IsBase64String_Failed0()
        {
            var res = SqlCrypt.IsBase64String("Пользователь @putintest присоединился к чату");

            Assert.AreEqual(res, false);
        }
        [TestMethod]
        public void SqlCrypt_IsBase64String_Failed1()
        {
            var res = SqlCrypt.IsBase64String(null);

            Assert.AreEqual(res, false);
        }

        [TestMethod]
        public void SqlCrypt_IsBase64String_Failed2()
        {

            //var s=System.Convert.ToBase64String(new byte[] {65});

           // var bb = System.Convert.FromBase64String("Sefg");

           // var sbb = Encoding.UTF8.GetString(bb);

            var res = SqlCrypt.IsBase64String("null");

            Assert.AreEqual(res, false);
        }

        [TestMethod]
        public void SqlCrypt_IsBase64String_Failed3()
        {

            //var s=System.Convert.ToBase64String(new byte[] {65});

            // var bb = System.Convert.FromBase64String("Sefg");

            // var sbb = Encoding.UTF8.GetString(bb);

            var res = SqlCrypt.IsBase64String("Sefg");

            Assert.AreEqual(res, false);
        }

        [TestMethod]
        public void test()
        {
            var json= "[{\"name\": \"1524925329-0.jpg\", \"size\": 743522, \"type\": \"image/jpeg\", \"attachId\": 0}]";

            var pairs = json.Split(new[] {","}, StringSplitOptions.RemoveEmptyEntries);

            var typepairs=pairs
                .Where(i=>i.Trim()
                .StartsWith("\"type\":"))
                .Select(i=>i.Replace("\"type\":",""))
                .Select(i=>i.Replace("\"",""))
                .Select(i => i.Replace(" ", ""));


            /* var jobj = JArray.Parse(json);
 
             var l = new List<string>();
 
             foreach (JObject o in jobj)
             {
                 var tas = o.GetValue("type").Value<string>();
 
                 if (!string.IsNullOrEmpty(tas))
                     l.Add(tas);
             }
 
             return l.ToArray();*/

        }

    }
}
