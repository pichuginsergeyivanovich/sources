﻿using Ninject;
using NNK.Logging;
using NNK.Messenger.Business;
using NNK.Messenger.Core;
using NNK.RabbitMQ.Core;

namespace NNK.Messenger.QService
{

    public class NinjectResolver
    {
        private readonly IKernel _kernel;

        public NinjectResolver(IKernel kernel)
        {
            _kernel = kernel;

            AddBindings();

        }

        public IKernel GetKernel()
        {
            return _kernel;

        }

        private void AddBindings()
        {
            _kernel.Bind<ILogger>().To<ConsoleLogger>();

            _kernel.Bind<IChatOperations>().To<NNK.Messenger.Business.Dapper.ChatOperations>();

            _kernel.Bind<IUserOperations>().To<NNK.Messenger.Business.Dapper.UserOperations>();

            _kernel.Bind<IIdentityOperations>().To<NNK.Messenger.Business.Dapper.IdentityOperations>();

            _kernel.Bind<IRabbitMqSettingsProvider>().To<RabbitMqProjectSettingsProvider>();

            _kernel.Bind<IAttachmentOperations>().To<NNK.Messenger.Business.Dapper.AttachmentOperations>();

            _kernel.Bind<INotificationOperations>().To<NNK.Messenger.Business.Dapper.NotificationOperations>();

            _kernel.Bind<IPartyOperations>().To<NNK.Messenger.Business.Dapper.PartyOperations>();

            _kernel.Bind<IPushTaskFactory>().To<PushTaskFactory>();

            _kernel.Bind<IRabbitMqConnectionFactoryProvider>().To<RabbitMQ.Core.RabbitMqConnectionFactoryProvider>();

            _kernel.Bind<RabbitMqWorker>().ToSelf();

            //_kernel.Bind<PushOperations>().ToSelf();


            _kernel.Bind<IDapperConnectionStringProvider>()
                .To<DapperAspNetIdentityConnectionStringProvider>()
                .WhenInjectedExactlyInto<NNK.Messenger.Business.Dapper.UserOperations>();

            _kernel.Bind<IDapperConnectionStringProvider>().To<DapperConnectionStringProvider>();

        }
    }
}
