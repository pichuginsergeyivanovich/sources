﻿using Ninject;

namespace NNK.Messenger.QService
{
    public class NinjectDependencyResolverSingleton
    {
        private NinjectDependencyResolverSingleton()
        {

        }
        static object _locker = new object();

        static NinjectDependencyResolver _ResolverInstance;
        public static NinjectDependencyResolver ResolverInstance
        {
            get
            {
                if (_ResolverInstance != null)
                    return _ResolverInstance;

                lock (_locker)
                {
                    if (_ResolverInstance == null)
                    {
                        var kernel = new StandardKernel();

                        _ResolverInstance = new NinjectDependencyResolver(kernel);

                    }
                    return _ResolverInstance;
                }
            }
            
        }
    }
}
