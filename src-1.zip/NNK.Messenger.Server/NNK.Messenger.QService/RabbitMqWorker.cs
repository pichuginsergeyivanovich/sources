﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using NNK.Messenger.Business;
using NNK.Messenger.Core;
using NNK.RabbitMQ.Core;
using RabbitMQ.Client.Events;
using NNK.Logging;

namespace NNK.Messenger.QService
{
    public class RabbitMqWorker
    {
        private readonly IIdentityOperations _idops;
        private readonly IUserOperations _uops;
        readonly IRabbitMqConnectionFactoryProvider _rabbitMqConnectionFactoryProvider;
        private readonly ILogger _logger;
        private readonly IPushTaskFactory _ptf;

        public RabbitMqWorker(
            IRabbitMqConnectionFactoryProvider rabbitMqConnectionFactoryProvider,
            ILogger logger,
            IPushTaskFactory ptf,
            IIdentityOperations idops,
            IUserOperations uops
        ){
            _rabbitMqConnectionFactoryProvider = rabbitMqConnectionFactoryProvider;

            _logger = logger;

            _ptf = ptf;

            _idops = idops;

            _uops = uops;
        }

        private void SendPush(PushTask task)
        {

            if (!task.Party.Any())
                return;

            var pushOps = new PushOperations(_idops, _uops);

            var cert = File.ReadAllBytes(Properties.Settings.Default.certFile); 

            foreach (var u in task.Party)
            {
                try
                {

                   // var user = _uops.GetByName(u);

                   // var token = user.SignedPreKey;

//                    if(!_idops.IsDeviceTokenOnUser(user.UserID,token))
//                        continue;


                    _logger.Message($"try send push to user {u}");

                    Task.Factory.StartNew<Task>(async () =>
                    {
                        await pushOps.SendPushAsync(task.Text, u, cert, "",Properties.Settings.Default.ApsnServerEnvProductionOrSandbox, _logger);
                    });

                }
                catch (Exception ex)
                {
                    _logger.Error(ex);
                }
            }
        }
        public bool Stopped { get; set; }
        public void Run()
        {
            try
            {
                var factory = _rabbitMqConnectionFactoryProvider.CreateConnectionFactory();

                using (var connection = factory.CreateConnection())
                using (var channel = connection.CreateModel())
                {
                    channel.QueueDeclare(queue: "mess_push",
                        durable: true,
                        exclusive: false,
                        autoDelete: false,
                        arguments: null);

                    var consumer = new EventingBasicConsumer(channel);

                    consumer.Received += (model, ea) =>
                    {
                        try
                        {
                            _logger.Message("work arrived");

                            var task = RabbitMqTaskFactory.Instance.DeserializeTask(ea.Body) as RabbitMqTask;

                            PushTask pushTask = null;

                            if (task?.TaskType == PushTaskType.PUSHTASK_ADDMESSAGE)
                            {
                                pushTask = _ptf.From(task as AddMessagePushTask);
                                _logger.Message("work arrived is push task add message ");
                            }
                            else if (task?.TaskType == PushTaskType.PUSHTASK_CREATEGROUPCHAT)
                            {
                                pushTask = _ptf.From(task as CreateGroupChatPushTask);
                                _logger.Message("work arrived is push task create group chat");
                            }
                            else if (task?.TaskType == PushTaskType.PUSHTASK_ADDMESSAGE2)
                            {
                                pushTask = _ptf.From(task as AddMessagePushTask2);
                                _logger.Message("work arrived is push task add message 2 ");
                            }
                            if (pushTask == null)
                                return;


                            SendPush(pushTask);

                        }
                        catch (Exception ex)
                        {
                            _logger.Error(ex);
                        }
                    };
                    channel.BasicConsume("mess_push", true, "ctag", true, false, null, consumer);
                    //channel.BasicConsume("mess_push", false, null, true, false, null, consumer);



                    //Console.ReadLine();

                    while (!Stopped)
                    {
                        Thread.Sleep(10000);
                    }
                }
            }

            catch (Exception ex)
            {
                _logger.Error(ex);
            }
        }
    }
}


