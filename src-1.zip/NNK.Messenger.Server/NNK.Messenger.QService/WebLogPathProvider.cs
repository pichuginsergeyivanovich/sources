﻿using NNK.Logging;

namespace NNK.Messenger.QService
{
    public class WebLogPathProvider : ILogParametersProvider
    {
        public string LogPath => Properties.Settings.Default.LogFile;
    }
}
