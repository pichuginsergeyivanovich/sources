﻿using NNK.RabbitMQ.Core;
using RabbitMQ.Client;


namespace NNK.Messenger.QService
{
    public class RabbitMqConnectionFactoryProvider: IRabbitMqConnectionFactoryProvider
    {
        IRabbitMqSettingsProvider _settingsProvider;

        public RabbitMqConnectionFactoryProvider(IRabbitMqSettingsProvider settingsProvider)
        {
            _settingsProvider = settingsProvider;
        }

        public ConnectionFactory CreateConnectionFactory()
        {
            var factory = new ConnectionFactory()
            {
                HostName = _settingsProvider.Host,
                UserName = _settingsProvider.User,
                Password = _settingsProvider.Password,
                AutomaticRecoveryEnabled = true
            };

            return factory;
        }
    }
}
