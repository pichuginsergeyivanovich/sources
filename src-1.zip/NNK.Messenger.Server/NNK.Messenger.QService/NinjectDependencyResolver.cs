﻿using Ninject;
using NNK.Logging;
using NNK.Messenger.Business;
using NNK.Messenger.Core;
using NNK.RabbitMQ.Core;

namespace NNK.Messenger.QService
{
    public class NinjectDependencyResolver:AbstractNinjectDependencyResolver 
    {
        public NinjectDependencyResolver(IKernel kernelParam)
            :base(kernelParam){
        }

        protected override void AddBindings()
        {
            //kernel.Bind<ILogger>().To<ConsoleLogger>();
            kernel.Bind<ILogger>().ToMethod((i) => TextFileLoggerSingleton.Instanse);

            kernel.Bind<IChatOperations>().To<NNK.Messenger.Business.Dapper.ChatOperations>();

            kernel.Bind<IUserOperations>().To<NNK.Messenger.Business.Dapper.UserOperations>();

            kernel.Bind<IIdentityOperations>().To<NNK.Messenger.Business.Dapper.IdentityOperations>();

            kernel.Bind<IRabbitMqSettingsProvider>().To<RabbitMqProjectSettingsProvider>();

            kernel.Bind<IAttachmentOperations>().To<NNK.Messenger.Business.Dapper.AttachmentOperations>();

            kernel.Bind<INotificationOperations>().To<NNK.Messenger.Business.Dapper.NotificationOperations>();

            kernel.Bind<IPartyOperations>().To<NNK.Messenger.Business.Dapper.PartyOperations>();

            kernel.Bind<IPushTaskFactory>().To<PushTaskFactory>();

            kernel.Bind<IRabbitMqConnectionFactoryProvider>().To<RabbitMQ.Core.RabbitMqConnectionFactoryProvider>();

            kernel.Bind<RabbitMqWorker>().ToSelf();

            //_kernel.Bind<PushOperations>().ToSelf();


            kernel.Bind<IDapperConnectionStringProvider>()
                .To<DapperAspNetIdentityConnectionStringProvider>()
                .WhenInjectedExactlyInto<NNK.Messenger.Business.Dapper.UserOperations>();

            kernel.Bind<IDapperConnectionStringProvider>().To<DapperConnectionStringProvider>();

        }
    }
}


                              
                              
                              
                              
                              