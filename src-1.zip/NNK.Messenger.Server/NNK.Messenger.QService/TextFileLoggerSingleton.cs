﻿using NNK.Logging.Loggers;
using NNK.Messenger.Business;
using TextFileLogger = NNK.Logging.Loggers.TextFileLogger;

namespace NNK.Messenger.QService
{
    public class TextFileLoggerSingleton
    {
        static readonly object _locker=new object();

        private static TextFileLogger _instanse;

        public static TextFileLogger Instanse
        {
            get
            {
//                if(_instanse!=null)
//                    return _instanse;

                lock (_locker)
                {
                    _instanse=new TextFileLogger(new WebLogPathProvider());

                    return _instanse;
                }
            }
        }
    }
}
