﻿using NNK.RabbitMQ.Core;

namespace NNK.Messenger.QService
{
    public class RabbitMqProjectSettingsProvider : IRabbitMqSettingsProvider
    {
        public string Host => Properties.Settings.Default.rabbitMqServerIp;

        public string Password => Properties.Settings.Default.rabbitMqServerPassword;

        public string User => Properties.Settings.Default.rabbitMqServerUserName;
    }
}
