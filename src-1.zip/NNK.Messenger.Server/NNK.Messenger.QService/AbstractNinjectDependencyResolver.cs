﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Ninject;

namespace NNK.Messenger.QService
{

    public abstract class AbstractNinjectDependencyResolver //: IDependencyResolver
    {
        protected IKernel kernel;

        protected AbstractNinjectDependencyResolver(IKernel kernelParam)
        {
            kernel = kernelParam;

            AddBindings();
        }

        public T GetService<T>()
        {
            return kernel.TryGet<T>();
        }

        public object GetService(Type serviceType)
        {
            return kernel.TryGet(serviceType);
        }

        public IEnumerable<object> GetServices(Type serviceType)
        {
            return kernel.GetAll(serviceType);
        }

        protected abstract void AddBindings();

    }

}
