﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.ServiceProcess;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace NNK.Messenger.QService
{
    static class Program
    {
        /// <summary>
        /// Главная точка входа для приложения.
        /// </summary>
       // [STAThread]
        static void Main(string[] args)
        {

            if (args.Count() > 0 &&
                !string.IsNullOrEmpty(args[0]) &&
                args[0].ToLowerInvariant() == "-runasprocess"
            )
            {
                Console.WriteLine("Service is starting in debug mode. ");



                var t = new Thread(() =>
                {

                    var worker = NinjectDependencyResolverSingleton.ResolverInstance.GetService<RabbitMqWorker>();

                    worker.Run();
                });

                t.Start();

                t.Join();

                Console.ReadLine();
            }
            else
            {

                ServiceBase[] ServicesToRun;
                ServicesToRun = new ServiceBase[]
                {
                                new QService()
                };
                ServiceBase.Run(ServicesToRun);
            }

        }
    }
}