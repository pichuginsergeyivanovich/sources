﻿using NNK.Messenger.Core;

namespace NNK.Messenger.QService
{
    public class DapperAspNetIdentityConnectionStringProvider : IDapperConnectionStringProvider
    {
        //public string ConnectionString => "Data Source = 10.1.41.60; Initial Catalog = AspNet.Identity.Test; Integrated Security = False; User Id=test; Password=test;";
        public string ConnectionString => Properties.Settings.Default.AspNetIdentityConnectionString;

    }
}
