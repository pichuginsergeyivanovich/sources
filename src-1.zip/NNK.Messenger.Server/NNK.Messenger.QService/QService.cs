﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Linq;
using System.ServiceProcess;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace NNK.Messenger.QService
{
    public partial class QService : ServiceBase
    {
        public QService()
        {
            InitializeComponent();
        }

        private Thread t;
        protected override void OnStart(string[] args)
        {
            t = new Thread(() =>
            {
                var worker = NinjectDependencyResolverSingleton.ResolverInstance.GetService<RabbitMqWorker>();

                worker.Stopped = false;

                worker.Run();
            });

            t.Start();
//
//            t.Join();
//
//            Console.ReadLine();

        }

        protected override void OnStop()
        {
            var worker = NinjectDependencyResolverSingleton.ResolverInstance.GetService<RabbitMqWorker>();

            worker.Stopped = true;

            t.Join();

            //
        }
    }
}
