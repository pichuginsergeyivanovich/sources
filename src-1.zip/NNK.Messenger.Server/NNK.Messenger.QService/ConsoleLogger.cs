﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using NNK.Messenger.Core;
using NNK.Logging;

namespace NNK.Messenger.QService
{
    public class ConsoleLogger : ILogger
    {
        public void Error(Exception ex)
        {
            WriteLine("{0} - Error - {1}", DateTime.Now.ToUniversalTime(), ex);
        }

        public void Message(string text)
        {
            WriteLine("{0} - Info - {1}", DateTime.Now.ToUniversalTime(), text);
        }

        void WriteLine(string format, params object[] args)
        {
            Console.WriteLine(format, args);

        }

    }
}
