﻿namespace NNK.Messenger.Core
{
    public enum PushTaskType:byte
    {
        PUSHTASK_ADDMESSAGE=1,
        PUSHTASK_CREATEGROUPCHAT = 2,
        PUSHTASK_ADDMESSAGE2 = 3,
    }
}
