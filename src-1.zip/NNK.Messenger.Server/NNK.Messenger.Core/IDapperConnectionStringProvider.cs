﻿namespace NNK.Messenger.Core
{
    public interface IDapperConnectionStringProvider
    {
        string ConnectionString { get; }
    }
}