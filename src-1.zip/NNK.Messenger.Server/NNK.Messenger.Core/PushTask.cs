﻿using System;

namespace NNK.Messenger.Core
{
    [Serializable]
    public class PushTask 
    {
        public string[] Party { get; set; }
        public string Text { get; set; }

        public string Queue { get; set; }
        
    }
}
