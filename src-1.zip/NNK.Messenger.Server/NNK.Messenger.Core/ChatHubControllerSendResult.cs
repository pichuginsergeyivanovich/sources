﻿using System;
using System.Collections.Generic;

namespace NNK.Messenger.Core
{
    public class ChatHubControllerSendResult
    {
        public ChatHubControllerSendResult()
        {
            Errors=new List<string>();
        }
        public bool IsNewChat { get; set; }
        public Guid ChatId { get; set; }
        public string[] connectedPartyIds { get; set; }
        public ChatMessage Message { get; set; }

        public bool IsError { get; set; }
        public List<string> Errors { get; set; }
        
    }
}
