﻿using System;

namespace NNK.Messenger.Core
{
    public class ChatMessage
    {
        public ChatMessage(string user, string message, string party, string chatId)
        {
            this.User = user;

            this.Message = message;

            this.Party = party;

            this.ChatId = chatId;

            this.Created=DateTime.UtcNow;

        }


        public Guid SID { get; set; }

        public string User { get; set; }

        public string Message { get; set; }

        public string Party { get; set; }

        public string ChatId { get; set; }

        public DateTime Created { get; set; }

        public string Attachments { get; set; }

        public string ChkSum { get; set; }

        public string MsgChkSum { get; set; }

        public string Metadata { get; set; }

        public string IV { get; set; }

        public string Soul { get; set; }

        public bool Read { get; set; }

        public bool Delivered { get; set; }

        public bool SrvDelivered { get; set; }

        public bool IsNewChat { get; set; }

        public bool? IsNewChatHidden { get; set; }
        public Guid NewChatId { get; set; }

        public bool? IsPlain { get; set; } 
    }
}
