﻿using System;

namespace NNK.Messenger.Core
{
    [Serializable]
    public class CreateGroupChatPushTask : RabbitMqTask
    {
        public CreateGroupChatPushTask(string chatId)
        {
            ChatId = chatId;
        }
        public string ChatId { get; set; }
        public override PushTaskType TaskType => PushTaskType.PUSHTASK_CREATEGROUPCHAT;
    }

    
}
