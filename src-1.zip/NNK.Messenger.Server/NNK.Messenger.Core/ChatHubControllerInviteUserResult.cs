﻿namespace NNK.Messenger.Core
{
    public class ChatHubControllerInviteUserResult
    {
        public string[] ConnectionParty { get; set; }
        public ChatMessage Message { get; set; }
    }
}
