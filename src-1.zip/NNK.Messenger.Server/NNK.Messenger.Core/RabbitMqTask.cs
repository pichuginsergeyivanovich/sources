﻿using System;
using NNK.RabbitMQ.Core;

namespace NNK.Messenger.Core
{
    [Serializable]
    public class RabbitMqTask: IRabbitMqTask
    {
        public virtual PushTaskType TaskType { get; }
    }
}
