﻿using System;

namespace NNK.Messenger.Core
{
    [Serializable]
    public class AddMessagePushTask:RabbitMqTask
    {
        public AddMessagePushTask(string user, string chatId)
        {
            User = user;
            ChatId = chatId;
        }
        public string User { get; set; }
        public string ChatId { get; set; }
        public override PushTaskType TaskType => PushTaskType.PUSHTASK_ADDMESSAGE;
    }

    
}
