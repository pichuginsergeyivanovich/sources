﻿namespace NNK.Messenger.Core
{
    public class ChatUser
    {
        public string ConnectionId { get; set; }
        public string Name { get; set; }
    }
}
