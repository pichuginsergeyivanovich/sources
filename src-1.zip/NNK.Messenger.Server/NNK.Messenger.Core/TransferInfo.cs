﻿using System;

namespace NNK.Messenger.Core
{
    public class TransferInfo
    {
        public string Filename { get; set; }

        public string SessionId { get; set; }

        public int Offset { get; set; }

        public string Path { get; set; }

        public ulong Size { get; set; }
        public string Type { get; set; }
        public string Message { get; set; }
        public Guid Sid { get; set; }

        public bool Complete => (ulong)(Offset) == Size;
    }
}
