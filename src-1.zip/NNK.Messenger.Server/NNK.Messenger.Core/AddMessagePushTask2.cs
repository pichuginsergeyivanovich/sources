﻿using System;

namespace NNK.Messenger.Core
{
    [Serializable]
    public class AddMessagePushTask2:RabbitMqTask
    {
        public AddMessagePushTask2(string user, string chatId, string text)
        {
            User = user;
            ChatId = chatId;
            Text = text;
        }
        public string User { get; set; }
        public string ChatId { get; set; }

        public string Text { get; set; }
        public override PushTaskType TaskType => PushTaskType.PUSHTASK_ADDMESSAGE2;
    }

    
}
