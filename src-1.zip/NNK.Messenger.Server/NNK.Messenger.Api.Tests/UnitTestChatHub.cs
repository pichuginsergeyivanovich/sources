﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Dynamic;
using System.Linq;
using System.Security.Principal;
using System.Text;
using System.Threading.Tasks;
using Microsoft.AspNet.Identity;
using Microsoft.AspNet.SignalR;
using Microsoft.AspNet.SignalR.Hubs;
using Microsoft.Owin;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Moq;
using Newtonsoft.Json.Linq;
using NNk.Messenger.Api.Hubs;
using NNk.Messenger.Api.Providers;
using NNK.Beeline.Services.Business.Data;
using NNK.Beeline.Services.Business.Providers;
using NNK.Beeline.Services.Business.Services;
using NNK.Beeline.Services.Data;
using NNK.Messenger.AspNetIdentity;
using NNK.Messenger.Business;
using NNK.Messenger.Business.Dapper;
using NNK.Messenger.Core;
using NNK.Messenger.Data;
using ILogger=NNK.Messenger.Core.ILogger;


namespace NNK.Messenger.Api.Tests
{
    [TestClass]
    public class UnitTestChatHub
    {
        private ChatHub CreateChatHubWithClients(IMock<IHubCallerConnectionContext<dynamic>> mockClients, string user="ccc", Mock<ISmsServiceOperations>  fakeSmsoMock =null, IDataStoreOps dataStoreOps=null)
        {

            var userStore = new Mock<IUserStore<User, int>>();
            var manager = new UserManager<User, int>(userStore.Object);

            var owinMock = new Mock<IOwinContext>();
            //var context = new Mock<HttpContextBase>();
            var mockIdentity = new Mock<IIdentity>();
            //context.SetupGet(x => x.User.Identity).Returns(mockIdentity.Object);  
            owinMock.SetupGet(i => i.Request.User.Identity).Returns(mockIdentity.Object);
            

            mockIdentity.SetupGet(x => x.Name).Returns(user);
            var dp = new DapperConnectionStringProvider();
            var idp = new DapperAspNetIdentityConnectionStringProvider();
            IPartyOperations pops = new PartyOperations(dp);
            IChatOperations cops = new ChatOperations(dp,pops ); //Mock<NNK.Messenger.Business.IChatOperations>();
            IAttachMetadataOperations amops = new AttachMetadataOperations(dp);
            IMessageOperations mo = new MessageOperations(dp,cops); //Mock<NNK.Messenger.Business.IMessageOperations>();
            IUserOperations uo = new UserOperations(idp);
            IOperationsOperations oops = new OperationsOperations(dp);
            IFileStoreOperations fops = new FileStoreOperations(dp);
            IAttachmentOperations aops = new AttachmentOperations(fops,dp);
            INotificationOperations nops = new NotificationOperations(dp);
            IInviteOperations iops = new InviteOperations(dp);
            IIdentityOperations idops = new IdentityOperations(dp);
            PushOperations puops = new PushOperations(idops, uo);


            if (dataStoreOps != null)
            {
                cops = dataStoreOps.cops;
                amops = dataStoreOps.amops;
                mo = dataStoreOps.mo;
                uo = dataStoreOps.uo;
                oops = dataStoreOps.oops;
                aops = dataStoreOps.aops;
                fops = dataStoreOps.fops;
                nops = dataStoreOps.nops;
                pops = dataStoreOps.pops;
                iops = dataStoreOps.iops;
            }

            //var uoMock = new Mock<NNK.Messenger.Business.IUserOperations>();
            var smsoMock = new Mock<ISmsServiceOperations>();
            var smstrMock = new Mock<ISmsTaskRepository>();
            var espMock = new Mock<IExchangeServiceProvider>();
            //var manager = ApplicationUserManager.Create(new IdentityFactoryOptions<ApplicationUserManager>(), owinMock.Object);
            var loggerMock = new Mock<ILogger>();
            ICryptoOperations crops = new CryptoOperations(loggerMock.Object);

            const string connectionId = "1";
            var request = new Mock<IRequest>();
            request.Setup(s => s.User.Identity.Name).Returns(user);
            request.Setup(s => s.User.Identity.IsAuthenticated).Returns(true);
            request.SetupGet(i => i.Environment).Returns(new Dictionary<string, object>() { { "server.RemoteIpAddress", "10.1.1.1" } });
            var mockHubCallerContext = new Mock<HubCallerContext>(request.Object, connectionId);
            mockHubCallerContext.Setup(r => r.Request).Returns(request.Object);
            mockHubCallerContext.Setup(r => r.ConnectionId).Returns(connectionId);

            if (fakeSmsoMock != null)
                smsoMock = fakeSmsoMock;
                
            var hub = new ChatHub(
                loggerMock.Object,
                crops,
                aops,
                fops,
                nops,
                pops,
                cops,
                amops,
                mo,
                uo,
                owinMock.Object,
                oops,
                iops,
                manager,
                smsoMock.Object,
                espMock.Object,
                ChatUsersHelper.Instance,
                idops,
                puops)
            {
                Clients = mockClients.Object,
                Context = mockHubCallerContext.Object
            };

            var hc = hub.GetController();

            hc.SetupHubCallerConnectionContext(() => hub.Clients);

            hc.SetupHubCallerContext(() => hub.GetContext());

            return hub;
        }

        [TestMethod]
        public async Task ChatHub_Ping()
        {

            var userStore = new Mock<IUserStore<NNK.Messenger.AspNetIdentity.User, int>>();
            var manager = new UserManager<User, int>(userStore.Object);

            var owinMock = new Mock<IOwinContext>();
            //var context = new Mock<HttpContextBase>();
            var mockIdentity = new Mock<IIdentity>();
            //context.SetupGet(x => x.User.Identity).Returns(mockIdentity.Object);  
            owinMock.SetupGet(i => i.Request.User.Identity).Returns(mockIdentity.Object);
            mockIdentity.SetupGet(x => x.Name).Returns("test_name");

            //var manager = ApplicationUserManager.Create(new IdentityFactoryOptions<ApplicationUserManager>(), owinMock.Object);
            
            //context that contains the client connections
            var mockClients = new Mock<IHubCallerConnectionContext<dynamic>>();
            //make the hub believe it has actual clients


            //create a mock of the client contract, this is the interface that defines what methods are available for clients
            //var caller = new Mock<IClientContract>();
           
            //set the mock up so that the available method has restrictions on parameters
            //client.Setup(m => m.getAllUsers(It.IsAny<vw_User[]>()));
            //caller.Setup(m => m.ping(It.IsAny<bool>())).Verifiable();
            //caller.Setup(m => m.ping(true)).Verifiable();
            var isSendMessageCalled = false;
            dynamic caller = new ExpandoObject();
            caller.ping = new Func<bool, Task>(async (flag) =>
            {
                await Task.Run(() => { isSendMessageCalled = true; });

            });

            //all.Setup(m => m.broadcastMessage(It.IsAny<string>(), It.IsAny<string>())).Verifiable();
            mockClients.Setup(m => m.Caller).Returns((ExpandoObject) caller);

            var hub = CreateChatHubWithClients(mockClients, "ccc", null, new DataStoreOps());


            var res = await hub.Ping();


            //Thread.Sleep(500);
            //or testMethod.Wait();


            Assert.IsTrue(isSendMessageCalled);


            //caller.VerifyAll();

        }

        [TestMethod]
        public async Task ChatHub_OnConnected()
        {

            var userStore = new Mock<IUserStore<NNK.Messenger.AspNetIdentity.User, int>>();
            var manager = new UserManager<User, int>(userStore.Object);

            var owinMock = new Mock<IOwinContext>();
            //var context = new Mock<HttpContextBase>();
            var mockIdentity = new Mock<IIdentity>();
            //context.SetupGet(x => x.User.Identity).Returns(mockIdentity.Object);  
            owinMock.SetupGet(i => i.Request.User.Identity).Returns(mockIdentity.Object);
            mockIdentity.SetupGet(x => x.Name).Returns("test_name");
            //var manager = ApplicationUserManager.Create(new IdentityFactoryOptions<ApplicationUserManager>(), owinMock.Object);
            //context that contains the client connections
            var mockClients = new Mock<IHubCallerConnectionContext<dynamic>>();

            //make the hub believe it has actual clients
            //create a mock of the client contract, this is the interface that defines what methods are available for clients
            //var caller = new Mock<IClientContract>();

            //set the mock up so that the available method has restrictions on parameters
            //client.Setup(m => m.getAllUsers(It.IsAny<vw_User[]>()));
            //caller.Setup(m => m.ping(It.IsAny<bool>())).Verifiable();
            //caller.Setup(m => m.ping(true)).Verifiable();
            object isOnConnectedCalled = null;
            object isOnUserConnectedCalled = null;

            dynamic caller = new ExpandoObject();

            caller.onConnected = new Action<object>((flag) =>
            {
                isOnConnectedCalled = flag;
            });

            dynamic allExcept = new ExpandoObject();
            allExcept.onUserConnected = new Action<object>((param) =>
            {
                isOnUserConnectedCalled = param;
            });


            //all.Setup(m => m.broadcastMessage(It.IsAny<string>(), It.IsAny<string>())).Verifiable();
            mockClients.Setup(m => m.Caller).Returns((ExpandoObject) caller);
            mockClients.Setup(m => m.AllExcept(It.IsAny<string>())).Returns((ExpandoObject) allExcept);
            //hub.Send("TestUser", "TestMessage");
            //all.VerifyAll();


            //owinMock.SetupGet(i => i.Request.User.Identity.Name).Returns("test");
            //owinMock.Setup(i => i.Request.User.Identity.GetUserName()).Returns("test");

            //make the all property of the clients return an instance that implements the iclientcontract
            //mockClients.Setup(m => m.All).Returns(client.Object);

            //mockClients.Setup(m => m.Caller).Returns(client.Object);

            //string user = Context.User.Identity.GetUserName();

            //TextFileLoggerSingleton.Instanse.Message($"ping called with user:{user}");

            //await Clients.Caller.ping(true);

            //uoMock.Setup(m => m.GetListForSyncAsync(null)).Returns(new Task<vw_User[]>(()=>new[] { new vw_User()}));
           
            var hub = CreateChatHubWithClients(mockClients, "ccc", null, new DataStoreOps());

            await hub.OnConnected();


            //Thread.Sleep(500);
            //or testMethod.Wait();


            Assert.IsTrue(
            (isOnConnectedCalled.GetType()
                .GetProperty("connectionId")?.GetValue(isOnConnectedCalled)
                .Equals("1")).Value);
            Assert.IsTrue(
                (isOnConnectedCalled.GetType().GetProperty("userName")?.GetValue(isOnConnectedCalled).Equals("ccc"))
                .Value);


            //caller.VerifyAll();

        }

        [TestMethod]
        public async Task ChatHub_OnDisconnected()
        {
            var userStore = new Mock<IUserStore<NNK.Messenger.AspNetIdentity.User, int>>();
            var manager = new UserManager<User, int>(userStore.Object);

            var owinMock = new Mock<IOwinContext>();
            //var context = new Mock<HttpContextBase>();
            var mockIdentity = new Mock<IIdentity>();
            //context.SetupGet(x => x.User.Identity).Returns(mockIdentity.Object);  
            owinMock.SetupGet(i => i.Request.User.Identity).Returns(mockIdentity.Object);
            mockIdentity.SetupGet(x => x.Name).Returns("test_name");

            
            //var manager = ApplicationUserManager.Create(new IdentityFactoryOptions<ApplicationUserManager>(), owinMock.Object);



            //context that contains the client connections
            var mockClients = new Mock<IHubCallerConnectionContext<dynamic>>();



            //make the hub believe it has actual clients


            //create a mock of the client contract, this is the interface that defines what methods are available for clients
            //var caller = new Mock<IClientContract>();

            //set the mock up so that the available method has restrictions on parameters
            //client.Setup(m => m.getAllUsers(It.IsAny<vw_User[]>()));
            //caller.Setup(m => m.ping(It.IsAny<bool>())).Verifiable();
            //caller.Setup(m => m.ping(true)).Verifiable();
            object isOnDisconnectedCalled = null;


            dynamic allExcept = new ExpandoObject();
            allExcept.onUserDisconnected = new Action<object>((param) =>
            {
                isOnDisconnectedCalled = param;
            });


            //all.Setup(m => m.broadcastMessage(It.IsAny<string>(), It.IsAny<string>())).Verifiable();
            //mockClients.Setup(m => m.Caller).Returns((ExpandoObject)allExcept);
            mockClients.Setup(m => m.AllExcept(It.IsAny<string>())).Returns((ExpandoObject)allExcept);
            //hub.Send("TestUser", "TestMessage");
            //all.VerifyAll();


            //owinMock.SetupGet(i => i.Request.User.Identity.Name).Returns("test");
            //owinMock.Setup(i => i.Request.User.Identity.GetUserName()).Returns("test");

            //make the all property of the clients return an instance that implements the iclientcontract
            //mockClients.Setup(m => m.All).Returns(client.Object);

            //mockClients.Setup(m => m.Caller).Returns(client.Object);

            //string user = Context.User.Identity.GetUserName();

            //TextFileLoggerSingleton.Instanse.Message($"ping called with user:{user}");

            //await Clients.Caller.ping(true);

            //uoMock.Setup(m => m.GetListForSyncAsync(null)).Returns(new Task<vw_User[]>(()=>new[] { new vw_User()}));


            var hub = CreateChatHubWithClients(mockClients, "ccc", null, new DataStoreOps());

            await hub.OnDisconnected(true);


            //Thread.Sleep(500);
            //or testMethod.Wait();


            Assert.IsTrue(
            (isOnDisconnectedCalled.GetType()
                .GetProperty("connectionId")?.GetValue(isOnDisconnectedCalled)
                .Equals("1")).Value);

        }

        [TestMethod]
        public async Task ChatHub_Token_Success()
        {

            var userStore = new Mock<IUserStore<NNK.Messenger.AspNetIdentity.User, int>>();
            var manager = new UserManager<User, int>(userStore.Object);

            var owinMock = new Mock<IOwinContext>();
            //var context = new Mock<HttpContextBase>();
            var mockIdentity = new Mock<IIdentity>();
            //context.SetupGet(x => x.User.Identity).Returns(mockIdentity.Object);  
            owinMock.SetupGet(i => i.Request.User.Identity).Returns(mockIdentity.Object);
            mockIdentity.SetupGet(x => x.Name).Returns("test_name");

            //var manager = ApplicationUserManager.Create(new IdentityFactoryOptions<ApplicationUserManager>(), owinMock.Object);



            //context that contains the client connections
            var mockClients = new Mock<IHubCallerConnectionContext<dynamic>>();



            //make the hub believe it has actual clients


            //create a mock of the client contract, this is the interface that defines what methods are available for clients

            //set the mock up so that the available method has restrictions on parameters
            //client.Setup(m => m.getAllUsers(It.IsAny<vw_User[]>()));
            //caller.Setup(m => m.ping(It.IsAny<bool>())).Verifiable();
            //caller.Setup(m => m.ping(true)).Verifiable();
            object is_Token_Called = null;


            dynamic caller = new ExpandoObject();
            caller.getToken = new Func<string,Task>(
                async (param) =>
                {
                    await Task.Run(() => { is_Token_Called = param; });
                    
            });

            mockClients.Setup(m => m.Caller).Returns((ExpandoObject)caller);


            var hub = CreateChatHubWithClients(mockClients, "ccc", null, new DataStoreOps());


            await hub.Token("ccc", "ccc");

            var res = JObject.Parse(is_Token_Called.ToString());

            Assert.IsNotNull(is_Token_Called);
            Assert.IsTrue(!string.IsNullOrEmpty(is_Token_Called.ToString()));
            Assert.IsNotNull(res);
            Assert.IsNotNull(res.GetValue("access_token"));
            

            //caller.VerifyAll();

        }

        [TestMethod]
        public async Task ChatHub_Token_Failed_InvalidCredentials()
        {

            var userStore = new Mock<IUserStore<NNK.Messenger.AspNetIdentity.User, int>>();
            var manager = new UserManager<User, int>(userStore.Object);

            var owinMock = new Mock<IOwinContext>();
            //var context = new Mock<HttpContextBase>();
            var mockIdentity = new Mock<IIdentity>();
            //context.SetupGet(x => x.User.Identity).Returns(mockIdentity.Object);  
            owinMock.SetupGet(i => i.Request.User.Identity).Returns(mockIdentity.Object);
            mockIdentity.SetupGet(x => x.Name).Returns("test_name");
            //var manager = ApplicationUserManager.Create(new IdentityFactoryOptions<ApplicationUserManager>(), owinMock.Object);
            //context that contains the client connections
            var mockClients = new Mock<IHubCallerConnectionContext<dynamic>>();
            //make the hub believe it has actual clients
            
            //create a mock of the client contract, this is the interface that defines what methods are available for clients
            //var caller = new Mock<IClientContract>();
            //set the mock up so that the available method has restrictions on parameters
            //client.Setup(m => m.getAllUsers(It.IsAny<vw_User[]>()));
            //caller.Setup(m => m.ping(It.IsAny<bool>())).Verifiable();
            //caller.Setup(m => m.ping(true)).Verifiable();
            object is_Token_Called = null;


            dynamic caller = new ExpandoObject();
            caller.getToken = new Func<string, Task>(
                async (param) =>
                {
                    await Task.Run(() => { is_Token_Called = param; });

                });

            mockClients.Setup(m => m.Caller).Returns((ExpandoObject)caller);

            var hub = CreateChatHubWithClients(mockClients, "ccc", null, new DataStoreOps());


            await hub.Token("unknown", "undefined");

            var res = JObject.Parse(is_Token_Called.ToString());

            Assert.IsNotNull(is_Token_Called);
            Assert.IsTrue(!string.IsNullOrEmpty(is_Token_Called.ToString()));
            Assert.IsNotNull(res);
            Assert.IsNull(res.GetValue("access_token"));
            Assert.IsNotNull(res.GetValue("error"));


            //caller.VerifyAll();

        }

        [TestMethod]
        public async Task ChatHub_Send_Success_WithNewChat()
        {

            var userStore = new Mock<IUserStore<NNK.Messenger.AspNetIdentity.User, int>>();
            var manager = new UserManager<User, int>(userStore.Object);

            var owinMock = new Mock<IOwinContext>();
            //var context = new Mock<HttpContextBase>();
            var mockIdentity = new Mock<IIdentity>();
            //context.SetupGet(x => x.User.Identity).Returns(mockIdentity.Object);  
            owinMock.SetupGet(i => i.Request.User.Identity).Returns(mockIdentity.Object);
            mockIdentity.SetupGet(x => x.Name).Returns("test_name");

            //var manager = ApplicationUserManager.Create(new IdentityFactoryOptions<ApplicationUserManager>(), owinMock.Object);
            //context that contains the client connections
            var mockClients = new Mock<IHubCallerConnectionContext<dynamic>>();
            //make the hub believe it has actual clients
            //create a mock of the client contract, this is the interface that defines what methods are available for clients
            //var caller = new Mock<IClientContract>();
            //set the mock up so that the available method has restrictions on parameters
            //client.Setup(m => m.getAllUsers(It.IsAny<vw_User[]>()));
            //caller.Setup(m => m.ping(It.IsAny<bool>())).Verifiable();
            //caller.Setup(m => m.ping(true)).Verifiable();
            object isSendAddMessageCalled = null;
            object isOnNewChatCreatedCalled = null;


            dynamic caller = new ExpandoObject();
            caller.addMessage = new Func<ChatMessage, Task>(
                async (param) =>
                {
                    await Task.Run(() => { isSendAddMessageCalled = param; });

                });

           // mockClients.Setup(m => m.Caller).Returns((ExpandoObject)caller);


            caller.onNewChatCreated = new Func<Guid, Task>(
                async (param) =>
                {
                    await Task.Run(() => { isOnNewChatCreatedCalled = param; });

                });

            mockClients.Setup(m => m.Clients(It.IsAny<string[]>())).Returns((ExpandoObject)caller);

            var hub = CreateChatHubWithClients(mockClients, "ccc", null, new DataStoreOps());


            var message = new ChatMessage("@ccc", "hello world!", "@ccc", "new")
            {
                SID = Guid.NewGuid(),
                Created = DateTime.UtcNow
            };

            await hub.Send(message);

            //var res = JObject.Parse(is_Token_Called.ToString());

            Assert.IsNotNull(isSendAddMessageCalled);
            Assert.IsNotNull(isOnNewChatCreatedCalled);
            Assert.IsNotNull((isSendAddMessageCalled as ChatMessage));
            Assert.IsTrue(((ChatMessage) isSendAddMessageCalled).SID==message.SID);
            Assert.IsTrue(((ChatMessage)isSendAddMessageCalled).Message == message.Message);
            Assert.IsNotNull((Guid)isOnNewChatCreatedCalled);
            //            Assert.IsNotNull(res);
            //            Assert.IsNull(res.GetValue("access_token"));
            //            Assert.IsNotNull(res.GetValue("error"));


            //caller.VerifyAll();

        }

        [TestMethod]
        public async Task ChatHub_Send_Success_WithExistChat()
        {
            var mockClients = new Mock<IHubCallerConnectionContext<dynamic>>();

            object isSendAddMessageCalled = null;

            dynamic caller = new ExpandoObject();

            caller.addMessage = new Func<ChatMessage, Task>(
                async (param) =>
                {
                    await Task.Run(() => { isSendAddMessageCalled = param; });

                });

            // mockClients.Setup(m => m.Caller).Returns((ExpandoObject)caller);

            mockClients.Setup(m => m.Clients(It.IsAny<string[]>())).Returns((ExpandoObject)caller);

            var hub = CreateChatHubWithClients(mockClients);

            var message = new ChatMessage("@ccc", "hello world!", "@ccc", "21083B88-01BF-4BD8-86D7-0AD8D1E51AEA")
            {
                SID = Guid.NewGuid(),
                Created = DateTime.UtcNow
            };

            await hub.Send(message);

            Assert.IsNotNull(isSendAddMessageCalled);
            Assert.IsNotNull((isSendAddMessageCalled as ChatMessage));
            Assert.IsTrue(((ChatMessage)isSendAddMessageCalled).SID == message.SID);
            Assert.IsTrue(((ChatMessage)isSendAddMessageCalled).Message == message.Message);
            Assert.IsTrue(string.Equals(((ChatMessage)isSendAddMessageCalled).ChatId, message.ChatId, StringComparison.InvariantCultureIgnoreCase));
        }

        [TestMethod]
        public async Task ChatHub_Send_Failed_WithNonExistChat()
        {

            var userStore = new Mock<IUserStore<NNK.Messenger.AspNetIdentity.User, int>>();
            var manager = new UserManager<User, int>(userStore.Object);

            var owinMock = new Mock<IOwinContext>();
            //var context = new Mock<HttpContextBase>();
            var mockIdentity = new Mock<IIdentity>();
            //context.SetupGet(x => x.User.Identity).Returns(mockIdentity.Object);  
            //owinMock.SetupGet(i => i.Request.User.Identity).Returns(mockIdentity.Object);
            mockIdentity.SetupGet(x => x.Name).Returns("test_name");

            var mockClients = new Mock<IHubCallerConnectionContext<dynamic>>();

            object isSendAddMessageCalled = null;

            dynamic caller = new ExpandoObject();

            caller.addMessage = new Func<ChatMessage, Task>(
                async (param) =>
                {
                    await Task.Run(() => { isSendAddMessageCalled = param; });

                });

            // mockClients.Setup(m => m.Caller).Returns((ExpandoObject)caller);

            mockClients.Setup(m => m.Clients(It.IsAny<string[]>())).Returns((ExpandoObject)caller);

            var hub = CreateChatHubWithClients(mockClients);

            var message = new ChatMessage("@ccc", "hello world!", "@ccc", "22228888-0000-0000-0000-111122223333")
            {
                SID = Guid.NewGuid(),
                Created = DateTime.UtcNow
            };

            Exception expectedException = null;

            try
            {
                await hub.Send(message);
            }
            catch (Exception ex)
            {
                expectedException = ex;
            }

            Assert.IsNotNull(expectedException);

            Assert.IsTrue(expectedException.Message == $"Chat {Guid.Parse(message.ChatId)} does not exist");
        }


        [TestMethod]
        public async Task ChatHub_GetChatMessagesToUser_Success()
        {
            var mockClients = new Mock<IHubCallerConnectionContext<dynamic>>();

            object isGetChatMessagesToUserCalled = null;

            dynamic caller = new ExpandoObject();

            caller.getChatMessages = new Func<ChatMessage[], Task>(
                async (param) =>
                {
                    await Task.Run(() => { isGetChatMessagesToUserCalled = param; });

                });

            // mockClients.Setup(m => m.Caller).Returns((ExpandoObject)caller);

            mockClients.Setup(m => m.Caller).Returns((ExpandoObject)caller);

            var hub = CreateChatHubWithClients(mockClients);

            await hub.GetChatMessagesToUser("9B087205-A8AC-46A9-955C-6A34C8E1DD8D");

            Assert.IsNotNull(isGetChatMessagesToUserCalled);
        }

        [TestMethod]
        public async Task ChatHub_GetChatMessagesToUser_Failed_WithAnotherChat()
        {
            var mockClients = new Mock<IHubCallerConnectionContext<dynamic>>();

            object result = null;

            dynamic caller = new ExpandoObject();

            caller.getChatMessages = new Func<ChatMessage[], Task>(
                async (param) =>
                {
                    await Task.Run(() => { result = param; });

                });

            // mockClients.Setup(m => m.Caller).Returns((ExpandoObject)caller);

            mockClients.Setup(m => m.Caller).Returns((ExpandoObject)caller);

            var hub = CreateChatHubWithClients(mockClients);

            Exception expected = null;
            
            try
            {
                await hub.GetChatMessagesToUser("C1C5BCBD-0780-4C8C-9D48-9EAB8D161A07");
            }
            catch (Exception ex)
            {
                expected = ex;
            }

            Assert.IsNotNull(expected);
            Assert.IsTrue(expected.Message== "Access to foreign' chat messages denied");
        }

        [TestMethod]
        public async Task ChatHub_GetChatMessagesToUser_Failed_ChatIsNullOrEmpty()
        {
            var mockClients = new Mock<IHubCallerConnectionContext<dynamic>>();

            object result = null;

            dynamic caller = new ExpandoObject();

            caller.getChatMessages = new Func<ChatMessage[], Task>(
                async (param) =>
                {
                    await Task.Run(() => { result = param; });

                });

            // mockClients.Setup(m => m.Caller).Returns((ExpandoObject)caller);

            mockClients.Setup(m => m.Caller).Returns((ExpandoObject)caller);

            var hub = CreateChatHubWithClients(mockClients);

            Exception expected = null;

            try
            {
                await hub.GetChatMessagesToUser(null);
            }
            catch (Exception ex)
            {
                expected = ex;
            }

            Assert.IsNotNull(expected);
            Assert.IsTrue(expected.Message == "Chat is null or empty");
        }

        //GetAllMessages(string user, string timeLabel = null, string msgChkSum = null)
        [TestMethod]
        public async Task ChatHub_GetAllMessages_Failed_UserIsNullOrEmpty()
        {
            var mockClients = new Mock<IHubCallerConnectionContext<dynamic>>();

            object result = null;

            dynamic caller = new ExpandoObject();

            caller.getAllMessages = new Func<Dictionary<string,ChatMessage[]>, Task>(
                async (param) =>
                {
                    await Task.Run(() => { result = param; });

                });

            // mockClients.Setup(m => m.Caller).Returns((ExpandoObject)caller);

            mockClients.Setup(m => m.Caller).Returns((ExpandoObject)caller);

            var hub = CreateChatHubWithClients(mockClients);

            Exception expected = null;

            try
            {
                await hub.GetAllMessages(null);
            }
            catch (Exception ex)
            {
                expected = ex;
            }

            Assert.IsNotNull(expected);
            Assert.IsTrue(expected.Message == "User is null or empty");
        }
        [TestMethod]
        public async Task ChatHub_GetAllMessages_Failed_UserDiffersFromAuth()
        {
            var mockClients = new Mock<IHubCallerConnectionContext<dynamic>>();

            object result = null;

            dynamic caller = new ExpandoObject();

            caller.getAllMessages = new Func<Dictionary<string, ChatMessage[]>, Task>(
                async (param) =>
                {
                    await Task.Run(() => { result = param; });

                });

            // mockClients.Setup(m => m.Caller).Returns((ExpandoObject)caller);

            mockClients.Setup(m => m.Caller).Returns((ExpandoObject)caller);

            var hub = CreateChatHubWithClients(mockClients);

            Exception expected = null;

            try
            {
                await hub.GetAllMessages("@sjdfbgkjewbgkjbewk");
            }
            catch (Exception ex)
            {
                expected = ex;
            }

            Assert.IsNotNull(expected);
            Assert.IsTrue(expected.Message == "User from arguments differs from authenticated");
        }

        //public async Task GetUserChatMessages(string user, string chat, string msgChkSum = null)
        [TestMethod]
        public async Task ChatHub_GetUserChatMessages_Failed_UserIsNullOrEmpty()
        {
            var mockClients = new Mock<IHubCallerConnectionContext<dynamic>>();

            object result = null;

            dynamic caller = new ExpandoObject();

            caller.getUserChatMessages = new Func<ChatMessage[], Task>(
                async (param) =>
                {
                    await Task.Run(() => { result = param; });

                });

            // mockClients.Setup(m => m.Caller).Returns((ExpandoObject)caller);

            mockClients.Setup(m => m.Caller).Returns((ExpandoObject)caller);

            var hub = CreateChatHubWithClients(mockClients);

            Exception expected = null;

            try
            {
                await hub.GetUserChatMessages(null, "C1C5BCBD-0780-4C8C-9D48-9EAB8D161A07");
            }
            catch (Exception ex)
            {
                expected = ex;
            }

            Assert.IsNotNull(expected);
            Assert.IsTrue(expected.Message == "User is null or empty");
        }

        [TestMethod]
        public async Task ChatHub_GetUserChatMessages_Failed_UserDiffersFromAuth()
        {
            var mockClients = new Mock<IHubCallerConnectionContext<dynamic>>();

            object result = null;

            dynamic caller = new ExpandoObject();

            caller.getUserChatMessages = new Func<ChatMessage[], Task>(
                async (param) =>
                {
                    await Task.Run(() => { result = param; });

                });

            // mockClients.Setup(m => m.Caller).Returns((ExpandoObject)caller);

            mockClients.Setup(m => m.Caller).Returns((ExpandoObject)caller);

            var hub = CreateChatHubWithClients(mockClients);

            Exception expected = null;

            try
            {
                await hub.GetUserChatMessages("@sjdfbgkjewbgkjbewk", "C1C5BCBD-0780-4C8C-9D48-9EAB8D161A07");
            }
            catch (Exception ex)
            {
                expected = ex;
            }

            Assert.IsNotNull(expected);
            Assert.IsTrue(expected.Message == "User from arguments differs from authenticated");
        }
        
        [TestMethod()]
        public async Task ChatHub_GetUserChatMessages_Failed_WithAnotherChat()
        {
            var mockClients = new Mock<IHubCallerConnectionContext<dynamic>>();

            object result = null;

            dynamic caller = new ExpandoObject();

            caller.getUserChatMessages = new Func<ChatMessage[], Task>(
                async (param) =>
                {
                    await Task.Run(() => { result = param; });

                });

            // mockClients.Setup(m => m.Caller).Returns((ExpandoObject)caller);

            mockClients.Setup(m => m.Caller).Returns((ExpandoObject)caller);

            var hub = CreateChatHubWithClients(mockClients);

            Exception expected = null;

            try
            {
                await hub.GetUserChatMessages("@ccc", "99D91EB9-9A04-4D80-B409-93C86265B5C6");
            }
            catch (Exception ex)
            {
                expected = ex;
            }

            Assert.IsNotNull(expected);
            Assert.IsTrue(expected.Message == "Access to foreign' chat messages denied");
        }

        [TestMethod]
        public async Task ChatHub_GetUserChatMessages_Failed_ChatIsNullOrEmpty()
        {
            var mockClients = new Mock<IHubCallerConnectionContext<dynamic>>();

            object result = null;

            dynamic caller = new ExpandoObject();

            caller.getUserChatMessages = new Func<ChatMessage[], Task>(
                async (param) =>
                {
                    await Task.Run(() => { result = param; });

                });

            // mockClients.Setup(m => m.Caller).Returns((ExpandoObject)caller);

            mockClients.Setup(m => m.Caller).Returns((ExpandoObject)caller);

            var hub = CreateChatHubWithClients(mockClients);

            Exception expected = null;

            try
            {
                await hub.GetUserChatMessages("@ccc", null);
            }
            catch (Exception ex)
            {
                expected = ex;
            }

            Assert.IsNotNull(expected);
            Assert.IsTrue(expected.Message == "Chat is null or empty");
        }

        [TestMethod]
        public async Task ChatHub_GetUserChatMessages_Success()
        {
            var mockClients = new Mock<IHubCallerConnectionContext<dynamic>>();

            object result = null;

            dynamic caller = new ExpandoObject();

            caller.getUserChatMessages = new Func<ChatMessage[], Task>(
                async (param) =>
                {
                    await Task.Run(() => { result = param; });

                });

            // mockClients.Setup(m => m.Caller).Returns((ExpandoObject)caller);

            mockClients.Setup(m => m.Caller).Returns((ExpandoObject)caller);

            var hub = CreateChatHubWithClients(mockClients);

            Exception expected = null;

            try
            {
                await hub.GetUserChatMessages("@ccc", "9B087205-A8AC-46A9-955C-6A34C8E1DD8D");
            }
            catch (Exception ex)
            {
                expected = ex;
            }

            Assert.IsNull(expected);
            Assert.IsNotNull(result);
        }

        [TestMethod]
        public async Task ChatHub_GetAllChats_Failed_UserIsNullOrEmpty()
        {
            var mockClients = new Mock<IHubCallerConnectionContext<dynamic>>();

            object result = null;

            dynamic caller = new ExpandoObject();

            caller.getAllChats = new Func<Chat[], Task>(
                async (param) =>
                {
                    await Task.Run(() => { result = param; });

                });

            // mockClients.Setup(m => m.Caller).Returns((ExpandoObject)caller);

            mockClients.Setup(m => m.Caller).Returns((ExpandoObject)caller);

            var hub = CreateChatHubWithClients(mockClients);

            Exception expected = null;

            try
            {
                await hub.GetAllChats(null, null);
            }
            catch (Exception ex)
            {
                expected = ex;
            }

            Assert.IsNotNull(expected);
            Assert.IsTrue(expected.Message == "User is null or empty");
        }
        
        [TestMethod]
        public async Task ChatHub_GetAllChats_Failed_UserDiffersFromAuth()
        {
            var mockClients = new Mock<IHubCallerConnectionContext<dynamic>>();

            object result = null;

            dynamic caller = new ExpandoObject();

            caller.getAllChats = new Func<Chat[], Task>(
                async (param) =>
                {
                    await Task.Run(() => { result = param; });

                });

            // mockClients.Setup(m => m.Caller).Returns((ExpandoObject)caller);

            mockClients.Setup(m => m.Caller).Returns((ExpandoObject)caller);

            var hub = CreateChatHubWithClients(mockClients);

            Exception expected = null;

            try
            {
                await hub.GetAllChats("@sjfgvljhflkvjaedlvkj", null);
            }
            catch (Exception ex)
            {
                expected = ex;
            }

            Assert.IsNotNull(expected);
            Assert.IsTrue(expected.Message == "User from arguments differs from authenticated");
        }

        [TestMethod]
        public async Task ChatHub_GetAllChats_Success()
        {
            var mockClients = new Mock<IHubCallerConnectionContext<dynamic>>();

            object result = null;

            dynamic caller = new ExpandoObject();

            caller.getAllChats = new Func<Chat[], Task>(
                async (param) =>
                {
                    await Task.Run(() => { result = param; });

                });

            // mockClients.Setup(m => m.Caller).Returns((ExpandoObject)caller);

            mockClients.Setup(m => m.Caller).Returns((ExpandoObject)caller);

            var hub = CreateChatHubWithClients(mockClients);

            Exception expected = null;

            try
            {
                await hub.GetAllChats("@ccc", null);
            }
            catch (Exception ex)
            {
                expected = ex;
            }

            Assert.IsNull(expected);
            Assert.IsNotNull(result);
        }

        [TestMethod]
        public async Task ChatHub_GetAllParty_Success()
        {
            var mockClients = new Mock<IHubCallerConnectionContext<dynamic>>();

            object result = null;

            dynamic caller = new ExpandoObject();

            caller.getAllParty = new Func<Party[], Task>(
                async (param) =>
                {
                    await Task.Run(() => { result = param; });

                });

            // mockClients.Setup(m => m.Caller).Returns((ExpandoObject)caller);

            mockClients.Setup(m => m.Caller).Returns((ExpandoObject)caller);

            var hub = CreateChatHubWithClients(mockClients);

            Exception expected = null;

            try
            {
                await hub.GetAllParty("@ccc", null);
            }
            catch (Exception ex)
            {
                expected = ex;
            }

            Assert.IsNull(expected);
            Assert.IsNotNull(result);
        }

        [TestMethod]
        public async Task ChatHub_GetAllParty_Failed_UserIsNullOrEmpty()
        {
            var mockClients = new Mock<IHubCallerConnectionContext<dynamic>>();

            object result = null;

            dynamic caller = new ExpandoObject();

            caller.getAllParty = new Func<Party[], Task>(
                async (param) =>
                {
                    await Task.Run(() => { result = param; });

                });

            // mockClients.Setup(m => m.Caller).Returns((ExpandoObject)caller);

            mockClients.Setup(m => m.Caller).Returns((ExpandoObject)caller);

            var hub = CreateChatHubWithClients(mockClients);

            Exception expected = null;

            try
            {
                await hub.GetAllParty(null, null);
            }
            catch (Exception ex)
            {
                expected = ex;
            }

            Assert.IsNotNull(expected);
            Assert.IsTrue(expected.Message == "User is null or empty");
        }

        [TestMethod]
        public async Task ChatHub_GetAllParty_Failed_UserDiffersFromAuth()
        {
            var mockClients = new Mock<IHubCallerConnectionContext<dynamic>>();

            object result = null;

            dynamic caller = new ExpandoObject();

            caller.getAllParty = new Func<Party[], Task>(
                async (param) =>
                {
                    await Task.Run(() => { result = param; });

                });

            // mockClients.Setup(m => m.Caller).Returns((ExpandoObject)caller);

            mockClients.Setup(m => m.Caller).Returns((ExpandoObject)caller);

            var hub = CreateChatHubWithClients(mockClients);

            Exception expected = null;

            try
            {
                await hub.GetAllParty("@kjhbkjre", null);
            }
            catch (Exception ex)
            {
                expected = ex;
            }

            Assert.IsNotNull(expected);
            Assert.IsTrue(expected.Message == "User from arguments differs from authenticated");
        }

        [TestMethod]
        public async Task ChatHub_GetAllUsers_Success()
        {
            var mockClients = new Mock<IHubCallerConnectionContext<dynamic>>();

            object result = null;

            dynamic caller = new ExpandoObject();

            caller.getAllUsers = new Func<vw_User[], Task>(
                async (param) =>
                {
                    await Task.Run(() => { result = param; });

                });

            // mockClients.Setup(m => m.Caller).Returns((ExpandoObject)caller);

            mockClients.Setup(m => m.Caller).Returns((ExpandoObject)caller);

            var hub = CreateChatHubWithClients(mockClients);

            Exception expected = null;

            try
            {
                await hub.GetAllUsers(null);
            }
            catch (Exception ex)
            {
                expected = ex;
            }

            Assert.IsNull(expected);
            Assert.IsNotNull(result);
        }

        [TestMethod]
        public async Task ChatHub_GetUserChatList_Success()
        {
            var mockClients = new Mock<IHubCallerConnectionContext<dynamic>>();

            object result = null;

            dynamic caller = new ExpandoObject();

            caller.getUserChatList = new Func<vw_user_chat_list[], Task>(
                async (param) =>
                {
                    await Task.Run(() => { result = param; });

                });

            // mockClients.Setup(m => m.Caller).Returns((ExpandoObject)caller);

            mockClients.Setup(m => m.Caller).Returns((ExpandoObject)caller);

            var hub = CreateChatHubWithClients(mockClients);

            Exception expected = null;

            try
            {
                await hub.GetUserChatList("@ccc");
            }
            catch (Exception ex)
            {
                expected = ex;
            }

            Assert.IsNull(expected);
            Assert.IsNotNull(result);
        }

        [TestMethod]
        public async Task ChatHub_GetUserChatList_Failed_UserIsNullOrEmpty()
        {
            var mockClients = new Mock<IHubCallerConnectionContext<dynamic>>();

            object result = null;

            dynamic caller = new ExpandoObject();

            caller.getUserChatList = new Func<vw_user_chat_list[], Task>(
                async (param) =>
                {
                    await Task.Run(() => { result = param; });

                });

            // mockClients.Setup(m => m.Caller).Returns((ExpandoObject)caller);

            mockClients.Setup(m => m.Caller).Returns((ExpandoObject)caller);

            var hub = CreateChatHubWithClients(mockClients);

            Exception expected = null;

            try
            {
                await hub.GetUserChatList(null);
            }
            catch (Exception ex)
            {
                expected = ex;
            }

            Assert.IsNotNull(expected);
            Assert.IsTrue(expected.Message == "User is null or empty");
        }

        [TestMethod]
        public async Task ChatHub_GetUserChatList_Failed_UserDiffersFromAuth()
        {
            var mockClients = new Mock<IHubCallerConnectionContext<dynamic>>();

            object result = null;

            dynamic caller = new ExpandoObject();

            caller.getUserChatList = new Func<vw_user_chat_list[], Task>(
                async (param) =>
                {
                    await Task.Run(() => { result = param; });

                });

            // mockClients.Setup(m => m.Caller).Returns((ExpandoObject)caller);

            mockClients.Setup(m => m.Caller).Returns((ExpandoObject)caller);

            var hub = CreateChatHubWithClients(mockClients);

            Exception expected = null;

            try
            {
                await hub.GetUserChatList("@kjbghiujerw");
            }
            catch (Exception ex)
            {
                expected = ex;
            }

            Assert.IsNotNull(expected);
            Assert.IsTrue(expected.Message == "User from arguments differs from authenticated");
        }

        [TestMethod]
        public async Task ChatHub_Validate_Failed_ExistLogin()
        {
            var mockClients = new Mock<IHubCallerConnectionContext<dynamic>>();

            object result = null;

            dynamic caller = new ExpandoObject();

            caller.validate = new Func<bool, Task>(
                async (param) =>
                {
                    await Task.Run(() => { result = param; });

                });

            // mockClients.Setup(m => m.Caller).Returns((ExpandoObject)caller);

            mockClients.Setup(m => m.Caller).Returns((ExpandoObject)caller);

            var hub = CreateChatHubWithClients(mockClients);

            Exception expected = null;

            try
            {
                await hub.Validate(Convert.ToBase64String(Encoding.Default.GetBytes("{'value':'ccc','key':'login'}")));
            }
            catch (Exception ex)
            {
                expected = ex;
            }

            Assert.IsNull(expected);
            Assert.IsNotNull(result);
            Assert.IsTrue((bool)result);
        }

        [TestMethod]
        public async Task ChatHub_Validate_Success_Login()
        {
            var mockClients = new Mock<IHubCallerConnectionContext<dynamic>>();

            object result = null;

            dynamic caller = new ExpandoObject();

            caller.validate = new Func<bool, Task>(
                async (param) =>
                {
                    await Task.Run(() => { result = param; });

                });

            // mockClients.Setup(m => m.Caller).Returns((ExpandoObject)caller);

            mockClients.Setup(m => m.Caller).Returns((ExpandoObject)caller);

            var hub = CreateChatHubWithClients(mockClients);

            Exception expected = null;

            try
            {
                await hub.Validate(Convert.ToBase64String(Encoding.Default.GetBytes("{'value':'$$bjhjhjhvjhkjhvkjh$$$@@@','key':'login'}")));
            }
            catch (Exception ex)
            {
                expected = ex;
            }

            Assert.IsNull(expected);
            Assert.IsNotNull(result);
            Assert.IsTrue(!(bool)result);
        }

        [TestMethod]
        public async Task ChatHub_Validate_Failed_NoValidateKey()
        {
            var mockClients = new Mock<IHubCallerConnectionContext<dynamic>>();

            object result = null;

            dynamic caller = new ExpandoObject();

            caller.validate = new Func<bool, Task>(
                async (param) =>
                {
                    await Task.Run(() => { result = param; });

                });

            // mockClients.Setup(m => m.Caller).Returns((ExpandoObject)caller);

            mockClients.Setup(m => m.Caller).Returns((ExpandoObject)caller);

            var hub = CreateChatHubWithClients(mockClients);

            Exception expected = null;

            try
            {
                await hub.Validate(Convert.ToBase64String(Encoding.Default.GetBytes("{'value':'$$bjhjhjhvjhkjhvkjh$$$@@@','key':''}")));
            }
            catch (Exception ex)
            {
                expected = ex;
            }

            Assert.IsNotNull(expected);
            Assert.IsTrue(expected.Message== "Validate key is null or empty");
        }

        [TestMethod]
        public async Task ChatHub_Validate_Failed_ExistEmail()
        {
            var mockClients = new Mock<IHubCallerConnectionContext<dynamic>>();

            object result = null;

            dynamic caller = new ExpandoObject();

            caller.validate = new Func<bool, Task>(
                async (param) =>
                {
                    await Task.Run(() => { result = param; });

                });

            // mockClients.Setup(m => m.Caller).Returns((ExpandoObject)caller);

            mockClients.Setup(m => m.Caller).Returns((ExpandoObject)caller);

            var hub = CreateChatHubWithClients(mockClients);

            Exception expected = null;

            try
            {
                await hub.Validate(Convert.ToBase64String(Encoding.Default.GetBytes("{'value':'ccc@ccc.ru','key':'email'}")));
            }
            catch (Exception ex)
            {
                expected = ex;
            }

            Assert.IsNull(expected);
            Assert.IsNotNull(result);
            Assert.IsTrue((bool)result);
        }

        [TestMethod]
        public async Task ChatHub_Validate_Success_Email()
        {
            var mockClients = new Mock<IHubCallerConnectionContext<dynamic>>();

            object result = null;

            dynamic caller = new ExpandoObject();

            caller.validate = new Func<bool, Task>(
                async (param) =>
                {
                    await Task.Run(() => { result = param; });

                });

            // mockClients.Setup(m => m.Caller).Returns((ExpandoObject)caller);

            mockClients.Setup(m => m.Caller).Returns((ExpandoObject)caller);

            var hub = CreateChatHubWithClients(mockClients);

            Exception expected = null;

            try
            {
                await hub.Validate(Convert.ToBase64String(Encoding.Default.GetBytes("{'value':'@kljlklkn$$$777ccc@ccc.ru','key':'email'}")));
            }
            catch (Exception ex)
            {
                expected = ex;
            }

            Assert.IsNull(expected);
            Assert.IsNotNull(result);
            Assert.IsTrue(!(bool)result);
        }

        [TestMethod]
        public async Task ChatHub_Validate_Failed_ExistSms()
        {
            var mockClients = new Mock<IHubCallerConnectionContext<dynamic>>();

            object result = null;

            dynamic caller = new ExpandoObject();

            caller.validate = new Func<bool, Task>(
                async (param) =>
                {
                    await Task.Run(() => { result = param; });

                });

            // mockClients.Setup(m => m.Caller).Returns((ExpandoObject)caller);

            mockClients.Setup(m => m.Caller).Returns((ExpandoObject)caller);

            var hub = CreateChatHubWithClients(mockClients);

            Exception expected = null;

            try
            {
                await hub.Validate(Convert.ToBase64String(Encoding.Default.GetBytes("{'value':'888','key':'sms'}")));
            }
            catch (Exception ex)
            {
                expected = ex;
            }

            Assert.IsNull(expected);
            Assert.IsNotNull(result);
            Assert.IsTrue((bool)result);
        }

        [TestMethod]
        public async Task ChatHub_Validate_Success_Sms()
        {
            var mockClients = new Mock<IHubCallerConnectionContext<dynamic>>();

            object result = null;

            dynamic caller = new ExpandoObject();

            caller.validate = new Func<bool, Task>(
                async (param) =>
                {
                    await Task.Run(() => { result = param; });

                });

            // mockClients.Setup(m => m.Caller).Returns((ExpandoObject)caller);

            mockClients.Setup(m => m.Caller).Returns((ExpandoObject)caller);

            var hub = CreateChatHubWithClients(mockClients);

            Exception expected = null;

            try
            {
                await hub.Validate(Convert.ToBase64String(Encoding.Default.GetBytes("{'value':'437659999111111110000','key':'sms'}")));
            }
            catch (Exception ex)
            {
                expected = ex;
            }

            Assert.IsNull(expected);
            Assert.IsNotNull(result);
            Assert.IsTrue(!(bool)result);
        }

        [TestMethod]
        public async Task ChatHub_Operation_Success()
        {
            
            var mockClients = new Mock<IHubCallerConnectionContext<dynamic>>();

            object result = null;

            dynamic caller = new ExpandoObject();

            caller.operation = new Func<Guid, Task>(
                async (param) =>
                {
                    await Task.Run(() => { result = param; });

                });
            
            // mockClients.Setup(m => m.Caller).Returns((ExpandoObject)caller);

            mockClients.Setup(m => m.Caller).Returns((ExpandoObject)caller);

            var hub = CreateChatHubWithClients(mockClients);

            Exception expected = null;

            var opops = new OperationsOperations(new DataStoreOps.DapperConnectionStringProvider());

            try
            {
                //await uops.DeleteUserByPhone("79067981094");

                var data =
                    Encoding.Default.GetBytes(
                        "{\"login\":\"pichugin_1094\",\"password\":\"pichugin\",\"confirm_password\":\"pichugin\",\"email\":\"sergey.pichugin@oilgazholding.ru\",\"phone\":\"79067981094\"}");


                await hub.Operation("register", "sms", Convert.ToBase64String(data));
            }
            catch (Exception ex)
            {
                expected = ex;
            }

            Assert.IsNull(expected);
            Assert.IsNotNull(result);
            Assert.IsNotNull(result is Guid);

            var op=opops.GetById((Guid)result);
            Assert.IsNotNull(op);

            if ((Guid?) result != null)
            {
                
                opops.DeleteOperation((Guid)result);
            }
        }

        [TestMethod]
        public async Task ChatHub_GetConfirmSecret_Success()
        {

            var mockClients = new Mock<IHubCallerConnectionContext<dynamic>>();

            var smsoMock = new Mock<ISmsServiceOperations>();



            object result = null;

            dynamic caller = new ExpandoObject();

            caller.operation = new Func<Guid, Task>(
                async (param) =>
                {
                    await Task.Run(() => { result = param; });

                });
            var code = "";
            // mockClients.Setup(m => m.Caller).Returns((ExpandoObject)caller);

            mockClients.Setup(m => m.Caller).Returns((ExpandoObject)caller);

            smsoMock.Setup(i => i.SendSms(It.IsAny<SmsTask>())).Callback<SmsTask>((i) =>
            {
                code = i.MessageText;

                Debug.WriteLine(i.MessageText);
            });
            smsoMock.Setup(i => i.SendSmsFromWeb(It.IsAny<SmsTask>())).Callback<SmsTask>((i) =>
            {
                code = i.MessageText;

                Debug.WriteLine(i.MessageText);
            });

            var hub = CreateChatHubWithClients(mockClients, "ccc", smsoMock);

            Exception expected = null;

            var opops = new OperationsOperations(new DataStoreOps.DapperConnectionStringProvider());

            try
            {
                

                //await uops.DeleteUserByPhone("79067981094");

                var data =
                    Encoding.Default.GetBytes(
                        "{\"login\":\"pichugin_1094\",\"password\":\"pichugin\",\"confirm_password\":\"pichugin\",\"email\":\"sergey.pichugin@oilgazholding.ru\",\"phone\":\"79067981094\"}");


                await hub.Operation("register", "sms", Convert.ToBase64String(data));

            }
            catch (Exception ex)
            {
                expected = ex;
            }

            Assert.IsNull(expected);
            Assert.IsNotNull(result);
            Assert.IsNotNull(result is Guid);

            await hub.GetConfirmSecret(Convert.ToBase64String(Encoding.UTF8.GetBytes(((Guid)result).ToString())));

            Assert.IsNotNull(code);
            Assert.IsNotNull((int?)int.Parse(code));

            var op = opops.GetById((Guid)result);
            Assert.IsNotNull(op);

            if ((Guid?)result != null)
            {
                opops.DeleteOperation((Guid)result);
            }
        }

        [TestMethod]
        public async Task ChatHub_GetUserInvites_Success()
        {
            var mockClients = new Mock<IHubCallerConnectionContext<dynamic>>();
            
            object result = null;

            dynamic caller = new ExpandoObject();

            caller.getFreshInvites = new Func<Invite[], Task>(
                async (param) =>
                {
                    await Task.Run(() => { result = param; });

                });
        
            // mockClients.Setup(m => m.Caller).Returns((ExpandoObject)caller);

            mockClients.Setup(m => m.Caller).Returns((ExpandoObject)caller);

            var hub = CreateChatHubWithClients(mockClients, "aaa");

            Exception expected = null;

            try
            {
                await hub.GetUserInvites("@aaa");
            }
            catch (Exception ex)
            {
                expected = ex;
            }

            Assert.IsNull(expected);
            Assert.IsNotNull(result);
        }

        [TestMethod]
        public async Task ChatHub_GetUserInvites_Failed_UserIsNullOrEmpty()
        {
            var mockClients = new Mock<IHubCallerConnectionContext<dynamic>>();

            object result = null;

            dynamic caller = new ExpandoObject();

            caller.getFreshInvites = new Func<Invite[], Task>(
                async (param) =>
                {
                    await Task.Run(() => { result = param; });

                });

            // mockClients.Setup(m => m.Caller).Returns((ExpandoObject)caller);

            mockClients.Setup(m => m.Caller).Returns((ExpandoObject)caller);

            var hub = CreateChatHubWithClients(mockClients, "aaa");

            Exception expected = null;

            try
            {
                await hub.GetUserInvites(null);
            }
            catch (Exception ex)
            {
                expected = ex;
            }

            Assert.IsNotNull(expected);
            Assert.IsTrue(expected.Message == "User is null or empty");
        }

        [TestMethod]
        public async Task ChatHub_GetUserInvites_Failed_UserDiffersFromAuth()
        {
            var mockClients = new Mock<IHubCallerConnectionContext<dynamic>>();

            object result = null;

            dynamic caller = new ExpandoObject();

            caller.getFreshInvites = new Func<Invite[], Task>(
                async (param) =>
                {
                    await Task.Run(() => { result = param; });

                });

            // mockClients.Setup(m => m.Caller).Returns((ExpandoObject)caller);

            mockClients.Setup(m => m.Caller).Returns((ExpandoObject)caller);

            var hub = CreateChatHubWithClients(mockClients, "aaa");

            Exception expected = null;

            try
            {
                await hub.GetUserInvites("@kjdfkdn$$kjbkjrbn2433214kj");
            }
            catch (Exception ex)
            {
                expected = ex;
            }

            Assert.IsNotNull(expected);
            Assert.IsTrue(expected.Message == "User from arguments differs from authenticated");
        }

        [TestMethod]
        public async Task ChatHub_KillChat_Success()
        {
            var mockClients = new Mock<IHubCallerConnectionContext<dynamic>>();

            object result = null;

            dynamic caller = new ExpandoObject();

            caller.onKillChat = new Func<string, Task>(
                async (param) =>
                {
                    await Task.Run(() => { result = param; });

                });

            // mockClients.Setup(m => m.Caller).Returns((ExpandoObject)caller);

            mockClients.Setup(m => m.All).Returns((ExpandoObject)caller);

            
            var guidToKill = Guid.NewGuid();
            
            var mids = (IEnumerable<Guid>)new[] {Guid.NewGuid(),Guid.NewGuid(), Guid.NewGuid() };
            var fids = new[] { Guid.NewGuid(), Guid.NewGuid(), Guid.NewGuid() };
            var amopsMock = new Mock<IAttachMetadataOperations>();
            var aopsMock=new Mock<IAttachmentOperations>();
            var copsMock = new Mock<IChatOperations>();
            
            var chat = new Chat()
            {
                ID = guidToKill,
                Author = "@test_author",
                Party = "@test_author",
                Created = DateTime.UtcNow,
                Title = "test chat"
            };

            copsMock.Setup(i => i.Get(It.IsAny<Guid>())).Returns(chat);

            var fopsMock = new Mock<IFileStoreOperations>();
            var mopsMock = new Mock<IMessageOperations>();
            mopsMock.Setup(i => i.GetChatMessages(guidToKill)).Returns(mids);
            var ResultKillChatMessageNotificationsAsync = false;
            var nopsMock = new Mock<INotificationOperations>();
            nopsMock.Setup(i => i.KillChatMessageNotifications(mids)).Callback<Guid[]>((q) =>
            {
                ResultKillChatMessageNotificationsAsync = true;
            });

            aopsMock.Setup(i => i.GetAttachIds(mids)).Returns(fids);

            var ResultKillChatMessageAttachesAsync = false;

            aopsMock.Setup(i => i.KillChatMessageAttaches(mids))
                .Callback<Guid[]>(q =>
                {
                    ResultKillChatMessageAttachesAsync = true;
                });

            var ResultKillFilesAsync = false;
            fopsMock.Setup(i => i.KillFiles(fids)).Callback<Guid[]>(q =>
            {
                ResultKillFilesAsync = true;
            });

            var ResultKillMessagesAsync = false;

            mopsMock.Setup(i => i.KillMessages(guidToKill))
                .Callback<Guid>(q =>
                {
                    ResultKillMessagesAsync = true;
                });
            
            var oopsMock = new Mock<IOperationsOperations>();
            var popsMock = new Mock<IPartyOperations>();

            var ResultKillPartyAsync = false;

            popsMock.Setup(i => i.KillParty(guidToKill))
                .Callback<Guid>(q =>
                {
                    ResultKillPartyAsync = true;
                });

            var ResultKillChatAsync = false;

            copsMock.Setup(i => i.KillChat(guidToKill))
                .Callback<Guid>(q =>
                {
                    ResultKillChatAsync = true;
                });

            var uopsMock = new Mock<IUserOperations>();

            var dataOpsMock = new Mock<IDataStoreOps>();

            dataOpsMock.Setup(i => i.amops).Returns(amopsMock.Object);
            dataOpsMock.Setup(i => i.aops).Returns(aopsMock.Object);
            dataOpsMock.Setup(i => i.cops).Returns(copsMock.Object);
            dataOpsMock.Setup(i => i.fops).Returns(fopsMock.Object);
            dataOpsMock.Setup(i => i.mo).Returns(mopsMock.Object);
            dataOpsMock.Setup(i => i.nops).Returns(nopsMock.Object);
            dataOpsMock.Setup(i => i.oops).Returns(oopsMock.Object);
            dataOpsMock.Setup(i => i.pops).Returns(popsMock.Object);
            dataOpsMock.Setup(i => i.uo).Returns(uopsMock.Object);

            var hub = CreateChatHubWithClients(mockClients, "test_author", null, dataOpsMock.Object);

            Exception expected = null;
            
            try
            {
                await hub.KillChat(guidToKill);
            }
            catch (Exception ex)
            {
                expected = ex;
            }

            Assert.IsNull(expected);
            Assert.IsNotNull(result);
            Assert.IsTrue(ResultKillChatMessageNotificationsAsync);
            Assert.IsTrue(ResultKillChatMessageAttachesAsync);
            Assert.IsTrue(ResultKillFilesAsync);
            Assert.IsTrue(ResultKillMessagesAsync);
            Assert.IsTrue(ResultKillPartyAsync);
            Assert.IsTrue(ResultKillChatAsync);
        }

        [TestMethod]
        public async Task ChatHub_InviteUser_Success()
        {
            var mockClients = new Mock<IHubCallerConnectionContext<dynamic>>();

            object result = null;
            object result1 = null;

            dynamic caller = new ExpandoObject();

            caller.onUserInvited = new Func<object, Task>(
                async (param) =>
                {
                    await Task.Run(() => { result = param; });

                });

            caller.addMessage = new Func<ChatMessage, Task>(
                async (param) =>
                {
                    await Task.Run(() => { result1 = param; });

                });


            mockClients.Setup(m => m.Caller).Returns((ExpandoObject)caller);

            mockClients.Setup(m => m.Clients(It.IsAny<string[]>())).Returns((ExpandoObject)caller);

            var ResultCreateInviteAsync = false;

            var iopsMock = new Mock<IInviteOperations>();

            iopsMock.Setup(i => i.CreateInviteAsync(It.IsAny<Guid>(), It.IsAny<string>(), It.IsAny<string>()))
                .Callback<Guid, string, string>((a, b, c) =>
                {
                    ResultCreateInviteAsync = true;
                })
                .ReturnsAsync(new Invite());


            var guidChatToInvite = Guid.NewGuid();

            var party = new[] { "@test_author", "@qq", "@ttt" };

            var copsMock = new Mock<IChatOperationsAsync>();

            var ResultGetChatPartyAsync = false;

            copsMock.Setup(i => i.GetChatPartyAsync(It.IsAny<Guid>()))
                .Callback<Guid>(q =>
                {
                    ResultGetChatPartyAsync = true;
                    
                }).ReturnsAsync(party);

            var mopsMock = new Mock<IMessageOperations>();

            var message = new Data.Message()
            {
                Author = "@test_author",
                ChatID = guidChatToInvite,
                Created = DateTime.UtcNow,
                Text = $"Пользователь @test_author пригласил в чат пользователя @user",
                ID = Guid.NewGuid()
            };

            var ResultCreateInviteMessageAsync = false;

            mopsMock.Setup(i => i.CreateInviteMessageAsync(It.IsAny<Guid>(), It.IsAny<string>(), It.IsAny<string>()))
                .Callback<Guid, string, string>((a, b, c) =>
                {
                    ResultCreateInviteMessageAsync = true;
                })
                .ReturnsAsync(message);

            var amopsMock = new Mock<IAttachMetadataOperations>();

            var ResultGetMetadata = false;

            amopsMock.Setup(i => i.GetMetadata(It.IsAny<Guid>()))
                .Callback<Guid>(q =>
                {
                    ResultGetMetadata = true;
                })
                .Returns("jsonStringWithMetadata");

            var aopsMock = new Mock<IAttachmentOperations>();
            var fopsMock = new Mock<IFileStoreOperations>();
            var nopsMock = new Mock<INotificationOperations>();
            var oopsMock = new Mock<IOperationsOperations>();
            var popsMock = new Mock<IPartyOperations>();
            var uopsMock = new Mock<IUserOperations>();

            var dataOpsMock = new Mock<IDataStoreOps>();

            dataOpsMock.Setup(i => i.amops).Returns(amopsMock.Object);
            dataOpsMock.Setup(i => i.aops).Returns(aopsMock.Object);
            dataOpsMock.Setup(i => i.cops).Returns(copsMock.Object);
            dataOpsMock.Setup(i => i.fops).Returns(fopsMock.Object);
            dataOpsMock.Setup(i => i.mo).Returns(mopsMock.Object);
            dataOpsMock.Setup(i => i.nops).Returns(nopsMock.Object);
            dataOpsMock.Setup(i => i.oops).Returns(oopsMock.Object);
            dataOpsMock.Setup(i => i.pops).Returns(popsMock.Object);
            dataOpsMock.Setup(i => i.uo).Returns(uopsMock.Object);
            dataOpsMock.Setup(i => i.iops).Returns(iopsMock.Object);

            var hub = CreateChatHubWithClients(mockClients, "test_author", null, dataOpsMock.Object);

            Exception expected = null;

            try
            {
                await hub.InviteUser(guidChatToInvite.ToString(), "@putin", "@test_author");
            }
            catch (Exception ex)
            {
                expected = ex;
            }

            Assert.IsNull(expected);
            Assert.IsNotNull(result);
            Assert.IsNotNull(result1);

            Assert.IsTrue(ResultCreateInviteAsync);
            Assert.IsTrue(ResultGetChatPartyAsync);
            Assert.IsTrue(ResultCreateInviteMessageAsync);
            Assert.IsTrue(ResultGetMetadata);
        }

        [TestMethod]
        public async Task ChatHub_RejectInvite_Success()
        {
            var mockClients = new Mock<IHubCallerConnectionContext<dynamic>>();

            object result = null;
            object result1 = null;

            dynamic caller = new ExpandoObject();

            caller.onUserInviteRejected = new Func<string, Task>(
                async (param) =>
                {
                    await Task.Run(() => { result = param; });

                });

            caller.addMessage = new Func<ChatMessage, Task>(
                async (param) =>
                {
                    await Task.Run(() => { result1 = param; });

                });


            mockClients.Setup(m => m.Clients(It.IsAny<string[]>())).Returns((ExpandoObject)caller);

            var ResultGetAsync = false;

            var iopsMock = new Mock<IInviteOperations>();

            var invite = new Invite()
            {
                ChatId = Guid.NewGuid(),
                ID = Guid.NewGuid(),
                Created = DateTime.UtcNow,
                Invited = "@putin",
                Inviter = "@test_author",
            };

            iopsMock.Setup(i => i.GetAsync(It.IsAny<Guid>()))
                .Callback<Guid>((a) =>
                {
                    ResultGetAsync = true;
                })
                .ReturnsAsync(invite);

            var ResultRejectInviteAsync = false;

            iopsMock.Setup(i => i.RejectInviteAsync(invite))
                .Callback<Invite>((i) =>
                {
                    i.Accepted=DateTime.UtcNow;
                    i.IsInviteAccept = false;
                    ResultRejectInviteAsync = true;
                })
                .ReturnsAsync(invite);


            var party = new[] { "@test_author", "@qq", "@ttt" };

            var copsMock = new Mock<IChatOperationsAsync>();

            var ResultGetChatPartyAsync = false;

            copsMock.Setup(i => i.GetChatPartyAsync(It.IsAny<Guid>()))
                .Callback<Guid>(q =>
                {
                    ResultGetChatPartyAsync = true;

                }).ReturnsAsync(party);

            var mopsMock = new Mock<IMessageOperations>();

            var message = new Data.Message()
            {
                Author = "@invited",
                ChatID = invite.ChatId,
                Created = DateTime.UtcNow,
                Text = $"Пользователь @invited отклонил приглашение в чат",
                ID = Guid.NewGuid(),
            };

            var ResultCreateInviteRejectMessageAsync = false;

            mopsMock.Setup(i => i.CreateInviteRejectMessageAsync(It.IsAny<Guid>(), It.IsAny<string>()))
                .Callback<Guid, string>((a, b )=>
                {
                    ResultCreateInviteRejectMessageAsync = true;
                })
                .ReturnsAsync(message);

            var amopsMock = new Mock<IAttachMetadataOperations>();

            var ResultGetMetadata = false;

            amopsMock.Setup(i => i.GetMetadata(It.IsAny<Guid>()))
                .Callback<Guid>(q =>
                {
                    ResultGetMetadata = true;
                })
                .Returns("jsonStringWithMetadata");

            var aopsMock = new Mock<IAttachmentOperations>();
            var fopsMock = new Mock<IFileStoreOperations>();
            var nopsMock = new Mock<INotificationOperations>();
            var oopsMock = new Mock<IOperationsOperations>();
            var popsMock = new Mock<IPartyOperations>();
            var uopsMock = new Mock<IUserOperations>();

            var dataOpsMock = new Mock<IDataStoreOps>();

            dataOpsMock.Setup(i => i.amops).Returns(amopsMock.Object);
            dataOpsMock.Setup(i => i.aops).Returns(aopsMock.Object);
            dataOpsMock.Setup(i => i.cops).Returns(copsMock.Object);
            dataOpsMock.Setup(i => i.fops).Returns(fopsMock.Object);
            dataOpsMock.Setup(i => i.mo).Returns(mopsMock.Object);
            dataOpsMock.Setup(i => i.nops).Returns(nopsMock.Object);
            dataOpsMock.Setup(i => i.oops).Returns(oopsMock.Object);
            dataOpsMock.Setup(i => i.pops).Returns(popsMock.Object);
            dataOpsMock.Setup(i => i.uo).Returns(uopsMock.Object);
            dataOpsMock.Setup(i => i.iops).Returns(iopsMock.Object);

            var hub = CreateChatHubWithClients(mockClients, "test_author", null, dataOpsMock.Object);

            Exception expected = null;

            try
            {
                await hub.RejectInvite(invite.ID.ToString());
            }
            catch (Exception ex)
            {
                expected = ex;
            }

            Assert.IsNull(expected);
            Assert.IsNotNull(result);
            Assert.IsNotNull(result1);

            Assert.IsTrue(ResultGetAsync);
            Assert.IsTrue(ResultRejectInviteAsync);
            Assert.IsTrue(ResultGetChatPartyAsync);
            Assert.IsTrue(ResultCreateInviteRejectMessageAsync);
            Assert.IsTrue(ResultGetMetadata);
        }

        [TestMethod]
        public async Task ChatHub_AcceptInvite_Success()
        {
            var mockClients = new Mock<IHubCallerConnectionContext<dynamic>>();

            object result = null;
            object result1 = null;

            dynamic caller = new ExpandoObject();

            caller.onUserInviteAccepted = new Func<string, Task>(
                async (param) =>
                {
                    await Task.Run(() => { result = param; });

                });

            caller.addMessage = new Func<ChatMessage, Task>(
                async (param) =>
                {
                    await Task.Run(() => { result1 = param; });

                });


            mockClients.Setup(m => m.Clients(It.IsAny<string[]>())).Returns((ExpandoObject)caller);

            mockClients.Setup(m => m.Caller).Returns((ExpandoObject)caller);

            var ResultGetAsync = false;

            var iopsMock = new Mock<IInviteOperations>();

            var invite = new Invite()
            {
                ChatId = Guid.NewGuid(),
                ID = Guid.NewGuid(),
                Created = DateTime.UtcNow,
                Invited = "@putin",
                Inviter = "@test_author",
            };

            iopsMock.Setup(i => i.GetAsync(It.IsAny<Guid>()))
                .Callback<Guid>((a) =>
                {
                    ResultGetAsync = true;
                })
                .ReturnsAsync(invite);

            var ResultAcceptInviteAsync = false;

            iopsMock.Setup(i => i.AcceptInviteAsync(invite))
                .Callback<Invite>((i) =>
                {
                    i.Accepted = DateTime.UtcNow;
                    i.IsInviteAccept = true;
                    ResultAcceptInviteAsync = true;
                })
                .ReturnsAsync(invite);

            var copsMock = new Mock<IChatOperationsAsync>();

            var ResultupdateChatPartyAsync = false;

            copsMock.Setup(i => i.updateChatPartyAsync(It.IsAny<Guid>(), It.IsAny<string>()))
                .Callback<Guid, string>((q,s) =>
                {
                    ResultupdateChatPartyAsync = true;

                }).Returns(Task.CompletedTask);

            var party = new[] { "@test_author", "@qq", "@ttt" };

            

            var ResultGetChatPartyAsync = false;

            copsMock.Setup(i => i.GetChatPartyAsync(It.IsAny<Guid>()))
                .Callback<Guid>(q =>
                {
                    ResultGetChatPartyAsync = true;

                }).ReturnsAsync(party);

            var mopsMock = new Mock<IMessageOperations>();

            var message = new Data.Message()
            {
                Author = "@invited",
                ChatID = invite.ChatId,
                Created = DateTime.UtcNow,
                Text = $"Пользователь @invited отклонил приглашение в чат",
                ID = Guid.NewGuid(),
            };

            var ResultCreateInviteAcceptMessageAsync = false;

            mopsMock.Setup(i => i.CreateInviteAcceptMessageAsync(It.IsAny<Guid>(), It.IsAny<string>()))
                .Callback<Guid, string>((a, b) =>
                {
                    ResultCreateInviteAcceptMessageAsync = true;
                })
                .ReturnsAsync(message);

            var amopsMock = new Mock<IAttachMetadataOperations>();
            var aopsMock = new Mock<IAttachmentOperations>();
            var fopsMock = new Mock<IFileStoreOperations>();
            var nopsMock = new Mock<INotificationOperations>();
            var oopsMock = new Mock<IOperationsOperations>();
            var popsMock = new Mock<IPartyOperations>();
            var uopsMock = new Mock<IUserOperations>();

            var dataOpsMock = new Mock<IDataStoreOps>();

            dataOpsMock.Setup(i => i.amops).Returns(amopsMock.Object);
            dataOpsMock.Setup(i => i.aops).Returns(aopsMock.Object);
            dataOpsMock.Setup(i => i.cops).Returns(copsMock.Object);
            dataOpsMock.Setup(i => i.fops).Returns(fopsMock.Object);
            dataOpsMock.Setup(i => i.mo).Returns(mopsMock.Object);
            dataOpsMock.Setup(i => i.nops).Returns(nopsMock.Object);
            dataOpsMock.Setup(i => i.oops).Returns(oopsMock.Object);
            dataOpsMock.Setup(i => i.pops).Returns(popsMock.Object);
            dataOpsMock.Setup(i => i.uo).Returns(uopsMock.Object);
            dataOpsMock.Setup(i => i.iops).Returns(iopsMock.Object);

            var hub = CreateChatHubWithClients(mockClients, "test_author", null, dataOpsMock.Object);

            Exception expected = null;

            try
            {
                await hub.AcceptInvite(invite.ID.ToString());
            }
            catch (Exception ex)
            {
                expected = ex;
            }

            Assert.IsNull(expected);
            Assert.IsNotNull(result);
            Assert.IsNotNull(result1);

            Assert.IsTrue(ResultGetAsync);
            Assert.IsTrue(ResultAcceptInviteAsync);
            Assert.IsTrue(ResultupdateChatPartyAsync);
            Assert.IsTrue(ResultGetChatPartyAsync);
            Assert.IsTrue(ResultCreateInviteAcceptMessageAsync);
            
        }

        [TestMethod]
        public async Task ChatHub_DeleteInvite_Success()
        {
            var mockClients = new Mock<IHubCallerConnectionContext<dynamic>>();

            object result = null;
            dynamic caller = new ExpandoObject();

            caller.onInviteDeleted = new Func<string, Task>(
                async (param) => await Task.Run(() => { result = param; })
                );

            mockClients.Setup(m => m.Caller).Returns((ExpandoObject)caller);

            var ResultDeleteAsync = false;

            var iopsMock = new Mock<IInviteOperations>();

            var invite = new Invite()
            {
                ChatId = Guid.NewGuid(),
                ID = Guid.NewGuid(),
                Created = DateTime.UtcNow,
                Invited = "@putin",
                Inviter = "@test_author",
            };

            iopsMock.Setup(i => i.DeleteAsync(It.IsAny<Guid>()))
                .Callback<Guid>((a) =>
                {
                    ResultDeleteAsync = true;
                })
                .Returns(Task.CompletedTask);

            var copsMock = new Mock<IChatOperationsAsync>();
            var mopsMock = new Mock<IMessageOperations>();
            var amopsMock = new Mock<IAttachMetadataOperations>();
            var aopsMock = new Mock<IAttachmentOperations>();
            var fopsMock = new Mock<IFileStoreOperations>();
            var nopsMock = new Mock<INotificationOperations>();
            var oopsMock = new Mock<IOperationsOperations>();
            var popsMock = new Mock<IPartyOperations>();
            var uopsMock = new Mock<IUserOperations>();

            var dataOpsMock = new Mock<IDataStoreOps>();

            dataOpsMock.Setup(i => i.amops).Returns(amopsMock.Object);
            dataOpsMock.Setup(i => i.aops).Returns(aopsMock.Object);
            dataOpsMock.Setup(i => i.cops).Returns(copsMock.Object);
            dataOpsMock.Setup(i => i.fops).Returns(fopsMock.Object);
            dataOpsMock.Setup(i => i.mo).Returns(mopsMock.Object);
            dataOpsMock.Setup(i => i.nops).Returns(nopsMock.Object);
            dataOpsMock.Setup(i => i.oops).Returns(oopsMock.Object);
            dataOpsMock.Setup(i => i.pops).Returns(popsMock.Object);
            dataOpsMock.Setup(i => i.uo).Returns(uopsMock.Object);
            dataOpsMock.Setup(i => i.iops).Returns(iopsMock.Object);

            var hub = CreateChatHubWithClients(mockClients, "test_author", null, dataOpsMock.Object);

            Exception expected = null;

            try
            {
                await hub.DeleteInvite(invite.ID.ToString());
            }
            catch (Exception ex)
            {
                expected = ex;
            }

            Assert.IsNull(expected);
            Assert.IsNotNull(result);
            Assert.IsTrue(ResultDeleteAsync);

        }

        [TestMethod]
        public async Task ChatHub_SendMetadata_Success()
        {
            var mockClients = new Mock<IHubCallerConnectionContext<dynamic>>();

            object result = null;
            dynamic caller = new ExpandoObject();

            caller.onMetadataSent = new Func<byte, Task>(
                async (param) => await Task.Run(() => { result = param; })
                );

            mockClients.Setup(m => m.Caller).Returns((ExpandoObject)caller);

            var msid = Guid.NewGuid();

            var amopsMock = new Mock<IAttachMetadataOperations>();

            var ResultAddAttachMetadataAsync = false;

            amopsMock.Setup(i => i.AddAttachMetadataAsync(It.IsAny<string>(), It.IsAny<Guid>()))
                .Callback<string, Guid>((s, g) =>
                {
                    ResultAddAttachMetadataAsync = true;
                })
                .ReturnsAsync(new AttachMedatada());

            var iopsMock = new Mock<IInviteOperations>();
            var copsMock = new Mock<IChatOperationsAsync>();
            var mopsMock = new Mock<IMessageOperations>();
            
            var aopsMock = new Mock<IAttachmentOperations>();
            var fopsMock = new Mock<IFileStoreOperations>();
            var nopsMock = new Mock<INotificationOperations>();
            var oopsMock = new Mock<IOperationsOperations>();
            var popsMock = new Mock<IPartyOperations>();
            var uopsMock = new Mock<IUserOperations>();

            var dataOpsMock = new Mock<IDataStoreOps>();

            dataOpsMock.Setup(i => i.amops).Returns(amopsMock.Object);
            dataOpsMock.Setup(i => i.aops).Returns(aopsMock.Object);
            dataOpsMock.Setup(i => i.cops).Returns(copsMock.Object);
            dataOpsMock.Setup(i => i.fops).Returns(fopsMock.Object);
            dataOpsMock.Setup(i => i.mo).Returns(mopsMock.Object);
            dataOpsMock.Setup(i => i.nops).Returns(nopsMock.Object);
            dataOpsMock.Setup(i => i.oops).Returns(oopsMock.Object);
            dataOpsMock.Setup(i => i.pops).Returns(popsMock.Object);
            dataOpsMock.Setup(i => i.uo).Returns(uopsMock.Object);
            dataOpsMock.Setup(i => i.iops).Returns(iopsMock.Object);

            var hub = CreateChatHubWithClients(mockClients, "test_author", null, dataOpsMock.Object);

            Exception expected = null;

            try
            {
                var metaOrig = "[{\"name\":\"Chrysanthemum.jpg\",\"size\":879394,\"type\":\"image/jpeg\"}]";

                var encoded = System.Uri.EscapeUriString(Convert.ToBase64String(Encoding.Default.GetBytes(metaOrig)));

                await hub.SendMetadata(msid, encoded);
            }
            catch (Exception ex)
            {
                expected = ex;
            }

            Assert.IsNull(expected);
            Assert.IsNotNull(result);
            Assert.IsTrue(ResultAddAttachMetadataAsync);

        }

        [TestMethod]
        public async Task ChatHub_LeaveChat_Success()
        {
            var mockClients = new Mock<IHubCallerConnectionContext<dynamic>>();

            object result = null;
            dynamic caller = new ExpandoObject();

            caller.onUserLeftChat = new Func<object, Task>(
                async (param) => await Task.Run(() => { result = param; })
                );

            mockClients.Setup(m => m.All).Returns((ExpandoObject)caller);

            var id = Guid.NewGuid();

            var amopsMock = new Mock<IAttachMetadataOperations>();

            var iopsMock = new Mock<IInviteOperations>();
            var copsMock = new Mock<IChatOperationsAsync>();

            var ResultRemoveChatUserAsync = false;

            copsMock.Setup(i => i.RemoveChatUserAsync(It.IsAny<Guid?>(), It.IsAny<string>()))
                .Callback<Guid?, string>((g, s) =>
                {
                    ResultRemoveChatUserAsync = true;

                }).Returns(Task.CompletedTask);


            var mopsMock = new Mock<IMessageOperations>();

            var aopsMock = new Mock<IAttachmentOperations>();
            var fopsMock = new Mock<IFileStoreOperations>();
            var nopsMock = new Mock<INotificationOperations>();
            var oopsMock = new Mock<IOperationsOperations>();
            var popsMock = new Mock<IPartyOperations>();
            var uopsMock = new Mock<IUserOperations>();

            var dataOpsMock = new Mock<IDataStoreOps>();

            dataOpsMock.Setup(i => i.amops).Returns(amopsMock.Object);
            dataOpsMock.Setup(i => i.aops).Returns(aopsMock.Object);
            dataOpsMock.Setup(i => i.cops).Returns(copsMock.Object);
            dataOpsMock.Setup(i => i.fops).Returns(fopsMock.Object);
            dataOpsMock.Setup(i => i.mo).Returns(mopsMock.Object);
            dataOpsMock.Setup(i => i.nops).Returns(nopsMock.Object);
            dataOpsMock.Setup(i => i.oops).Returns(oopsMock.Object);
            dataOpsMock.Setup(i => i.pops).Returns(popsMock.Object);
            dataOpsMock.Setup(i => i.uo).Returns(uopsMock.Object);
            dataOpsMock.Setup(i => i.iops).Returns(iopsMock.Object);

            var hub = CreateChatHubWithClients(mockClients, "test_author", null, dataOpsMock.Object);

            Exception expected = null;

            try
            {
                await hub.LeaveChat(id, "@test_author");
            }
            catch (Exception ex)
            {
                expected = ex;
            }

            Assert.IsNull(expected);
            Assert.IsNotNull(result);
            Assert.IsTrue(ResultRemoveChatUserAsync);

        }

        [TestMethod]
        public async Task ChatHub_CreateGroupChat_Success()
        {
            var mockClients = new Mock<IHubCallerConnectionContext<dynamic>>();

            object result = null;

            dynamic caller = new ExpandoObject();

            caller.onGroupChatCreated = new Func<Chat, Task>(
                async (param) => await Task.Run(() => { result = param; })
                );

            caller.onNewChatCreated = new Func<Chat, Task>(
                async (param) => await Task.Run(() => { result = param; })
                );

            mockClients.Setup(m => m.Caller).Returns((ExpandoObject)caller);

            mockClients.Setup(m => m.Clients(It.IsAny<string[]>())).Returns((ExpandoObject)caller);

            var id = Guid.NewGuid();

            var amopsMock = new Mock<IAttachMetadataOperations>();

            var iopsMock = new Mock<IInviteOperations>();
            var copsMock = new Mock<IChatOperationsAsync>();

            var ResultCreateChatAsync = false;

            var chat=new Chat();


            copsMock.Setup(i => i.CreateChatAsync(It.IsAny<Chat>()))
                .Callback<Chat>(q =>
                {
                    chat.Author = q.Author;
                    chat.Title = q.Title;
                    chat.Party = q.Party;
                    ResultCreateChatAsync = true;
                })
                .ReturnsAsync(chat);

            var mopsMock = new Mock<IMessageOperations>();

            var aopsMock = new Mock<IAttachmentOperations>();
            var fopsMock = new Mock<IFileStoreOperations>();
            var nopsMock = new Mock<INotificationOperations>();
            var oopsMock = new Mock<IOperationsOperations>();
            var popsMock = new Mock<IPartyOperations>();
            var uopsMock = new Mock<IUserOperations>();

            var dataOpsMock = new Mock<IDataStoreOps>();

            dataOpsMock.Setup(i => i.amops).Returns(amopsMock.Object);
            dataOpsMock.Setup(i => i.aops).Returns(aopsMock.Object);
            dataOpsMock.Setup(i => i.cops).Returns(copsMock.Object);
            dataOpsMock.Setup(i => i.fops).Returns(fopsMock.Object);
            dataOpsMock.Setup(i => i.mo).Returns(mopsMock.Object);
            dataOpsMock.Setup(i => i.nops).Returns(nopsMock.Object);
            dataOpsMock.Setup(i => i.oops).Returns(oopsMock.Object);
            dataOpsMock.Setup(i => i.pops).Returns(popsMock.Object);
            dataOpsMock.Setup(i => i.uo).Returns(uopsMock.Object);
            dataOpsMock.Setup(i => i.iops).Returns(iopsMock.Object);

            var hub = CreateChatHubWithClients(mockClients, "test_author", null, dataOpsMock.Object);

            Exception expected = null;

            try
            {
                await hub.CreateGroupChat(new []{"@putin","@test_author","@qqq"}, "group chat test title","@test_author");
            }
            catch (Exception ex)
            {
                expected = ex;
            }

            Assert.IsNull(expected);
            Assert.IsNotNull(result);
            Assert.IsTrue(ResultCreateChatAsync);

        }

        [TestMethod]
        public async Task ChatHub_SendMessageNotification3_Success()
        {
            var mockClients = new Mock<IHubCallerConnectionContext<dynamic>>();

            object result = null;

            dynamic caller = new ExpandoObject();

            caller.getMessageReadStatus = new Func<dynamic, Task>(
                async (param) =>
                {
                    await Task.Run(() => { result = param; });

                });

            // mockClients.Setup(m => m.Caller).Returns((ExpandoObject)caller);

            mockClients.Setup(m => m.Caller).Returns((ExpandoObject)caller);

            var hub = CreateChatHubWithClients(mockClients,"putin_test");
            

            Exception expected = null;

            try
            {
                await hub.SendMessageNotification3("ED7A2E13-0404-45AB-8F01-210B988FE8CF", DateTime.Now, "client descr");
            }
            catch (Exception ex)
            {
                expected = ex;
            }

            Assert.IsNull(expected);
            Assert.IsNotNull(result);
        }

    }
}
