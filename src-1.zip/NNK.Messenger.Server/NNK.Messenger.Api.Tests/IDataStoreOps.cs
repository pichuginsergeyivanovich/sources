using NNK.Messenger.Business;

namespace NNK.Messenger.Api.Tests
{
    public interface IDataStoreOps
    {
        IChatOperations cops { get; set; }
        IAttachMetadataOperations amops { get; set; }
        IMessageOperations mo { get; set; }
        IUserOperations uo { get; set; }
        IOperationsOperations oops { get; set; }
        IAttachmentOperations aops { get; set; }
        IFileStoreOperations fops { get; set; }
        INotificationOperations nops { get; set; }
        IPartyOperations pops { get; set; }

        IInviteOperations iops { get; set; }
    }
}