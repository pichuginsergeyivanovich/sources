﻿using NNK.Messenger.Business;
using NNK.Messenger.Business.Dapper;
using NNK.Messenger.Core;

namespace NNK.Messenger.Api.Tests
{
    public class DataStoreOps : IDataStoreOps
    {
        public class DapperConnectionStringProvider : IDapperConnectionStringProvider
        {
            public string ConnectionString => "Data Source = 10.1.41.60; Initial Catalog = NNK.Messenger.Test; Integrated Security = False; User Id=test; Password=test; ";
        }
        public class DapperAspNetIdentityConnectionStringProvider : IDapperConnectionStringProvider
        {
            public string ConnectionString => "Data Source = 10.1.41.60; Initial Catalog = AspNet.Identity.Test; Integrated Security = False; User Id=test; Password=test; ";
        }
        public DataStoreOps()
        {
            var dp=new DapperConnectionStringProvider();

            var dpi = new DapperAspNetIdentityConnectionStringProvider();

            this.pops = new PartyOperations(dp);

            this.cops = new ChatOperations(dp,pops); 

            this.amops=new AttachMetadataOperations(dp);

            this.mo=new MessageOperations(dp, cops, amops);

            this.uo=new UserOperations(dpi);

            this.oops=new OperationsOperations(dp);

            this.fops = new FileStoreOperations(dp);

            this.aops=new AttachmentOperations(fops, dp);
            
            this.nops=new NotificationOperations(dp);

            this.iops=new InviteOperations(dp);
        }

        public IChatOperations cops { get; set; }

        public IAttachMetadataOperations amops { get; set; }

        public IMessageOperations mo { get; set; }

        public IUserOperations uo { get; set; }

        public IOperationsOperations oops { get; set; }

        public IAttachmentOperations aops { get; set; }

        public IFileStoreOperations fops { get; set; }

        public INotificationOperations nops { get; set; }

        public IPartyOperations pops { get; set; }

        public IInviteOperations iops { get; set; }
    }
}
