﻿namespace NNK.Logging { 
    public interface ILogParametersProvider
    {
        string LogPath { get; }
    }
}
