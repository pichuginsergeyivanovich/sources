﻿using System;

namespace NNK.Logging
{
    public interface ILogger
    {
        void Error(Exception ex);
        void Message(string text);
    }
}
