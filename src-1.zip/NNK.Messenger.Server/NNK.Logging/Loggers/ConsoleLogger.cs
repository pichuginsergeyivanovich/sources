﻿using System;

namespace NNK.Logging.Loggers
{
    public class ConsoleLogger:ILogger
    {
        public void Error(Exception ex)
        {
            Console.WriteLine("{0} - Error - {1}", DateTime.Now.ToUniversalTime(), ex);
        }

        public void Message(string text)
        {
            Console.WriteLine("{0} - Info - {1}", DateTime.Now.ToUniversalTime(), text);
        }
    }
}
