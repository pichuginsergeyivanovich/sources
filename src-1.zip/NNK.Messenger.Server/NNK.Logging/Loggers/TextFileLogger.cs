﻿using System;
using System.IO;

namespace NNK.Logging.Loggers
{
    public class TextFileLogger:ILogger
    {
        string _logPath;
        public TextFileLogger(ILogParametersProvider logPathProvider)
        {
            _logPath = logPathProvider.LogPath;
        }
        string logFile
        {
            get
            {
                var LogFile = Path.Combine(_logPath, $"{DateTime.Now.ToUniversalTime():yyyyMMdd}_log.txt");

                return LogFile;
            }
        }
        public void Error(Exception ex)
        {
            WriteLine("{0} - Error - {1}", DateTime.Now.ToUniversalTime(), ex);
        }

        void WriteLine(string format, params object[] args)
        {
            lock (logFile)
            {
                using (var filestream = new FileStream(logFile, FileMode.Append,FileAccess.Write,FileShare.ReadWrite))
                {
                    var streamwriter = new StreamWriter(filestream);

                    streamwriter.AutoFlush = true;

                    streamwriter.WriteLine(format, args);

                    filestream.Flush();

                    filestream.Close();
                }
            }
        }

        public void Message(string text)
        {
            WriteLine("{0} - Info - {1}", DateTime.Now.ToUniversalTime(), text);
        }


    }
}
