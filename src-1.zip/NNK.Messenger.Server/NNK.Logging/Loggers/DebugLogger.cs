﻿using System;
using System.Diagnostics;

namespace NNK.Logging.Loggers
{
    public class DebugLogger:ILogger
    {
        public void Error(Exception ex)
        {
            Debug.WriteLine("{0} - Error - {1}", DateTime.Now.ToUniversalTime(), ex);
        }

        public void Message(string text)
        {
            Debug.WriteLine("{0} - Info - {1}", DateTime.Now.ToUniversalTime(), text);
        }
    }
}
