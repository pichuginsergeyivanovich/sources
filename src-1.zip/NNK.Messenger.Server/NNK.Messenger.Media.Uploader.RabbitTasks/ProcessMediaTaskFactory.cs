﻿using System.Collections.Generic;
using System.IO;
using System.Net.Http;
using System.Threading.Tasks;

namespace NNK.Messenger.Media.Uploader.RabbitTasks
{
    public class ProcessMediaTaskFactory
    {
        public static async Task<IEnumerable<ProcessMediaTask>> From(HttpRequestMessage request, string msid, string mediaTempDir, string fileStorageDbLevelName, string user, string author, string text, string chatId)
        {
            var files = await request.Content.ReadAsMultipartAsync(new MultipartMemoryStreamProvider());

            var l = new List<ProcessMediaTask>();

            foreach (var f in files.Contents)
            {
                var filename = f.Headers.ContentDisposition.FileName;

                filename = filename.Replace("\"", "");

                var bytes = await f.ReadAsByteArrayAsync();

                var src = $"\\\\localhost\\MSSQLSERVER\\{fileStorageDbLevelName}\\FileAttach\\{msid}_{filename}";

                if (!Directory.Exists(mediaTempDir))
                    Directory.CreateDirectory(mediaTempDir);

                var fpath = Path.Combine(mediaTempDir, $"{msid}_{filename}");

                if (!File.Exists(fpath))
                    File.WriteAllBytes(fpath, bytes);

                l.Add(new ProcessMediaTask
                    {
                        msid = msid,
                        user = user,
                        src = src,
                        tmp = fpath,
                        filename = filename,
                        author = author,
                        text = text,
                        chatid = chatId
                    });
            }
            return l;
        }
        public static async Task<IEnumerable<ProcessMediaTask>> From(HttpRequestMessage request, string msid, string mediaTempDir, string fileStorageDbLevelName, string user, string author, string text, string chatId, string party)
        {
            var files = await request.Content.ReadAsMultipartAsync(new MultipartMemoryStreamProvider());

            var l = new List<ProcessMediaTask>();

            foreach (var f in files.Contents)
            {
                var filename = f.Headers.ContentDisposition.FileName;

                filename = filename.Replace("\"", "");

                var bytes = await f.ReadAsByteArrayAsync();

                var src = $"\\\\localhost\\MSSQLSERVER\\{fileStorageDbLevelName}\\FileAttach\\{msid}_{filename}";

                if (!Directory.Exists(mediaTempDir))
                    Directory.CreateDirectory(mediaTempDir);

                var fpath = Path.Combine(mediaTempDir, $"{msid}_{filename}");

                if (!File.Exists(fpath))
                    File.WriteAllBytes(fpath, bytes);

                l.Add(new ProcessMediaTask
                {
                    msid = msid,
                    user = user,
                    src = src,
                    tmp = fpath,
                    filename = filename,
                    author = author,
                    text = text,
                    chatid = chatId,
                    party = party
                });
            }
            return l;
        }
    }
}
