﻿using System;
using System.IO;
using System.Threading.Tasks;
using NNK.Logging;
using NNK.Messenger.Business;
using NNK.RabbitMQ.Core;
using RabbitMQ.Client;
using RabbitMQ.Client.Events;

namespace NNK.Messenger.Media.Uploader.RabbitTasks
{
    public class RabbitMqProcessMediaTaskResolver:IRabbitMqTaskResolver
    {
        private readonly ILogger _logger;
        private readonly ICryptoOperations _crops;
        private readonly IFileStoreOperations _fops;
        private readonly IAttachmentOperations _aops;
        private readonly IAttachMetadataOperations _amops;
        private readonly IChatOperations _cops;
        private readonly IMessageOperations _mops;
        private readonly IRabbitMqTaskNotifier _notifier;
        private readonly IRabbitMqTaskNotifier _pnotifier;
        private readonly byte[] _key;
        private string _host;

        public RabbitMqProcessMediaTaskResolver(
            ILogger logger, 
            ICryptoOperations crops, 
            IFileStoreOperations fops, 
            IAttachmentOperations aops, 
            IAttachMetadataOperations amops, 
            IChatOperations cops, 
            IMessageOperations mops, 
            IRabbitMqTaskNotifier notifier,
            IRabbitMqTaskNotifier pnotifier,
            byte[] key,
            string host)
        {
            _logger = logger;

            _crops = crops;

            _fops = fops;

            _aops = aops;

            _amops = amops;

            _cops = cops;

            _mops = mops;

            _notifier = notifier;

            _pnotifier = pnotifier;

            _key = key;

            _host = host;
        }
        public void ResolveTask(object sender, BasicDeliverEventArgs ea)
        {
            _logger.Message("==============================================");

            var task = RabbitMqTaskFactory.Instance.DeserializeTask(ea.Body) as IRabbitMqTask;

            if (task is ProcessMediaTask)
            {
                //lock ((task as ProcessMediaTask).tmp)
                {
                    ProcessTask(task as ProcessMediaTask, _key);
                }
            }

            _logger.Message("==============================================");

        }
        private void ProcessTask(ProcessMediaTask t, byte[] skey)
        {
            try
            {
                t.src = t.src.Replace("\\localhost\\", $"\\{_host}\\");

                t.filename = new FileInfo(t.tmp).Name;

                if (!File.Exists(t.tmp))
                {
                    _logger.Message($"ERROR!!! FILE NOT EXIST {t.tmp}: SKIPPING! ");

                    return;
                }


                _logger.Message($"begin process file: {t.filename} for msid: {t.msid}");
                _logger.Message($"src: {t.src}");
                _logger.Message($"tmp: {t.tmp}");

                _crops.EncryptFile(skey, t.tmp, t.src + ".secret");

                var fsar = _fops.GetFileStoreAddResult($"{t.filename}.secret");

                var at = _aops.AddAttachment(Guid.Parse(t.msid), fsar.stream_id, fsar.unc_path);

                //_amops.LinkAttachMetadata(at);
                _amops.LinkAttachMetadataTransacted(at);

                int total;

                int attached;

                var progress = _amops.VeryfyAttachMetadata(at, out total, out attached) ?? 0;

                var m = _mops.Get(Guid.Parse(t.msid));

                if (progress == 1 && m==null)
                {

                    _logger.Message($"{t.msid}:{t.filename} progress: {progress * 100:#.00}% ({attached}/{total})");


                    try
                    {
                        Guid chatIdAsGuid;

                        var party = Guid.TryParse(t.chatid, out chatIdAsGuid)?_cops.GetChatParty(chatIdAsGuid):new string[0];

                        var messageParty = string.IsNullOrEmpty(t.party) ? string.Join(",", party) : t.party;

                        var dbMessage = new ChatControllerProxy(_cops, _mops).PostMessage2(t.author, t.text, messageParty, t.chatid, DateTime.Now.ToUniversalTime(), Guid.Parse(t.msid));

                    }
                    catch (Exception ex)
                    {
                        _logger.Error(ex);
                    }

                    try
                    {
                        _pnotifier?.Notify(new ProcessMediaProgressTask()
                        {
                            user = t.user,
                            total = total,
                            msid = t.msid,
                            uploaded = attached,
                            percentage = progress * 100
                        });
                    }
                    catch (Exception e)
                    {
                        _logger.Error(e);
                    }

                    try
                    {
                         _notifier?.Notify(t);
                    }
                    catch (Exception e)
                    {
                        _logger.Error(e);
                    }


                    try
                    {
                        if (File.Exists(t.tmp))
                            File.Delete(t.tmp);
                    }
                    catch (Exception e)
                    {
                        _logger.Error(e);
                    }




                }
                else
                {
                    _logger.Message($"{t.msid}:{t.filename} progress: {progress * 100:#.00}% ({attached}/{total})");

                    try
                    {
                        _pnotifier?.Notify(new ProcessMediaProgressTask()
                        {
                            user = t.user,
                            total = total,
                            msid = t.msid,
                            uploaded = attached,
                            percentage = progress * 100
                        });
                    }
                    catch (Exception e)
                    {
                        _logger.Error(e);
                    }
                }




                _logger.Message($"end process file: {t.filename} for msid: {t.msid}");
            }
            catch (Exception ex)
            {
                _logger.Error(ex);

                throw;
            }
        }

        public void ResolveTask(BasicGetResult result)
        {
            throw new NotImplementedException();
        }
    }
}
