﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using NNK.RabbitMQ.Core;

namespace NNK.Messenger.Media.Uploader.RabbitTasks
{
    [Serializable]
    public class ProcessMediaProgressTask:IRabbitMqTask
    {
        public string msid { get; set; }
        public string user { get; set; }

        public int uploaded { get; set; }

        public int total { get; set; }

        public decimal percentage { get; set; }
    }
}
