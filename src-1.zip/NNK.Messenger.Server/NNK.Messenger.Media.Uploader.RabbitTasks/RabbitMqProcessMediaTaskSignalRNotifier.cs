﻿using System;
using System.Threading;
using System.Threading.Tasks;
using Microsoft.AspNet.SignalR.Client;
using Microsoft.AspNet.SignalR.Client.Hubs;
using NNK.Logging;
using NNK.RabbitMQ.Core;

namespace NNK.Messenger.Media.Uploader.RabbitTasks
{
    public class RabbitMqProcessMediaTaskSignalRNotifier:IRabbitMqTaskNotifier
    {
        private readonly ILogger _logger;

        private readonly string _hubUrl;

        public RabbitMqProcessMediaTaskSignalRNotifier(ILogger logger, string hubUrl)
        {
            _logger = logger;

            _hubUrl = hubUrl;
        }

        public async Task Notify(IRabbitMqTask task)
        {

            if (task is ProcessMediaTask)
            {
                var t = (ProcessMediaTask) task;

                _logger.Message($"try send complete notification for {t.msid} user: {t.user}");

                try
                {
                    var c = new HubConnection(_hubUrl);
                    //var c = new HubConnection("http://127.0.0.1:80");

                    var h = new HubProxy(c, "systemAgentHub");

                    var retries = 10;

                    while (retries > 0)
                    {

                        try
                        {
                            await c.Start();

                            await h.Invoke("OnResendConfirmedAttachMessagePrivate", t.msid, t.user);

                            retries = 0;
                        }
                        catch (Exception ex)
                        {
                            _logger.Error(ex);
                            retries--;
                            Thread.Sleep(1000);

                        }
                    }
                }
                catch (Exception ex)
                {
                    _logger.Error(ex);
                }
            }
        }
    }
}
