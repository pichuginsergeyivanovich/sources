﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using NNK.RabbitMQ.Core;

namespace NNK.Messenger.Media.Uploader.RabbitTasks
{
    [Serializable]
    public class ProcessMediaTask:IRabbitMqTask
    {
        public string msid { get; set; }
        public string user { get; set; }
        public string src { get; set; }
        public string tmp { get; set; }
        public string filename { get; set; }
        public string author { get; set; }
        public string text { get; set; }
        public string chatid { get; set; }
        public string party { get; set; }
    }
}
