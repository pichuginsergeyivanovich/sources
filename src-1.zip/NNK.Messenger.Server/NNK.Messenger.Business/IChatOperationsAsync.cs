using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using NNK.Messenger.Data;

namespace NNK.Messenger.Business
{
    public interface IChatOperationsAsync
    {
        Party[] GetChatByParty(string author, string party);
        Chat CreateChat(Chat inserted);
        Task<Chat> CreateChatAsync(Chat inserted);
        vw_user_chat_list[] GetChatList(string user, string msgChkSum = null);
        Task<vw_user_chat_list[]> GetChatListAsync(string user);
        string[] GetChatIDsList(string user);
        Task<string[]> GetChatIDsListAsync(string user);
        Task<Chat[]> GetAllChatsListAsync(string user, string timeLabel = null);
        Party[] GetAllParty(string user, string timeLabel = null);
        Task<Party[]> GetAllPartyAsync(string user, string timeLabel = null);
        string[] GetChatParty(Guid chatId);
        Task<IEnumerable<string>> GetChatPartyAsync(Guid chatId);
        Task KillChatAsync(Guid chatId);
        Task<Chat> GetAsync(Guid chatId);
        Task updateChatPartyAsync(Guid chatId, string user);
        Task RemoveChatUserAsync(Guid? chatId, string user);
        Task<bool> IsUserChatAsync(Guid chatId, string user);
    }
}