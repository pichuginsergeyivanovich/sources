﻿using System.Collections.Generic;
using System.Threading.Tasks;
using NNK.Messenger.AspNetIdentity;

namespace NNK.Messenger.Business
{
    public interface IUserOperations
    {
        IEnumerable<string> GetList();
        IEnumerable<vw_User> GetListForSync(string timeLabel = null);
        void Dispose();
        bool GetByLogin(string login);
        bool GetByPhone(string phone);
        bool GetByEmail(string email);
        vw_User GetByName(string user);

        void ResetUserPassword(string user);


    }
}