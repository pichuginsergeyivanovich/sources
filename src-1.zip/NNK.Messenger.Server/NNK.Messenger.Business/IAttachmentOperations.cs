using System;
using System.Threading.Tasks;
using NNK.Messenger.Data;

namespace NNK.Messenger.Business
{
    public interface IAttachmentOperations
    {
        void LinkToMessage(Guid messageId, FileStore_Add_Result[] loadedFileStreams);
        Attach AddAttachment(Guid messageId, string fileName, byte[] fileData);
        Attach AddAttachment(Guid messageId, Guid streamId, string uncPath);

        Attach[] GetMessageAttachments(Guid? messageId);

        Attach[] GetChatAttachments(Guid? chatId);
        
        string GetMessageAttachmentsVirtualUrls(Guid? messageId, Action<string> copyFunc, string host);
        Guid[] GetAttachIds(Guid[]mids);
        void KillChatMessageAttaches(Guid[] mids);

        Attach[] CloneAttach(Guid messageId, Guid newMessageId);

        Attach Get(int attachId);
        FileStore_Add_Result ProxyAddFile(byte[] ebytes, string filename);
    }
}