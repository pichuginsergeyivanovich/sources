﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Threading.Tasks;
using Dapper;
using NNK.Messenger.Core;
using NNK.Messenger.Data;

namespace NNK.Messenger.Business.Dapper
{
    public class NotificationOperations : BaseDapperConnection, INotificationOperations
    {
        public NotificationOperations(IDapperConnectionStringProvider provider) : base(provider)
        {
        }

        public void AddNotification(NotificationTypeEnum type, Guid sid, DateTime clientDate, string clientDescr, string cip, string username)
        {

            var i = new Notification()
            {
                id = Guid.NewGuid(),
                messageId = sid,
                type = (byte) type,
                clientDate = clientDate,
                clientDescr = clientDescr,
                clientIp = cip,
                created = DateTime.Now.ToUniversalTime(),
                username = username

            };
            Execute(db =>
            {
                db.Execute(
                    "insert dbo.Notification(id, messageId, type, clientDate, clientDescr, clientIp, created, username) values(@id, @messageId, @type, @clientDate, @clientDescr, @clientIp, @created, @username)",
                    i);
            });


        }

        public dynamic GetChangeStatusSids(Guid chatId)
        {
            return ExecuteQuery(db =>
            {
                var res =
                    db.Query<dynamic>("dbo.[sp_ChangeStatus] @chatId", new { chatId= chatId}).ToArray();

                return res;
            });
        }
        public bool AnyByMsidAndType(Guid msid, byte type)
        {
            return ExecuteQuery(db =>
            {
                var res =
                    db.Query<Notification>(
                        "select * from dbo.Notification(nolock) where messageId = @msid and type=@type",
                        new {msid, type}).ToArray();

                return res.Any();
            });
        }

        public IEnumerable<Guid> AddBulkNotification(NotificationTypeEnum type, Guid chatid, DateTime clientDate, string clientDescr, string cip, string username)
        {

            return ExecuteQuery(db =>
            {

                var msgs = db.Query<Guid>(
                    "select ID from dbo.Message(nolock) where ChatID=@chatId and (StatusRead is null or StatusRead=0) union 	select m.ID from dbo.Message m left join [dbo].[Notification] n(nolock) on n.type=2 and n.messageId=m.id  and n.username=@username where ChatID =@chatId and n.id is null",
                    new {chatId = chatid, username= username }).ToArray();


                var notifs = msgs.Select(i => new Notification()
                {
                    id = Guid.NewGuid(),
                    messageId = i,
                    type = (byte) type,
                    clientDate = clientDate,
                    clientDescr = clientDescr,
                    clientIp = cip,
                    created = DateTime.Now.ToUniversalTime(),
                    username = username
                });


                foreach (var n in notifs)
                {
                    var res =
                        db.Query<Guid>(
                            "select id from dbo.Notification(nolock) where messageId = @messageId and type=@type and username=@username", n);

                    if (!res.Any())
                    {
                        db.Execute(
                            "insert dbo.Notification(id, messageId, type, clientDate, clientDescr, clientIp, created, username) values(@id, @messageId, @type, @clientDate, @clientDescr, @clientIp, @created, @username)",
                            n);
                    }
                }

                return msgs;

            });
        }



        public void KillChatMessageNotifications(Guid[] mids)
        {
            Execute(db =>
            {
                var midsString = string.Join(",", mids.Select(i=>$"'{i}'"));

                db.Execute($"delete from dbo.Notification where messageId in ({midsString})");
                
            });
        }

        public IEnumerable<Notification> GetNotifications(Guid sid)
        {
            return ExecuteQuery(db =>db.Query<Notification>($"select * from Notification where MessageId=@sid", new { sid }));
        }

        public IEnumerable<Notification> GetNotifications(Guid sid, NotificationTypeEnum type)
        {
            return ExecuteQuery(db => db.Query<Notification>($"select * from Notification where MessageId=@sid and Type=@type", new { sid, type }));
        }

    }
}
