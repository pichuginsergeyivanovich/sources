﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Dapper;
using NNK.Messenger.Core;
using NNK.Messenger.Data;

namespace NNK.Messenger.Business.Dapper
{
    public class IdentityOperations : BaseDapperConnection, IIdentityOperations
    {
        public IdentityOperations(IDapperConnectionStringProvider provider) : base(provider)
        {
        }

        public void RegisterUserKeys(int uid, byte[] identityKey, byte[] signedPreKey, byte[] signedPreKeyHash, Queue<byte[]> oneTimeKeyQueue)
        {
            
            var exist = ExecuteQuery(db => db.Query<Identity>("select * from dbo.[Identity] where ObjectId=@uid", new { uid }))?.FirstOrDefault();

            if (exist != null)
            {
                exist.IdentityKey = identityKey;

                exist.SignedPreKey = (signedPreKey == null || signedPreKey.Length < 32) ? PushOperations.BytesFromHexString("D1432CF37AF0FE4F99EC09F4B391B63D7F2116D64E8A2465552637FC874ED91E") : signedPreKey;

                exist.ModifyOn = DateTime.UtcNow;

                Execute(
                    db =>
                        db.Execute(
                            "update dbo.[Identity] set IdentityKey=@IdentityKey, SignedPreKey=@SignedPreKey, ModifyOn=@ModifyOn  where ObjectId=@ObjectId",
                            exist));
            }
            else
            {
                var item = new Data.Identity()
                {
                    IdentityKey = identityKey,
                    ObjectId = uid,
                    SignedPreKey = (signedPreKey == null || signedPreKey.Length < 32) ? PushOperations.BytesFromHexString("D1432CF37AF0FE4F99EC09F4B391B63D7F2116D64E8A2465552637FC874ED91E") : signedPreKey,
                    PreKey = signedPreKeyHash,
                    CreateOn = DateTime.Now.ToUniversalTime(),
                    ModifyOn = DateTime.Now.ToUniversalTime()
                };
                Execute(
                    db =>
                        db.Execute(
                            "insert into dbo.[Identity] (IdentityKey, ObjectId, SignedPreKey, PreKey, CreateOn, ModifyOn) values (@IdentityKey, @ObjectId, @SignedPreKey, @PreKey, @CreateOn, @ModifyOn)",
                            item));


            }






            //using (var ctx = new MessengerEntities()){
                /*var clearExistDevKey = await ctx.Identity.Where(i => i.SignedPreKey == signedPreKey).ToArrayAsync();

                if (clearExistDevKey.Any())
                {

                    foreach (var u in clearExistDevKey)
                    {
                        u.SignedPreKey = null;
                    }

                    await ctx.SaveChangesAsync();
                }*/


                /*
                var exist = await ctx.Identity.FirstOrDefaultAsync(i => i.ObjectId == uid);

                if (exist != null)
                {
                    exist.IdentityKey = identityKey;

                    exist.SignedPreKey = (signedPreKey==null || signedPreKey.Length<32)? PushOperations.BytesFromHexString("D1432CF37AF0FE4F99EC09F4B391B63D7F2116D64E8A2465552637FC874ED91E"): signedPreKey;

                    exist.ModifyOn = DateTime.UtcNow;

                    await ctx.SaveChangesAsync();
                }
                else
                {
                    var item = new Data.Identity()
                    {
                        IdentityKey = identityKey,
                        ObjectId = uid,
                        SignedPreKey = (signedPreKey == null || signedPreKey.Length < 32) ? PushOperations.BytesFromHexString("D1432CF37AF0FE4F99EC09F4B391B63D7F2116D64E8A2465552637FC874ED91E") : signedPreKey,
                        PreKey = signedPreKeyHash,
                        CreateOn = DateTime.Now.ToUniversalTime(),
                        ModifyOn = DateTime.Now.ToUniversalTime()
                    };


                    ctx.Identity.Add(item);

                    await ctx.SaveChangesAsync();
                }*/
            //}
        }

        public Data.Identity Get(int uid)
        {
            return ExecuteQuery(db => db.Query<Identity>("select * from dbo.[Identity] where ObjectId=@uid", new { uid }))?.FirstOrDefault();
        }

        public bool IsDeviceTokenOnUser(int uid, byte[] devtoken)
        {
            var uidIdentity = Get(uid);

            var token = uidIdentity.SignedPreKey;

            var lastIdentityWithToken= ExecuteQuery(db => db.Query<Identity>("select top 1 * from dbo.[Identity] where SignedPreKey=@token order by ModifyOn desc", new { token=token }))?.FirstOrDefault();

            return uid == lastIdentityWithToken?.ObjectId;

        }

        public void CleanDevToken(int uid, byte[]devtoken)
        {
            Execute(
                 db =>
                     db.Execute("update dbo.[Identity] set SignedPreKey=0xD1432CF37AF0FE4F99EC09F4B391B63D7F2116D64E8A2465552637FC874ED91E where ObjectId=@uid and SignedPreKey=@devtoken",new {devtoken, uid}));
        }
    }


}
