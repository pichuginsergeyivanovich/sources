﻿using System;
using System.Linq;
using Dapper;
using Newtonsoft.Json;
using NNK.Messenger.Core;
using NNK.Messenger.Data;

namespace NNK.Messenger.Business.Dapper
{
    public class AttachmentOperations : BaseDapperConnection, IAttachmentOperations
    {
        private readonly IFileStoreOperations _fops;

        public AttachmentOperations(IFileStoreOperations fops, IDapperConnectionStringProvider provider) : base(provider)
        {
            _fops = fops;
        }

        public void LinkToMessage(Guid messageId, FileStore_Add_Result[] loadedFileStreams)
        {
            var items = loadedFileStreams.Select(i =>
                new Attach
                {
                    MessageID = messageId,
                    stream_id = i.stream_id,
                    FilePath = i.unc_path
                }).ToArray();

            Execute(db =>db.Execute("insert dbo.Attach (MessageID, stream_id, FilePath) values(@MessageID, @stream_id, @FilePath)",items));

        }

        public Attach[] CloneAttach(Guid messageId, Guid newMessageId)
        {
            //Execute(db => db.Execute("insert dbo.Attach (MessageID, stream_id, FilePath) select @newMessageId, stream_id, FilePath FROM [NNK.Messenger].[dbo].[Attach] where MessageID=@messageId", new { messageId, newMessageId }));

            return ExecuteQuery(db =>
               db.Query<Attach>(
                   "insert dbo.Attach (MessageID, stream_id, FilePath) select @newMessageId, stream_id, FilePath FROM [NNK.Messenger].[dbo].[Attach] where MessageID=@messageId; select * from dbo.Attach (nolock) where MessageID=@newMessageId"
                   , new { messageId, newMessageId }
                   )?.ToArray()

           );
        }



        public Attach AddAttachment(Guid messageId, string fileName, byte[] fileData)
        {

            var fileAddResult = _fops.AddFile(fileName, fileData);

            var att = new Attach
            {
                MessageID = messageId,
                stream_id = fileAddResult.stream_id,
                FilePath = fileAddResult.unc_path
            };

            return ExecuteQuery(db =>
                db.Query<Attach>(
                    "insert dbo.Attach (MessageID, stream_id, FilePath) values(@MessageID, @stream_id, @FilePath); select * from dbo.Attach (nolock) where MessageID=@MessageID and stream_id=@stream_id",
                    att)?.FirstOrDefault()
            );
        }
        public Attach AddAttachment(Guid messageId, Guid streamId, string uncPath)
        {

            //var fileAddResult = _fops.AddFile(fileName, fileData);

            var att = new Attach
            {
                MessageID = messageId,
                stream_id = streamId,
                FilePath = uncPath
            };

            return ExecuteQuery(db =>
                db.Query<Attach>(
                    "insert dbo.Attach (MessageID, stream_id, FilePath) values(@MessageID, @stream_id, @FilePath); select * from dbo.Attach (nolock) where MessageID=@MessageID and stream_id=@stream_id",
                    att)?.FirstOrDefault()
            );
        }
        public FileStore_Add_Result ProxyAddFile(byte[] fileData, string fileName)
        {
            return _fops.AddFile(fileName, fileData);
        }

        public Attach[] GetMessageAttachments(Guid? messageId)
        {
            return ExecuteQuery(db => db.Query<Attach>("select * from dbo.Attach (nolock) where MessageID=@MessageID",new { MessageID =messageId}))?.ToArray();
        }
        public Attach[] GetChatAttachments(Guid? chatId)
        {
            return ExecuteQuery(db => db.Query<Attach>("SELECT a.* FROM [NNK.Messenger].[dbo].[Attach] a(nolock) left join dbo.Message m (nolock) on m.ID=a.MessageID where m.ChatID=@chatId", new { chatId = chatId }))?.ToArray();
        }
        public Attach Get(int attachId)
        {
            return ExecuteQuery(db => db.Query<Attach>("select * from dbo.Attach (nolock) where ID=@attachId", new { attachId = attachId }))?.FirstOrDefault();
        }
        public Guid[] GetAttachIds(Guid[] mids)
        {
            var msidAsString = string.Join(",", mids.Select(i => $"{i}"));

            return ExecuteQuery(db => db.Query<Guid>("select stream_id from dbo.Attach (nolock) where MessageID in (@msidAsString)", new { msidAsString }))?.ToArray();
        }
        public string GetMessageAttachmentsVirtualUrls(Guid? messageId, Action<string> copyFunc, string host)
        {
            var res = GetMessageAttachments(messageId);

            if (copyFunc != null)
            {
                foreach (var f in res)
                {
                    copyFunc(f.FilePath);
                }
            }

            Func<Attach[], string> a = (aa) =>
            {
                var atts = aa.Select(i =>
                      new {
                          url = i.FilePath.Replace(@"\\localhost\MSSQLSERVER\MSSQLSERVER\FileAttach\", $@"http://{host}:8080/api/chat/attach/")
                                        .Replace(@"\\DMZDOM-MSG-01\MSSQLSERVER\MSSQLSERVER\FileAttach\", $@"http://{host}:8080/api/chat/attach/"),
                          name = i.FilePath.Replace(@"\\localhost\MSSQLSERVER\MSSQLSERVER\FileAttach\", ""),
                          attachId = i.ID,
                          messageId = i.MessageID
                      }
                ).ToArray();

                var obj = JsonConvert.SerializeObject(atts, new JsonSerializerSettings() { StringEscapeHandling = StringEscapeHandling.EscapeHtml });

                return obj;
            };


            return a(res);
        }

        public void KillChatMessageAttaches(Guid[] mids)
        {
            var msidAsString = string.Join(",", mids.Select(i => $"{i}"));

            Execute(db => db.Execute("delete from dbo.Attach where MessageID in (@msidAsString)", new { msidAsString }));
        }
    }
}
