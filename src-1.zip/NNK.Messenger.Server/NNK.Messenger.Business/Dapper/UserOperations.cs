﻿using System;
using System.Collections.Generic;
using System.Linq;
using Dapper;
using NNK.Messenger.AspNetIdentity;
using NNK.Messenger.Core;

namespace NNK.Messenger.Business.Dapper
{
    public class UserOperations : BaseDapperConnection, IUserOperations 
    {
        public UserOperations(IDapperConnectionStringProvider provider) : base(provider)
        {
        }

        public IEnumerable<string> GetList()
        {
            return ExecuteQuery(db => db.Query<string>($"select '@'+UserName from dbo.[User]"));
        }

        public IEnumerable<vw_User> GetListForSync(string timeLabel = null)
        {
            return ExecuteQuery(db =>
            {
                var builder = new SqlBuilder();

                var template = builder.AddTemplate("select * from dbo.vw_User /**where**/ /**orderby**/");

                if (!string.IsNullOrEmpty(timeLabel))
                {
                    var dtFilter = DateTime.Parse(timeLabel);

                    builder.Where("Modified >= '@dtFilter'", new[] { dtFilter });
                }

                builder.OrderBy("UserName");

                return db.Query<vw_User>(template.RawSql, template.Parameters);

            });
        }

        public bool GetByLogin(string login)
        {
            return
                ExecuteQuery(
                    db =>
                        db.Query<string>($"select top 1 UserName from dbo.[User] where UserName=@UserName",
                            new {UserName = login}))?.FirstOrDefault() != null;
        }

        public bool GetByPhone(string phone)
        {
            return
                ExecuteQuery(
                    db =>
                        db.Query<string>("select top 1 UserName from dbo.[User] where PhoneNumber=@phone",
                            new { phone }))?.FirstOrDefault() != null;
        }

        public bool GetByEmail(string email)
        {
            return
                ExecuteQuery(
                    db =>
                        db.Query<string>("select top 1 UserName from dbo.[User] where Email=@email",
                            new { email }))?.FirstOrDefault() != null;
        }

        public vw_User GetByName(string user)
        {
            user = user.Replace("@", "");

            return ExecuteQuery(db => db.Query<vw_User>("select top 1 * from dbo.[User] where UserName=@user",new {user}))?.FirstOrDefault();
        }

        public void ResetUserPassword(string user)
        {
            user = user.Replace("@", "");

            ExecuteQuery(db => db.Execute("update dbo.[User] set PasswordHash=NULL, AccessFailedCount=5 where UserName=@user", new { user }));

        }
        public void Dispose()
        {
            
        }
    }
}
