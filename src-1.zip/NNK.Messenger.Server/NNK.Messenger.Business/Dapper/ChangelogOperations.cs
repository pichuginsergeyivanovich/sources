﻿using System;
using System.Collections.Generic;
using System.Linq;
using Dapper;
using NNK.Messenger.Core;
using NNK.Messenger.Data;

namespace NNK.Messenger.Business.Dapper
{
    public class ChangelogOperations : BaseDapperConnection, IChangelogOperations
    {
        public ChangelogOperations(IDapperConnectionStringProvider provider): base(provider)
        {
        }
        public Changelog GetLast()
        {
            return ExecuteQuery(db => db.Query<Changelog>("select top 1 * from dbo.Changelog order by created desc")?.FirstOrDefault());
        }
        public Changelog Get(string version)
        {
            return ExecuteQuery(db => db.Query<Changelog>("select top 1 * from dbo.Changelog where Version=@version order by created desc",new {version})?.FirstOrDefault());
        }
        public Changelog GetByStamp(Guid stamp)
        {
            return ExecuteQuery(db => db.Query<Changelog>("select top 1 * from dbo.Changelog where Stamp=@stamp order by created desc", new { stamp })?.FirstOrDefault());
        }
        public string GetNextLinkForStamp(Guid stamp)
        {
            var nextLink = Guid.NewGuid();

            Execute(db => { db.Execute("insert dbo.ChangeLogStat(VersionStamp, UrlLinkParam ) values(@stamp, @nextLink)", new {stamp, nextLink }); });

            return nextLink.ToString();
        }
        public Changelog GetByLinkedStamp(Guid lstamp)
        {

            var item =
                ExecuteQuery(
                    db =>
                        db.Query<ChangeLogStat>("select top 1 * from dbo.ChangeLogStat where UrlLinkParam=@lstamp",
                            new {lstamp})?.FirstOrDefault());



            return GetByStamp(item.VersionStamp);
        }


    }
}
