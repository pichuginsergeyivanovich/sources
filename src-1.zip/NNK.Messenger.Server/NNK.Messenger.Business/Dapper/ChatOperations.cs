﻿using System;
using System.Collections.Generic;
using System.Linq;
using Dapper;
using NNK.Messenger.Core;
using NNK.Messenger.Data;

namespace NNK.Messenger.Business.Dapper
{
    public class ChatOperations :BaseDapperConnection, IChatOperations
    {
        private readonly IPartyOperations _pops;

        public ChatOperations(IDapperConnectionStringProvider provider, IPartyOperations pops) : base(provider)
        {
            _pops = pops;
        }

        public Chat CreateChat(Chat inserted, Guid?newChatId=null)
        {
            var key = newChatId ?? Guid.NewGuid();

            var chat = new Chat
            {
                ID = key,
                Author = inserted.Author,
                Created = DateTime.Now.ToUniversalTime(),
                Party = inserted.Party,
                Title = inserted.Title,
                Tags = inserted.Tags,
                IsHidden = inserted.IsHidden,
                PasswordHash = inserted.PasswordHash,
                IsGroup = inserted.IsGroup
            };


            var party = chat.Party.Split(new[] {","}, StringSplitOptions.None).ToList();

            if (!party.Contains(chat.Author))
                party.Add(chat.Author);

            if (party.Any())
                chat.Party = string.Join(",", party);

            Execute(
                (db) =>
                    db.Execute(
                        "insert dbo.Chat (ID,Author,Created,Party,Title,Tags,IsHidden,PasswordHash, IsGroup) values(@ID,@Author,@Created,@Party,@Title,@Tags,@IsHidden,@PasswordHash,@IsGroup) ",
                        chat));




            if (party.Any())
            {
                var partyItems = party.Select(i => new Party {ChatID = key, User = i}).Distinct();

                foreach (var pi in partyItems)
                {
                    Execute((db) => db.Execute("insert dbo.Party(ChatID,[User]) values(@ChatID, @User)", pi));
                }



            }
           return chat;
        }

        public Chat GetChatFromParty(string partyAsString, string user)
        {
            var partyList =
                partyAsString.Split(new[] { "," }, StringSplitOptions.RemoveEmptyEntries)
                    .Select(i => i.Trim())
                    .ToList();

            partyList.Remove("empty");

            if (!partyList.Contains(user))
                partyList.Add(user);

            var party = partyList.Distinct().ToList();

            if (party.Count != 2)
                return null;

            var chats = ExecuteQuery(db => db.Query<Chat>("select * from dbo.Chat c where c.Author=@user and c.IsGroup=0 and c.IsHidden=0", new { user })?.ToArray());

            foreach (var c in chats)
            {
                if (c.PartyAsArray().Contains(party[0]) && c.PartyAsArray().Contains(party[1]))
                    return c;
            }
            return null;

        }

        public vw_user_chat_list[] GetChatList(string user, string msgChkSum = null)
        {

            var chats = ExecuteQuery(db =>
            {
                var r = db.Query<vw_user_chat_list>("select distinct * from dbo.vw_user_chat_list where [user]=@user order by last_created desc", new { user });

                return r.ToArray();
            });


            if (msgChkSum == null)
                return chats;

            var l = new List<vw_user_chat_list>();

            foreach (var c in chats)
            {
                var ch = ExecuteQuery(db =>
                {
                    var r = db.Query<vw_user_chat_list>("select * from dbo.vw_user_chat_list where msg_checksum=@msg_checksum", new { msg_checksum= msgChkSum });

                    return r;
                }); 

                if (ch == null)
                    continue;

                l.Add(c);
            }

            return l.ToArray();

        }
       
        public string[] GetChatIDsList(string user)
        {
            return ExecuteQuery(db =>
            {
                var r = db.Query<Guid>("select chat_id from dbo.vw_user_chat_list where [user]=@user", new { user });

                return r.Select(i=>i.ToString()).ToArray();
            });
        }
        public  Chat[] GetAllChatsList(string user, string timeLabel = null)
        {
            if (timeLabel != null)
            {
                var dtFilter = DateTime.Parse(timeLabel);

                return ExecuteQuery(db =>
                {
                    var res = db.Query<Chat>("select * from dbo.Chat where ID in (select chat_id from dbo.vw_user_chat_list where [user] = @user and Created >= '@dtFilter')",
                        new {user, dtFilter});

                    return res.ToArray();
                });
            }
            return ExecuteQuery(db =>
            {
                var res = db.Query<Chat>("select * from dbo.Chat where ID in (select chat_id from dbo.vw_user_chat_list where [user] = @user)", new { user });

                return res.ToArray();
            });
        }

        public Party[] GetAllParty(string user, string timeLabel = null)
        {
            var chats = GetChatIDsList(user);

            var chatIds = $"({string.Join(", ", chats.Select(i => $"'{i}'"))})";

            if (timeLabel != null)
            {
                var dtFilter = DateTime.Parse(timeLabel);

                return ExecuteQuery( db =>
                {
                    var res =  db.Query<Party>("select * from dbo.Party where ChatID in ( @chatIds) and Created > '@dtFilter'", new { chatIds,  dtFilter });

                    return res.ToArray();
                });
            }
            return ExecuteQuery(db =>
            {
                var res = db.Query<Party>("select * from dbo.Party where ChatID in ( @chatIds)", new { chatIds });

                return res.ToArray();
            });
        }

        public string[] GetChatParty(Guid chatId)
        {
            return ExecuteQuery(db =>
            {
                var res = db.Query<string>("select [User] from dbo.Party where ChatID = @chatId", new { chatId });

                return res.ToArray();
            });
        }

        public Chat Get(Guid chatId)
        {
            return ExecuteQuery(db =>db.Query<Chat>("select * from dbo.Chat where ID = @chatId", new { chatId })?.FirstOrDefault());
        }
        public bool Exist(Guid chatId)
        {
            var id =
                ExecuteQuery(
                    db =>
                        db.Query<Guid>("select id from dbo.Chat(nolock) where ID = @chatId", new {chatId})?.FirstOrDefault());

            return id != null && !id.Equals(Guid.Empty);
        }
        public void KillChat(Guid chatId)
        {
           Execute((db) => db.Execute("delete from dbo.Chat where ID=@chatId",new {chatId}));
        }

        public void UpdateChatParty(Guid chatId, string user)
        {
            var party = GetChatParty(chatId).Distinct().ToList();

            var cont = party.Contains(user);

            if (!cont)
            {
                party.Add(user);
            }

            var partyString = string.Join(",", party);
          
            Execute(db =>db.Execute("update dbo.Chat set Party = @partyString where ID = @chatId", new { partyString , chatId}));

            if (!cont)
                _pops.LinkPartyToChat(new[] {user}, chatId);

        }

        public void RemoveChatUser(Guid chatId, string user)
        {

            var party = GetChatParty(chatId).Distinct().ToList();

            var cont = party.Contains(user);

            if (cont)
            {
                party.Remove(user);
            }

            var partyString = string.Join(",", party);

            Execute(db =>db.Execute("update dbo.Chat set Party = @partyString where ID = @chatId", new {partyString, chatId}));

            if (cont)
                _pops.RemoveChatUser(user, chatId);
        }

        public bool IsUserChat(Guid chatId, string user)
        {

            var list = GetChatIDsList(user);

            var a = list.Select(Guid.Parse).ToArray();

            return a.Contains(chatId);
        }

        public void UpdateChatTitle(Guid chatId, string newtitle)
        {

            Execute(db => db.Execute("update dbo.Chat set Title = @newtitle where ID = @chatId", new { newtitle, chatId }));

        }

        public void SetChatImageStreamId(Guid chatId, Guid? fileStreamId)
        {
            Execute(db => db.Execute("update dbo.Chat set ImageAvatarStreamId = @fileStreamId where ID = @chatId", new { fileStreamId, chatId }));
        }
        public Guid? GetChatImageStreamId(Guid chatId)
        {
            return ExecuteQuery(db => db.Query<Guid?>("select ImageAvatarStreamId from dbo.Chat(nolock) where ID = @chatId", new { chatId })?.FirstOrDefault());
        }
    }
}
