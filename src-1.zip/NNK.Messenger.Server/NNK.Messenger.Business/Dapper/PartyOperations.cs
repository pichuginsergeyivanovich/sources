﻿using System;
using System.Collections.Generic;
using System.Linq;
using Dapper;
using NNK.Messenger.Core;
using NNK.Messenger.Data;

namespace NNK.Messenger.Business.Dapper
{
    public class PartyOperations : BaseDapperConnection, IPartyOperations
    {
        public PartyOperations(IDapperConnectionStringProvider provider) : base(provider)
        {
        }

        public void LinkPartyToChat(string user, Guid chatId)
        {
            LinkPartyToChat(new[] { user }, chatId);
        }

        public void KillParty(Guid chatId)
        {
            Execute(db =>db.Execute("delete from dbo.Party where ChatID = @chatId", new { chatId }));
        }

        public IEnumerable<Party> GetChatParty(Guid? chatId)
        {
            return ExecuteQuery(db =>db.Query<Party>("select * from dbo.Party where ChatID = @chatId", new { chatId }));
        }
        public Party GetChatUserParty(Guid? chatId, string user)
        {
            return ExecuteQuery(db => db.Query<Party>("select * from dbo.Party where ChatID = @chatId and [User]=@user", new { chatId, user })?.FirstOrDefault());
        }

        public void RemoveChatUser(string user, Guid? chatId)
        {
            var chatUserParty = GetChatUserParty(chatId, user);

            Execute(db =>
            {
                db.Execute("delete from dbo.Party where Id = @Id", new {Id = chatUserParty.Id});
            });
        }

        public void LinkPartyToChat(string[] party, Guid chatId)
        {
            foreach (var p in party)
            {
                var exist = GetChatUserParty(chatId, p);

                if (exist == null)
                {
                    Execute(db =>
                    {
                        db.Execute("insert dbo.Party(ChatID, [User], Created) values(@chatId, @user, @created)",
                            new {chatId, user = p, created = DateTime.Now.ToUniversalTime()});
                    });
                }
            }

        }
    }
}
