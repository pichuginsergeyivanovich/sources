﻿using System;
using System.Collections.Generic;
using System.Linq;
using Dapper;
using NNK.Messenger.Core;
using NNK.Messenger.Data;

namespace NNK.Messenger.Business.Dapper
{
    public class ProfileOperations : BaseDapperConnection, IProfileOperations
    {
        public ProfileOperations(IDapperConnectionStringProvider provider) : base(provider)
        {
        }
        public Profile GetProfile(int userId)
        {
            return ExecuteQuery(db => db.Query<Profile>("select * from dbo.Profile where UserID = @userId", new { userId })?.FirstOrDefault());
        }

        public bool ExistProfile(int userId)
        {
            return ExecuteQuery(db => db.Query<Profile>("select UserID from dbo.Profile where UserID = @userId", new { userId })?.FirstOrDefault()!=null);
        }

        public void SaveProfile(int userId, Profile p)
        {
            var exist = ExistProfile(userId);

            if (exist)
            {
                Execute(db =>
                {
                    db.Execute("update dbo.Profile set DeletedMsgIDs = @DeletedMsgIDs, SettingsPinEnabled = @SettingsPinEnabled, SettingsPinCode = @SettingsPinCode, SettingsTouchIdEnabled = @SettingsTouchIdEnabled, Created = @Created, Contacts = @Contacts, SettingsIsLocalNotificationsEnabled = @SettingsIsLocalNotificationsEnabled, SettingsSoundsEnabled = @SettingsSoundsEnabled, ImageAvatarStreamId  = @ImageAvatarStreamId where UserID = @UserID",
                        new { UserID = userId, p.DeletedMsgIDs, p.SettingsPinEnabled, p.SettingsPinCode, p.SettingsTouchIdEnabled, p.Created, p.Contacts, p.SettingsIsLocalNotificationsEnabled, p.SettingsSoundsEnabled, p.ImageAvatarStreamId }
                        );
                });
            }
            else
            {
                Execute(db =>
                {
                    db.Execute("insert dbo.Profile(UserID, DeletedMsgIDs, SettingsPinEnabled, SettingsPinCode, SettingsTouchIdEnabled, Created, Contacts, SettingsIsLocalNotificationsEnabled, SettingsSoundsEnabled, ImageAvatarStreamId)" +
                               " values(@UserID, @DeletedMsgIDs, @SettingsPinEnabled, @SettingsPinCode, @SettingsTouchIdEnabled, @Created, @Contacts, @SettingsIsLocalNotificationsEnabled, @SettingsSoundsEnabled, @ImageAvatarStreamId)",
                    new { UserID =userId, p.DeletedMsgIDs, p.SettingsPinEnabled, p.SettingsPinCode, p.SettingsTouchIdEnabled,p.Created,p.Contacts,p.SettingsIsLocalNotificationsEnabled, p.SettingsSoundsEnabled, p.ImageAvatarStreamId}
                    );
                });
            }
        }

        public void DeleteProfile(int userId)
        {
            Execute(db =>
            {
                db.Execute("delete from dbo.Profile where UserId = @Id", new {Id = userId});
            });
        }

        public Guid? GetProfileImage(int userId)
        {
            return ExecuteQuery(db => db.Query<Guid?>("select ImageAvatarStreamId from dbo.Profile where UserID = @userId", new { userId })?.FirstOrDefault());
        }
    }
}
