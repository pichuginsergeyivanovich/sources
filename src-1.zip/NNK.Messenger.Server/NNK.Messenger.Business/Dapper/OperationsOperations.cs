﻿using System;
using System.Linq;
using System.Text;
using System.Threading;
using Dapper;
using NNK.Messenger.Core;
using NNK.Messenger.Data;

namespace NNK.Messenger.Business.Dapper
{
    public class OperationsOperations: BaseDapperConnection, IOperationsOperations
    {
        public OperationsOperations(IDapperConnectionStringProvider provider) : base(provider)
        {
        }

        public Operation Add(string id, string method, string data)
        {
            var bytes = Convert.FromBase64String(data);

            var decodedString = Encoding.UTF8.GetString(bytes);

            var op = new Operation
            {
                ID = Guid.NewGuid(),
                Data = decodedString,
                Created = DateTime.Now.ToUniversalTime(),
                Method = method,
                Name = id,
                Type = 1 //sms
            };

            return ExecuteQuery(db => db.Query<Operation>("insert into dbo.Operation(ID, Data, Created, Method, Name, Type) values(@ID, @Data, @Created, @Method, @Name, @Type);" +
                                               "select top 1 * from dbo.Operation where ID=@ID", op))?.FirstOrDefault();
        }

        public Operation Confirm(string idDecoded, string codeDecoded)
        {
            var gid = Guid.Parse(idDecoded);

            return ExecuteQuery(db =>
            {
                var op =
                    db.Query<Operation>("select top 1 * from dbo.Operation where ID=@ID", new {ID = gid})?
                        .FirstOrDefault();

                if (op == null)
                    throw new ApplicationException("Операция для подтверждения отсутствует!");

                db.Execute("update dbo.Operation set ConfirmCode=@codeDecoded where ID=@ID", new {codeDecoded, ID = gid });

                var isOperationConfirmed = db.Query<bool>("select IsOperationConfirmed from dbo.Operation where ID=@ID", new { codeDecoded, ID = gid }).FirstOrDefault();

                if (isOperationConfirmed)
                {
                    db.Execute("update dbo.Operation set ConfirmCodeCreated=@created where ID=@ID", new { created= DateTime.Now.ToUniversalTime(), ID = gid });

                    return db.Query<Operation>("select top 1 * from dbo.Operation where ID=@ID", op)?.FirstOrDefault();
                }

                return null;
            });
        }

        public void OperationProcessedCreated(Guid? updated)
        {
            if (updated == null)
                return;

            var op = GetById(updated.Value);

            if (op == null)
                return;

            Execute(
                db =>
                    db.Execute("update dbo.Operation set OperationProcessedCreated=@OperationProcessedCreated",
                        new {OperationProcessedCreated = DateTime.Now.ToUniversalTime()}));

        }

        public Operation GetConfirmSecretCode(Guid id)
        {
            Execute(db => db.Execute("exec sp_gen_code"));

            return GetById(id);
        }

        public Operation GetById(Guid operationId)
        {
            return ExecuteQuery(db => db.Query<Operation>("select top 1 * from dbo.Operation where ID=@ID", new {ID = operationId}))?.FirstOrDefault();
        }

        public void DeleteOperation(Guid id)
        {
            Execute(db => db.Execute("delete from dbo.Operation where ID=@id", new { id }));
        }


    }
}
