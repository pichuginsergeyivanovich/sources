﻿using System;
using System.Collections.Generic;
using System.Linq;
using Dapper;
using NNK.Messenger.Core;
using NNK.Messenger.Data;

namespace NNK.Messenger.Business.Dapper
{
    public class UserSessionOperations : BaseDapperConnection, IUserSessionOperations
    {
        public UserSessionOperations(IDapperConnectionStringProvider provider) : base(provider)
        {
        }


        public IEnumerable<UserSession> GetUserSessions()
        {
            return ExecuteQuery(db =>db.Query<UserSession>("select * from dbo.UserSession"));
        }

        public void RemoveUserSession(Guid connectionId)
        {
            Execute(db =>
            {
                db.Execute("delete from dbo.UserSession where ConnectionId=@ConnectionId", new { ConnectionId = connectionId });
            });
        }
        public void AddUserSession(UserSession us)
        {
            Execute(db =>
            {
                db.Execute("insert dbo.UserSession(ConnectionId, Username) values(@ConnectionId, @Username)",us);
            });
        }
    }
}
