﻿using System;
using System.Linq;
using System.Threading.Tasks;
using Dapper;
using NNK.Messenger.Core;
using NNK.Messenger.Data;

namespace NNK.Messenger.Business.Dapper
{
    public class InviteOperations : BaseDapperConnection, IInviteOperations
    {
        public InviteOperations(IDapperConnectionStringProvider provider) : base(provider)
        {
        }

//        public async Task<Invite> CreateInviteAsync(Guid chat, string inviter, string user)
//        {
//            var item = new Invite
//            {
//                ID = Guid.NewGuid(),
//                ChatId = chat,
//                Created = DateTime.Now.ToUniversalTime(),
//                Inviter = inviter,
//                Invited = user
//            };
//
//            return await Task.Run(() =>
//                ExecuteQuery(db =>
//                    db.Query<Invite>(
//                        "insert into dbo.Invite(ID, ChatId, Created, Inviter, Invited) values(@ID, @ChatId, @Created, @Inviter, @Invited);" +
//                        "select * from dbo.Invite (nolock) where ID=@ID",
//                        item)
//                )?.FirstOrDefault());
//        }
//        public async Task<Invite[]> GetAllByUserAsync(string user, bool fresh = true)
//        {
//            return await Task.Run(() => ExecuteQuery(db =>
//                db.Query<Invite>(
//                    "select * from dbo.Invite (nolock) where Invited=@user",
//                    new { user }))?.ToArray());
//        }
//        public async Task<Invite> GetAsync(Guid id)
//        {
//            return await Task.Run(() => ExecuteQuery(db =>
//                db.Query<Invite>(
//                    "select * from dbo.Invite (nolock) where ID=@id",
//                    new { id }))?.FirstOrDefault());
//        }
//        public async Task<Invite> AcceptInviteAsync(Invite invite)
//        {
//            return await Task.Run(() => ExecuteQuery(db =>
//                db.Query<Invite>(
//                    "update dbo.Invite set Accepted=@Accepted, IsInviteAccept=1 where where ID=@id;" +
//                    "select * from dbo.Invite (nolock) where ID=@id",
//                    invite))?.FirstOrDefault());
//        }
//        public async Task<Invite> RejectInviteAsync(Invite invite)
//        {
//            return await Task.Run(() => ExecuteQuery(db =>
//                db.Query<Invite>(
//                    "update dbo.Invite set Accepted=@Accepted, IsInviteAccept=0 where where ID=@id;" +
//                    "select * from dbo.Invite (nolock) where ID=@id",
//                    invite))?.FirstOrDefault());
//        }
//        public async Task DeleteAsync(Guid inviteId)
//        {
//            await Task.Run(
//                () => ExecuteQuery(db => db.Execute("delete from dbo.Invite where where ID=@inviteId", new { inviteId })));
//        }
        public Invite CreateInvite(Guid chat, string inviter, string user, bool? hidden=false)
        {
            var item = new Invite
            {
                ID = Guid.NewGuid(),
                ChatId = chat,
                Created = DateTime.Now.ToUniversalTime(),
                Inviter = inviter,
                Invited = user,
                IsHidden = hidden
            };

            return ExecuteQuery(db =>
                db.Query<Invite>(
                    "insert into dbo.Invite(ID, ChatId, Created, Inviter, Invited, IsHidden) values(@ID, @ChatId, @Created, @Inviter, @Invited, @IsHidden);" +
                    "select * from dbo.Invite (nolock) where ID=@ID",
                    item))?.FirstOrDefault();
        }


        public Invite[] GetAllByUser(string user, bool fresh = true)
        {
            return ExecuteQuery(db =>
                db.Query<Invite>(
                    "select * from dbo.Invite (nolock) where Invited=@user",
                    new {user}))?.ToArray();
        }

        public Invite Get(Guid id)
        {
            return ExecuteQuery(db =>
                db.Query<Invite>(
                    "select * from dbo.Invite (nolock) where ID=@id",
                    new {id}))?.FirstOrDefault();
        }

        public Invite AcceptInvite(Invite invite)
        {
            return ExecuteQuery(db =>
                db.Query<Invite>(
                    "update dbo.Invite set Accepted=@Accepted, IsInviteAccept=1 where ID=@ID;" +
                    "select * from dbo.Invite (nolock) where ID=@ID",
                    new {Accepted = DateTime.Now.ToUniversalTime(), ID = invite.ID}))?.FirstOrDefault();
        }

        public Invite RejectInvite(Invite invite)
        {
            return ExecuteQuery(db =>
                db.Query<Invite>(
                    "update dbo.Invite set Accepted=@Accepted, IsInviteAccept=0 where ID=@ID;" +
                    "select * from dbo.Invite (nolock) where ID=@ID",
                    new {Accepted = DateTime.Now.ToUniversalTime(), ID = invite.ID}))?.FirstOrDefault();
        }

        public void Delete(Guid inviteId)
        {
            ExecuteQuery(db => db.Execute("delete from dbo.Invite where ID=@inviteId", new { inviteId }));
        }
    }
}
