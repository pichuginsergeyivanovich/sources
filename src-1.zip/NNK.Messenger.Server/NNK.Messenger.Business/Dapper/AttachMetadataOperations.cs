﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using Dapper;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using NNK.Messenger.Core;
using NNK.Messenger.Data;

namespace NNK.Messenger.Business.Dapper
{
    public class AttachMetadataOperations :BaseDapperConnection, IAttachMetadataOperations
    {
        public AttachMetadataOperations(IDapperConnectionStringProvider provider) : base(provider)
        {
        }

        public AttachMedatada AddAttachMetadata(string metaData, Guid messageId)
        {
            var item = new AttachMedatada
            {
                ID = Guid.NewGuid(),
                MessageID = messageId,
                AttachMetadata = metaData
            };

            if (!(item.AttachMetadata.StartsWith("[") && item.AttachMetadata.EndsWith("]")))
            {
                item.AttachMetadata = $"[{metaData}]";
            }

            return ExecuteQuery(db =>
            {

                var md =
                    db.Query<AttachMedatada>("select top 1 * from AttachMedatada where MessageID = @MessageID",
                        new {MessageID = messageId})?.FirstOrDefault();

                if (md == null)
                {
                    db.Execute("insert dbo.AttachMedatada (ID, MessageID, AttachMetadata) values(@ID, @MessageID, @AttachMetadata)",item);
                }

                return md;
            });
        }

        public string GetMetadata(Guid messageId)
        {
            return
                ExecuteQuery(
                    db =>
                        db.Query<string>(
                            "select top 1 AttachMetadata from AttachMedatada where MessageID = @MessageID",
                            new {MessageID = messageId}))?.FirstOrDefault();
        }

        public void CloneAttachMetadata(Guid messageId, Guid newmsgid)
        {
            var md =
                ExecuteQuery(
                    db =>
                        db.Query<AttachMedatada>("select top 1 * from dbo.AttachMedatada where MessageID=@MessageID",
                            new { MessageID = messageId }))?.FirstOrDefault();

            if (md == null)
                return;

            var jobj = Newtonsoft.Json.Linq.JArray.Parse(md.AttachMetadata);

            for (var i = 0; i < jobj.Count; i++)
            {
                var item = jobj[i] as JObject;

                //var name = item.GetValue("name");

                item?.Remove("attachId");
            }

            var obj = JsonConvert.SerializeObject(jobj,
                new JsonSerializerSettings() { StringEscapeHandling = StringEscapeHandling.EscapeHtml });

            //md.AttachMetadata = obj;

            //md.MessageID = newmsgid;

            AddAttachMetadata(obj, newmsgid);

        }
        public void LinkClonedAttachMetadata(Attach attach)
        {
            var md =
                ExecuteQuery(
                    db =>
                        db.Query<AttachMedatada>("select top 1 * from dbo.AttachMedatada where MessageID=@MessageID",
                            attach))?.FirstOrDefault();

            if (md == null)
                return;


            var jobj = Newtonsoft.Json.Linq.JArray.Parse(md.AttachMetadata);

            for (var i = 0; i < jobj.Count; i++)
            {
                var item = jobj[i] as JObject;

                if (item["attachId"] == null)
                {
                    item?.Add("attachId", attach.ID);
                }
                else
                {
                    item["attachId"] = attach.ID;
                }
            }

            var obj = JsonConvert.SerializeObject(jobj,
                new JsonSerializerSettings() { StringEscapeHandling = StringEscapeHandling.EscapeHtml });

            md.AttachMetadata = obj;

            Execute(db => db.Execute("update dbo.AttachMedatada set AttachMetadata=@AttachMetadata where ID=@ID", md));

        }
        public void LinkAttachMetadata(Attach attach)
        {

            var md =
                ExecuteQuery(
                    db =>
                        db.Query<AttachMedatada>("select top 1 * from dbo.AttachMedatada with(updlock) where MessageID=@MessageID",
                            attach
                            ))
                            ?.FirstOrDefault();

            if (md == null)
                return;

            var jobj = Newtonsoft.Json.Linq.JArray.Parse(md.AttachMetadata);

            for (var i = 0; i < jobj.Count; i++)
            {
                var item = jobj[i] as JObject;

                var name = item.GetValue("name");

                if (attach.FilePath.EndsWith($"{attach.MessageID.ToString().ToLower()}_{name}.secret"))
                {
                    if (item["attachId"] == null)
                    {
                        item?.Add("attachId", attach.ID);
                    }
                    else
                    {
                        item["attachId"] = attach.ID;
                    }
                }
            }

            var obj = JsonConvert.SerializeObject(jobj,
                new JsonSerializerSettings() {StringEscapeHandling = StringEscapeHandling.EscapeHtml});

            md.AttachMetadata = obj;

            Execute(db => db.Execute("update dbo.AttachMedatada set AttachMetadata=@AttachMetadata where ID=@ID", md));

        }
        public void LinkAttachMetadataTransacted(Attach attach)
        {
            using (IDbConnection db = new SqlConnection(ConnectionString))
            {
                IDbTransaction trunsaction = null;

                try
                {
                    db.Open();

                    trunsaction = db.BeginTransaction();

                    if (trunsaction == null)
                        throw new ApplicationException("Could not create trunsaction");

                    var md =
                        db.Query<AttachMedatada>("select top 1 * from dbo.AttachMedatada with(updlock) where MessageID=@MessageID",
                            attach,trunsaction,false)?.FirstOrDefault();

                    if (md == null)
                        return;

                    var jobj = Newtonsoft.Json.Linq.JArray.Parse(md.AttachMetadata);

                    for (var i = 0; i < jobj.Count; i++)
                    {
                        var item = jobj[i] as JObject;

                        if (item != null)
                        {
                            var name = item.GetValue("name");

                            if (attach.FilePath.EndsWith($"{attach.MessageID.ToString().ToLower()}_{name}.secret"))
                            {
                                if (item["attachId"] == null)
                                {
                                    item.Add("attachId", attach.ID);
                                }
                                else
                                {
                                    item["attachId"] = attach.ID;
                                }
                            }
                        }
                    }

                    var obj = JsonConvert.SerializeObject(jobj, new JsonSerializerSettings() { StringEscapeHandling = StringEscapeHandling.EscapeHtml });

                    md.AttachMetadata = obj;

                    db.Execute("update dbo.AttachMedatada set AttachMetadata=@AttachMetadata where ID=@ID", md, trunsaction);

                    trunsaction.Commit();

                }
                catch (Exception)
                {
                    trunsaction?.Rollback();

                    throw;
                }
                finally
                {
                    if (db.State != ConnectionState.Closed)
                        db.Close();
                }
            }
        }

        public decimal? VeryfyAttachMetadata(Attach attach, out int total, out int attached)
        {
            total = 0;
            attached = 0;

            var md =
                ExecuteQuery(
                    db =>
                        db.Query<AttachMedatada>("select top 1 * from dbo.AttachMedatada where MessageID=@MessageID",
                            attach))?.FirstOrDefault();

            if (md == null)
                return null;


            var jobj = Newtonsoft.Json.Linq.JArray.Parse(md.AttachMetadata);

            var cnt = 0;

            if (jobj.Count == 0)
                return null;

            total = jobj.Count;

            for (var i = 0; i < jobj.Count; i++)
            {
                var item = jobj[i] as JObject;

                var name = item.GetValue("name");

                if (item["attachId"] != null)
                {
                    cnt++;
                }
            }

            attached = cnt;

            return (decimal)cnt / jobj.Count;
        }

        public void KillMetadata(Guid msid)
        {
            Execute(db =>
            {
                db.Execute("delete from dbo.AttachMedatada where MessageID=@MessageID", new { MessageID=msid });
            });
        }
    }
}
