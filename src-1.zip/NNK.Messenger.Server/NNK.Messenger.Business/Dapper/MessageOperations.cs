﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Web.Configuration;
using NNK.Messenger.Core;
using NNK.Messenger.Data;
using Dapper;


namespace NNK.Messenger.Business.Dapper
{
    public class MessageOperations: BaseDapperConnection, IMessageOperations
    {
        private readonly IChatOperations _cops;
        private readonly IAttachMetadataOperations _amops;

        public MessageOperations(IDapperConnectionStringProvider provider, IChatOperations cops, IAttachMetadataOperations amops) : base(provider)
        {
            _cops = cops;
            _amops = amops;

            /*SqlMapperExtensions.TableNameMapper = (type) =>
            {
                switch (type.Name)
                {
                    case "Message":
                    case "MessageWrapper":
                        return "Message";
                    default:
                        var name = type.Name + "s";
                        if (type.IsInterface && name.StartsWith("I"))
                            name = name.Substring(1);
                        return name;
                }
            };*/
        }

        public Message AddMessage(Guid chatDecoded, string authorDecoded, string textDecoded)
        {
            var m = new
            {
                ID = Guid.NewGuid(),
                Author = authorDecoded,
                Created = DateTime.Now.ToUniversalTime(),
                Text = textDecoded,
                ChatID = chatDecoded,
                StatusSrvDelivered=true

            };

            Execute(db=> db.Execute("insert into dbo.Message (ID, Author, Created, Text, ChatID, StatusSrvDelivered) values(@ID, @Author, @Created, @Text, @ChatID, @StatusSrvDelivered)", m));

            return Get(m.ID);
        }
        public Message AddMessage(Guid chatDecoded, string authorDecoded, string textDecoded, DateTime created, Guid? newMessageId = default(Guid?))
        {
            if (!newMessageId.HasValue)
                newMessageId = Guid.NewGuid();

            var m = new MessageWrapper
            {
                ID = newMessageId.Value,
                Author = authorDecoded,
                Created = DateTime.Now.ToUniversalTime(),
                Text = textDecoded,
                ChatID = chatDecoded,
                StatusSrvDelivered = true
            };

                //Execute(db => db.Insert<dynamic>(m));
                Execute(
                    db =>
                        db.Execute("insert into dbo.Message (ID, Author, Created, Text, ChatID, StatusSrvDelivered) select @ID, @Author, @Created, @Text, @ChatID, @StatusSrvDelivered where not exists(select ID from  dbo.Message where ID=@ID)",m));
  
            return Get(m.ID);
        }
        /*
        public async Task<Message> AddMessageAsync(Guid chatDecoded, string authorDecoded, string textDecoded, DateTime created, Guid? newMessageId = default(Guid?))
        {
            if (!newMessageId.HasValue)
                newMessageId = Guid.NewGuid();

            var m = new MessageWrapper
            {
                ID = newMessageId.Value,
                Author = authorDecoded,
                Created = DateTime.Now.ToUniversalTime(),
                Text = textDecoded,
                ChatID = chatDecoded
            };

            using (IDbConnection db = new SqlConnection(ConnectionString))
            {

                try
                {
                    db.Open();

                    //await db.InsertAsync<MessageWrapper>(m);
                    db.Execute(
                        "INSERT INTO Message ([ID], [ChatID], [Text], [Created], [Author]) values (@ID, @ChatID, @Text, @Created, @Author)",
                        m);

                    var r = await db.QueryAsync<Message>("select top 1 * from Message where ID = @ID", new { m.ID });

                    return await Task.FromResult(r.FirstOrDefault());
                }

                finally
                {
                    if (db.State != ConnectionState.Closed)
                        db.Close();
                }
            }


        }
        /*
        public async Task<Message> AddMessageAsync(Guid chatDecoded, string authorDecoded, string textDecoded, DateTime created, Guid? newMessageId = default(Guid?))
        {
            if (!newMessageId.HasValue)
                newMessageId = Guid.NewGuid();

            var m = new MessageWrapper
            {
                ID = newMessageId.Value,
                Author = authorDecoded,
                Created = DateTime.Now.ToUniversalTime(),
                Text = textDecoded,
                ChatID = chatDecoded
            };

            using (IDbConnection db = new SqlConnection(ConnectionString))
            {

                try
                {
                    db.Open();

                    //await db.InsertAsync<MessageWrapper>(m);
                    db.Execute(
                        "INSERT INTO Message ([ID], [ChatID], [Text], [Created], [Author]) values (@ID, @ChatID, @Text, @Created, @Author)",
                        m);

                    var r = await db.QueryAsync<Message>("select top 1 * from Message where ID = @ID", new {m.ID});

                    return await Task.FromResult(r.FirstOrDefault());
                }

                finally
                {
                    if (db.State != ConnectionState.Closed)
                        db.Close();
                }
            }


        }*/
        public ChatMessage AsFullChatMessage(Message message, string attachMetadata)
        {
            var party = _cops.GetChatParty(message.ChatID);

            var result = new ChatMessage(message.Author, message.Text, string.Join(",", party), message.ChatID.ToString())
            {
                SID = message.ID,
                Created = message.Created,
                ChkSum = message.ChkSum.ToString(),
                MsgChkSum = message.MsgChkSum.ToString(),
                Metadata = attachMetadata,
                Read = message.StatusRead.HasValue && message.StatusRead.Value,
                Delivered = message.StatusDelivered.HasValue && message.StatusDelivered.Value,
                SrvDelivered = message.StatusSrvDelivered.HasValue && message.StatusSrvDelivered.Value,
            };

            return result;
        }


        #region SystemChatMessages

        public ChatMessage CreateCustomChatMessage(Guid chatId, string creator, string text)
        {
            var dbMessage = AddMessage(chatId, creator, text, DateTime.Now.ToUniversalTime());

            return AsFullChatMessage(dbMessage, _amops.GetMetadata(dbMessage.ID));
        }

//        public Message CreateInviteMessage(Guid chat, string user, string inviter, string text)
//        {
//            return AddMessage(chat, inviter, text, DateTime.Now.ToUniversalTime());
//        }
//
//        public Message CreateInviteRejectMessage(Guid chatId, string invited, string text)
//        {
//            return AddMessage(chatId, invited, text, DateTime.Now.ToUniversalTime());
//        }
//
//        public Message CreateSimpleChatMessage(Guid chatId, string author, string text)
//        {
//            return AddMessage(chatId, author, text, DateTime.Now.ToUniversalTime());
//        }
//
//        public Message CreateGroupChatMessage(Guid chatId, string author, string text)
//        {
//            return AddMessage(chatId, author, text, DateTime.Now.ToUniversalTime());
//        }

        #endregion

        public Message Get(Guid sid)
        {
            var res= ExecuteQuery(db => db.Query<Message>("select * from dbo.Message where ID=@sid", new{ sid })?.FirstOrDefault());

            return  res;
        }

        public IEnumerable<Message> GetChatMessages(Guid? chatId)
        {
            return !chatId.HasValue ? new Message[0] : ExecuteQuery(db => db.Query<Message>("select * from dbo.Message where ChatID=@chatId", new { chatId = chatId.Value }));
        }

        public IEnumerable<Guid> GetChatMessagesIDs(Guid? chatId)
        {
            return !chatId.HasValue ? new Guid[0] : ExecuteQuery(db => db.Query<Guid>("select id from dbo.Message where ChatID=@chatId", new { chatId=chatId.Value}));
        }

        public IEnumerable<Message> GetMessages(Guid chatId, string timeLabel = null, string msgChkSum = null)
        {
            DateTime? dtFilter = ExecuteQuery(db =>
            {
                if (!string.IsNullOrEmpty(msgChkSum))
                {

                    return db.Query<DateTime?>("select top 1 Created from dbo.Message WHERE MsgChkSum = @msgChkSum", new {msgChkSum}).FirstOrDefault();
                }
                return (DateTime?)null;
            });

            return ExecuteQuery(db =>
            {
                var builder = new SqlBuilder();

                var template = builder.AddTemplate("select * from dbo.Message /**where**/ /**orderby**/");

                builder.Where("ChatId = @chatId", new {chatId});
                

                if (!string.IsNullOrEmpty(msgChkSum))
                {
                    if (dtFilter != null)
                        builder.Where("Created > @Created", new {Created = dtFilter});
                }
                else if (!string.IsNullOrEmpty(timeLabel))
                {
                    dtFilter = DateTime.Parse(timeLabel);

                    builder.Where("Created >= @Created", new { Created = dtFilter });

                }

                builder.OrderBy("Created");

                var res = db.Query<Message>(template.RawSql, template.Parameters);

                return res.ToArray();
            });

        }

        public void KillMessages(Guid chatId)
        {
            var items = GetChatMessagesIDs(chatId);

            Execute(db =>
            {
                foreach (var i in items)
                {
                    db.Execute("delete from dbo.Message where ID = @msgID", new {msgID = i});
                }
                
            });
        }

        public void UpdateMessageStatus(Guid gsid, bool srvDelivered, bool delivered, bool read)
        {
            var m = Get(gsid);

            if (m == null)
                return;

            /*var mw = new MessageWrapper
            {
                ID = m.ID,
                Author = m.Author,
                ChatID = m.ChatID,
                Created = m.Created,
                StatusDelivered = delivered,
                StatusRead = read,
                StatusSrvDelivered = srvDelivered,
                Text = m.Text
            };*/

            //Execute(db =>db.Update(mw));
            Execute(db =>
            {
                db.Execute(
                    "update dbo.Message set StatusDelivered=@delivered, StatusRead=@read, StatusSrvDelivered=@srvDelivered where ID=@ID",
                    new {delivered, read, srvDelivered, m.ID});
            });

        }

        public void UpdateMessageText(Guid msid, string newtext)
        {
            var m = Get(msid);

            if (m == null)
                return;

            Execute(db =>
            {
                db.Execute("update dbo.Message set Text=@newtext where ID=@ID",  new { newtext, m.ID });
            });
        }

        public IEnumerable<MessageStatus> GetSidInfo(Guid msid, string username)
        {
            return
                ExecuteQuery(
                    db =>
                        db.Query<MessageStatus>("exec dbo.sp_get_sid_info @msid, @username",
                            new {msid, username}));


        }
    }
}
