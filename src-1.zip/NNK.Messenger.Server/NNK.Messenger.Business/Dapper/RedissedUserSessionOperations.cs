﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using Dapper;
using NNK.Messenger.Business.Redis;
using NNK.Messenger.Core;
using NNK.Messenger.Data;


namespace NNK.Messenger.Business.Dapper
{
    public class RedissedUserSessionOperations : BaseDapperConnection, IUserSessionOperations
    {
        public RedissedUserSessionOperations(IDapperConnectionStringProvider provider) : base(provider)
        {
        }
     

        public IEnumerable<UserSession> GetUserSessions()
        {
           var v = RedisCache.GetCacheValue("skey1");

            var userSessionCache = RedisCache.GetCacheValue("dbo.UserSession");

            if (userSessionCache==null)
            {
                var result = ExecuteQuery(db => db.Query<UserSession>("select * from dbo.UserSession"));

                var userSessions = result as UserSession[] ?? result.ToArray();

                var sv = string.Join(",", userSessions.Select(i => i.ConnectionId.ToString()).ToArray());

                RedisCache.SetCacheValue($"dbo.UserSession", sv);

                Debug.WriteLine(sv);


                foreach (var r in userSessions)
                {
                    RedisCache.SetCacheValue($"dbo.UserSession_{r.ConnectionId}", r.Username);
                }
                return userSessions;
            }
            else
            {
                var s = (string) userSessionCache;

                var ss = s.Split(new[] {","}, StringSplitOptions.RemoveEmptyEntries);

                var res = ss.Select(i => new UserSession()
                    {
                        Username = RedisCache.GetCacheValue($"dbo.UserSession_{i}")?.Trim(),
                        ConnectionId = Guid.Parse(i)
                    })
                    .ToArray();

                return res;

            }
        }

        public void RemoveUserSession(Guid connectionId)
        {
            Execute(db =>{db.Execute("delete from dbo.UserSession where ConnectionId=@ConnectionId", new { ConnectionId = connectionId });});

            RedisCache.RemoveCacheKey($"dbo.UserSession_{connectionId}");

            var userSessionCache = RedisCache.GetCacheValue("dbo.UserSession");

            if (!string.IsNullOrEmpty(userSessionCache))
            {
                var ss = userSessionCache.Split(new[] {","}, StringSplitOptions.RemoveEmptyEntries)?.ToList();

                ss.Remove(connectionId.ToString());

                RedisCache.SetCacheValue("dbo.UserSession",string.Join(",",ss));
            }

        }
        public void AddUserSession(UserSession us)
        {
            Execute(db =>{db.Execute("insert dbo.UserSession(ConnectionId, Username) values(@ConnectionId, @Username)",us);});

            RedisCache.SetCacheValue($"dbo.UserSession_{us.ConnectionId}", us.Username);

            RedisCache.AppendCacheValue($"dbo.UserSession", us.ConnectionId);
        }
    }
}
