﻿using System;
using System.Data.SqlClient;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using Dapper;
using NNK.Messenger.Core;
using NNK.Messenger.Data;

namespace NNK.Messenger.Business.Dapper
{
    public class FileStoreOperations : BaseDapperConnection, IFileStoreOperations
    {
        public FileStoreOperations(IDapperConnectionStringProvider provider) : base(provider)
        {
        }

        public FileStore_Add_Result AddFile(string fileName, byte[]fileData)
        {
            //return
            //    ExecuteQuery(
            //        db =>
            //            db.Query<FileStore_Add_Result>("exec dbo.FileStore_AddV1 @newid, @fileName, @fileData", new {newid=Guid.NewGuid(), fileName, fileData},null,true, 120
            //            ))?.FirstOrDefault();
            

            lock (fileName)
            {
                var retry = 1;

                var streamId = Guid.NewGuid();

                var result = new FileStore_Add_Result()
                {
                    stream_id = streamId,
                    unc_path = $"\\\\DMZDOM-MSG-01\\MSSQLSERVER\\MSSQLSERVER\\FileAttach\\{fileName}"
                };

                while (retry>0)
                {

                    try
                    {
                        ExecuteQuery(
                            db =>
                                db.Execute(
                                    "INSERT INTO dbo.FileStore (stream_id, file_stream, name) VALUES (@newid ,@fileData,@fileName)",
                                    new {newid = streamId, fileName, fileData}, null, 120));

                        retry = 0;
                    }
                    catch (SqlException ex)
                    {
                        if (
                            ex.Message.Contains(
                                "Violation of UNIQUE KEY constraint 'UQ__FileStor__A236CBB304CC11CD'. Cannot insert duplicate key in object 'dbo.FileStore'"))
                        {
                            //Thread.Sleep(50);

                            result =
                                ExecuteQuery(
                                    db =>
                                        db.Query<FileStore_Add_Result>(
                                            "select top 1 stream_id, FileTableRootPath()+file_stream.GetFileNamespacePath()  as unc_path from dbo.FileStore where name = @fileName",
                                            new {fileName = fileName}, null, true/*, 120*/
                                        ))?.FirstOrDefault();

                            

                            retry = 0;

                        }
                        else if (ex.Number == 1205 && ex.Class == 13)//deadlock
                        {
                            //Thread.Sleep(50);
                            retry = 1;
                        }
                        else if (ex.Number == -2 && ex.Class == 11)//timeout
                        {
                            //Thread.Sleep(50);
                            retry = 1;
                        }
                        else
                        {
                            retry = 0;
                            throw;
                        }
                    }
                    
                }

                return result;
            }
        }
        public FileStore_Add_Result AddFileOldSchool(string fileName, byte[] fileData)
        {
            return
                ExecuteQuery(
                    db =>
                        db.Query<FileStore_Add_Result>("exec dbo.FileStore_Add @fileName, @fileData", new { fileName, fileData }))?.FirstOrDefault();

        }
        public byte[] GetFileBytes(Guid fileStreamId)
        {
            return
                ExecuteQuery(
                    db =>
                        db.Query<byte[]>("select file_stream from dbo.FileStore(nolock) where stream_id=@stream_id", new { stream_id = fileStreamId}))?.FirstOrDefault();
        }
        public FileStore_Add_Result GetFileStoreAddResult(string filename)
        {
            return ExecuteQuery(
                db =>
                    db.Query<FileStore_Add_Result>(
                        "select top 1 stream_id, FileTableRootPath()+file_stream.GetFileNamespacePath()  as unc_path from dbo.FileStore where name = @fileName",
                        new {fileName = filename}, null, true /*, 120*/
                    ))?.FirstOrDefault();
        }
        public void DeleteFile(Guid fileStreamId)
        {
            ExecuteQuery(db => db.Execute("exec dbo.FileStore_Del @fileStreamId", new {fileStreamId}));
        }

        public void KillFiles(Guid[] fileStreamIds)
        {
            foreach (var f in fileStreamIds)
                DeleteFile(f);
        }
    }
}
