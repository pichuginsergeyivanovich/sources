using System.Collections.Generic;
using System.Threading.Tasks;
using NNK.Messenger.Data;

namespace NNK.Messenger.Business
{
    public interface IIdentityOperations
    {
        void RegisterUserKeys(int uid, byte[] identityKey, byte[] signedPreKey, byte[] signedPreKeyHash, Queue<byte[]> oneTimeKeyQueue);
        Identity Get(int uid);


        bool IsDeviceTokenOnUser(int uid, byte[] devtoken);

        void CleanDevToken(int uid, byte[] devtoken);



    }
}