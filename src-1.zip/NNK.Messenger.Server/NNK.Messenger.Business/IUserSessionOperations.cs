using System;
using System.Collections.Generic;
using NNK.Messenger.Data;

namespace NNK.Messenger.Business
{
    public interface IUserSessionOperations
    {
        IEnumerable<UserSession> GetUserSessions();
        void RemoveUserSession(Guid connectionId);
        void AddUserSession(UserSession us);
    }
}