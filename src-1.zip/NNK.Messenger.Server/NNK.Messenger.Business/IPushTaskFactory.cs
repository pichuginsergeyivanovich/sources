using NNK.Messenger.Core;

namespace NNK.Messenger.Business
{
    public interface IPushTaskFactory
    {
        PushTask From(AddMessagePushTask task);

        PushTask From(AddMessagePushTask2 task);
        PushTask From(CreateGroupChatPushTask task);
    }
}