﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NNK.Messenger.Business
{
    public enum NotificationTypeEnum : byte
    {
        NT_SRV_DELIVERY = 0, //сообщение дошло до сервера
        NT_DELIVERY = 1, //сообщение дошло до клиента
        NT_READ = 2
    }
}
