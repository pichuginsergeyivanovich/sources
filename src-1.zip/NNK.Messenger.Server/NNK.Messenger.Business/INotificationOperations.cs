﻿using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using NNK.Messenger.Data;

namespace NNK.Messenger.Business
{
    public interface INotificationOperations
    {
        void AddNotification(NotificationTypeEnum type, Guid sid, DateTime clientDate, string clientDescr, string cip, string username);

        IEnumerable<Guid> AddBulkNotification(NotificationTypeEnum type, Guid chatid, DateTime clientDate, string clientDescr, string cip, string username);

        void KillChatMessageNotifications(Guid[] mids);

        IEnumerable<Notification> GetNotifications(Guid sid);
        IEnumerable<Notification> GetNotifications(Guid sid, NotificationTypeEnum type);

        dynamic GetChangeStatusSids(Guid chatId);

    }
}