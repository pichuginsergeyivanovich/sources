﻿using System;
using System.Threading.Tasks;
using NNK.Messenger.Data;

namespace NNK.Messenger.Business
{
    public interface IAttachMetadataOperations
    {
        AttachMedatada AddAttachMetadata(string metaData, Guid messageId);
        string GetMetadata(Guid messageId);
        void LinkAttachMetadata(Attach attach);
        void KillMetadata(Guid msid);

        void CloneAttachMetadata(Guid messageId, Guid newmsgid);
        void LinkClonedAttachMetadata(Attach attach);
        void LinkAttachMetadataTransacted(Attach attach);

        decimal? VeryfyAttachMetadata(Attach attach, out int total, out int attached);
    }
}