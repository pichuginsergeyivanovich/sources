using System;
using System.Threading.Tasks;
using NNK.Messenger.Data;

namespace NNK.Messenger.Business
{
    public interface IInviteOperations
    {
        //        Task<Invite> CreateInviteAsync(Guid chat, string inviter, string user);
        //        Task<Invite[]> GetAllByUserAsync(string user, bool fresh=true);
        //        Task<Invite> GetAsync(Guid id);
        //        Task<Invite> AcceptInviteAsync(Invite invite);
        //        Task<Invite> RejectInviteAsync(Invite invite);
        //        Task DeleteAsync(Guid inviteId);
        Invite CreateInvite(Guid chat, string inviter, string user, bool? hidden=false);
        Invite[] GetAllByUser(string user, bool fresh = true);
        Invite Get(Guid id);
        Invite AcceptInvite(Invite invite);
        Invite RejectInvite(Invite invite);
        void Delete(Guid inviteId);
    }
}