﻿using System;
using Newtonsoft.Json.Linq;
using NNK.Messenger.Data;

namespace NNK.Messenger.Business
{
    public class ProfileFactory
    {
        public static Profile FromJson(string json)
        {
            var jobj = Newtonsoft.Json.Linq.JObject.Parse(json);

            var userName = (string)jobj.GetValue("userName");

            var deletedMsgsIds = (jobj.GetValue("deletedMsgsIds")==null || jobj.GetValue("deletedMsgsIds").Type == JTokenType.Null)?"":jobj.GetValue("deletedMsgsIds").ToString(); 

             var contacts = (jobj.GetValue("contacts")==null || jobj.GetValue("contacts").Type == JTokenType.Null) ? "" : jobj.GetValue("contacts").ToString();

            var isPinEnabled = (string)jobj.GetValue("isPinEnabled");

            var isSoundsEnabled = (string)jobj.GetValue("isSoundsEnabled");

            var isLocalNotificationsEnabled = (string)jobj.GetValue("isLocalNotificationsEnabled");

            var pinCode = (string)jobj.GetValue("pinCode");

            var isTouchEnabled = (string)jobj.GetValue("isTouchEnabled");

            var imageAvatarStreamId = (string)jobj.GetValue("imageAvatarStreamId");


            var p = new Profile
            {
                UserName = userName,

                DeletedMsgIDs = deletedMsgsIds,

                Contacts = contacts,
                
                SettingsIsLocalNotificationsEnabled = bool.Parse(isLocalNotificationsEnabled),

                SettingsPinEnabled = bool.Parse(isPinEnabled),

                SettingsSoundsEnabled = bool.Parse(isSoundsEnabled),

                SettingsPinCode = pinCode,

                SettingsTouchIdEnabled = bool.Parse(isTouchEnabled),

                Created = DateTime.Now.ToUniversalTime(),

                ImageAvatarStreamId = string.IsNullOrEmpty(imageAvatarStreamId)?(Guid?)null:Guid.Parse(imageAvatarStreamId)
            };


            return p;

        }
    }
}
