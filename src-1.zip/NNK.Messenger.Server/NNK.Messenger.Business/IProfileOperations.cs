using System;
using NNK.Messenger.Data;

namespace NNK.Messenger.Business
{
    public interface IProfileOperations
    {
        Profile GetProfile(int userId);
        bool ExistProfile(int userId);
        void SaveProfile(int userId, Profile p);
        void DeleteProfile(int userId);

        Guid? GetProfileImage(int userId);
    }
}