﻿using System;
using System.Linq;
using NNK.Messenger.Core;

namespace NNK.Messenger.Business
{
    public class PushTaskFactory : IPushTaskFactory
    {
        private readonly IChatOperations _cops;

        public PushTaskFactory(IChatOperations cops)
        {
            _cops = cops;
        }

        public PushTask From(AddMessagePushTask task)
        {
            var author = task.User;

            var chatId = task.ChatId;

            var party = _cops.GetChatParty(Guid.Parse(chatId))
                .Where(i => i != author)
                .Distinct().ToArray();

            return new PushTask()
            {
                Party = party,
                Text = "Вам было отправленно сообщение",
            };
        }
        public PushTask From(CreateGroupChatPushTask task)
        {
            var chatId = task.ChatId;

            var chat = _cops.Get(Guid.Parse(chatId));

            var party = _cops.GetChatParty(Guid.Parse(chatId))
                .Where(i => i != chat.Author)
                .Distinct().ToArray();

            return new PushTask()
            {
                Party = party,
                Text = "Создан чат с Вашим участием",
            };
        }
        public PushTask From(AddMessagePushTask2 task)
        {
            var author = task.User;

            var chatId = task.ChatId;

            var party = _cops.GetChatParty(Guid.Parse(chatId))
                .Where(i => i != author)
                .Distinct().ToArray();

            return new PushTask()
            {
                Party = party,
                Text = task.Text
            };
        }
    }
}
