﻿using System;
using System.Threading.Tasks;
using NNK.Messenger.Data;

namespace NNK.Messenger.Business
{
    public interface IOperationsOperations
    {
        Operation Add(string id, string method, string data);
        Operation Confirm(string idDecoded, string codeDecoded);
        void OperationProcessedCreated(Guid? updated);
        Operation GetConfirmSecretCode(Guid id);
        Operation GetById(Guid operationId);
        void DeleteOperation(Guid id);
    }
}