﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using NNK.Messenger.Core;
using NNK.Logging;

namespace NNK.Messenger.Business
{
    public class CryptoOperations : ICryptoOperations
    {
        private readonly ILogger _logger;

        public CryptoOperations(ILogger logger)
        {
            _logger = logger;
        }
        public byte[] EncryptDataString(byte[] key, string plaintext, out byte[] iv)
        {
            using (Aes aes = new AesCryptoServiceProvider())
            {
                aes.Key = key;

                iv = aes.IV;

                using (var ciphertext = new MemoryStream())
                {
                    using (var cs = new CryptoStream(ciphertext, aes.CreateEncryptor(), CryptoStreamMode.Write))
                    {
                        byte[] plaintextMessage = Encoding.UTF8.GetBytes(plaintext);

                        cs.Write(plaintextMessage, 0, plaintextMessage.Length);

                        cs.Close();

                        return ciphertext.ToArray();
                    }
                }
            }
        }
        public void EncryptStream(byte[] key, Stream input, Stream output, out byte[] iv)
        {

            using (var aes = new AesCryptoServiceProvider())
            {

                //var _logger = TextFileLoggerSingleton.Instanse;

                iv = aes.IV;
                _logger.Message($"EncryptStream:iv bytes:{string.Join(",", iv)}");
                _logger.Message($"EncryptStream:iv:{Convert.ToBase64String(iv)}");
                _logger.Message($"EncryptStream:iv len:{iv.Count()}");

                ulong totcnt = 0;


                using (var cryptoTransform = aes.CreateEncryptor(key, iv))
                {

                    using (var cryptoStream = new CryptoStream(output, cryptoTransform, CryptoStreamMode.Write))
                    {

                        const int blockSize = 1024;

                        var buffer = new byte[blockSize];

                        while (true)
                        {

                            var bytesRead = input.Read(buffer, 0, blockSize);

                            //if (totcnt == 0)
                            //{
                            //    _logger.Message($"EncryptStream:top 100 enc:{string.Join(",", buffer.Take(100).ToArray())}");
                            //}

                            if (bytesRead == 0)
                            {
                                break;
                            }

                            cryptoStream.Write(buffer, 0, bytesRead);

                            totcnt += (uint)bytesRead;
                        }

                        _logger.Message($"EncryptStream:enc totcnt:{totcnt}");

                        cryptoStream.Write(iv, 0, iv.Length);
                        cryptoStream.Close();
                    }
                }


            }
        }
        public void EncryptFile(byte[] key, string inFile, string outFile)
        {
            byte[] iv;

            using (var inStream = new FileStream(inFile, FileMode.Open, FileAccess.Read, FileShare.ReadWrite))
            {
                using (var outStream = new FileStream(outFile, FileMode.Create, FileAccess.Write,FileShare.ReadWrite))
                {
                    EncryptStream(key, inStream, outStream, out iv);

                    outStream.Close();
                }

                inStream.Close();
            }
            /*
            //var _logger = TextFileLoggerSingleton.Instanse;

            using (var sw = new FileStream(inFile, FileMode.Open, FileAccess.Read))
            {
                var first = new byte[10];

                var last = new byte[10];

                sw.Read(first, 0, 10);

                _logger.Message($"EncryptStream:top 10 :{string.Join(",", first)}");


                _logger.Message($"EncryptStream:len:{sw.Length}");


                sw.Seek(-10, SeekOrigin.End);

                sw.Read(last, 0, 10);

                _logger.Message($"EncryptStream:last 10 :{string.Join(",", last)}");

            }*/


            using (var sw = new FileStream(outFile, FileMode.Append, FileAccess.Write, FileShare.ReadWrite))
            {

                sw.Seek(0, SeekOrigin.End);

                sw.Write(iv, 0, iv.Length);

                sw.Close();
            }

            _logger.Message($"EncryptStream:cryptoStream.Length:{new FileInfo(outFile).Length}");
        }

        public static void EncryptDataFile(byte[] key, String sourceFile, String destFile)
        {


            // Initialize the keyed hash object.
            using (var hmac = new HMACSHA256(key))
            {
                using (var inStream = new FileStream(sourceFile, FileMode.Open))
                {
                    using (var outStream = new FileStream(destFile, FileMode.Create))
                    {
                        // Compute the hash of the input file.
                        byte[] hashValue = hmac.ComputeHash(inStream);
                        // Reset inStream to the beginning of the file.
                        inStream.Position = 0;
                        // Write the computed hash value to the output file.
                        outStream.Write(hashValue, 0, hashValue.Length);
                        // Copy the contents of the sourceFile to the destFile.
                        int bytesRead;
                        // read 1K at a time
                        byte[] buffer = new byte[1024];
                        do
                        {
                            // Read from the wrapping CryptoStream.
                            bytesRead = inStream.Read(buffer, 0, 1024);
                            outStream.Write(buffer, 0, bytesRead);
                        } while (bytesRead > 0);
                        outStream.Close();
                    }
                    inStream.Close();
                }
            }
            return;
        } // end SignFile
        public string DecryptDataString(byte[] key, byte[] encrypted, byte[] iv)
        {
            using (Aes aes = new AesCryptoServiceProvider())
            {
                aes.Key = key;
                aes.IV = iv;

                using (var plaintext = new MemoryStream())
                {
                    using (var cs = new CryptoStream(plaintext, aes.CreateDecryptor(), CryptoStreamMode.Write))
                    {
                        cs.Write(encrypted, 0, encrypted.Length);
                        cs.Close();
                        return Encoding.UTF8.GetString(plaintext.ToArray());
                    }
                }
            }
        }
    }
}
