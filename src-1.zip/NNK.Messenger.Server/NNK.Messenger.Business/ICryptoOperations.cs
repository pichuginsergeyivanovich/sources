using System.IO;

namespace NNK.Messenger.Business
{
    public interface ICryptoOperations
    {
        byte[] EncryptDataString(byte[] key, string plaintext, out byte[] iv);
        void EncryptStream(byte[] key, Stream input, Stream output, out byte[] iv);
        void EncryptFile(byte[] key, string inFile, string outFile);
        string DecryptDataString(byte[] key, byte[] encrypted, byte[] iv);
    }
}