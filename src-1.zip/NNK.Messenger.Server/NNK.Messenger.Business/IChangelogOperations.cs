﻿using System;
using NNK.Messenger.Data;

namespace NNK.Messenger.Business
{
    public interface IChangelogOperations
    {
        Changelog Get(string version);
        Changelog GetLast();
        string GetNextLinkForStamp(Guid stamp);
        Changelog GetByStamp(Guid stamp);
        Changelog GetByLinkedStamp(Guid lstamp);

    }
}