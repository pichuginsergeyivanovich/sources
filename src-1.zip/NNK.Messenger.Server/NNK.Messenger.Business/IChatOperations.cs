using System;
using NNK.Messenger.Data;

namespace NNK.Messenger.Business
{
    public interface IChatOperations
    {
        //Party[] GetChatByParty(string author, string party);
        Chat CreateChat(Chat inserted, Guid? newChatId = null);
        vw_user_chat_list[] GetChatList(string user, string msgChkSum = null);
        string[] GetChatIDsList(string user);
        Chat[] GetAllChatsList(string user, string timeLabel = null);
        Party[] GetAllParty(string user, string timeLabel = null);
        string[] GetChatParty(Guid chatId);
        void KillChat(Guid chatId);
        Chat Get(Guid chatId);
        void UpdateChatParty(Guid chatId, string user);
        void RemoveChatUser(Guid chatId, string user);
        bool IsUserChat(Guid chatId, string user);
        void UpdateChatTitle(Guid guid, string newtitle);
        void SetChatImageStreamId(Guid chatId, Guid? fileStreamId);
        Guid? GetChatImageStreamId(Guid chatId);
        bool Exist(Guid chatId);
        Chat GetChatFromParty(string partyAsString, string user);
    }
}