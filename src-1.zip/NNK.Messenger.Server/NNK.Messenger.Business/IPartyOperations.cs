﻿using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using NNK.Messenger.Data;

namespace NNK.Messenger.Business
{
    public interface IPartyOperations
    {
        IEnumerable<Party> GetChatParty(Guid? chatId);

        Party GetChatUserParty(Guid? chatId, string user);

        void LinkPartyToChat(string[] party, Guid chatId);
        void LinkPartyToChat(string user, Guid chatId);
        void KillParty(Guid chatId);
        void RemoveChatUser(string user, Guid? chatId);
    }
}