using System;
using System.Threading.Tasks;
using NNK.Messenger.Data;

namespace NNK.Messenger.Business
{
    public interface IFileStoreOperations
    {
        FileStore_Add_Result AddFile(string fileName, byte[]fileData);
        FileStore_Add_Result AddFileOldSchool(string fileName, byte[] fileData);

        //Task<FileStore_Add_Result> AddFileAsync(string fileName, byte[] fileData);
        void DeleteFile(Guid fileStreamId);
        //void DeleteFileAsync(Guid fileStreamId);
        void KillFiles(Guid[] fileStreamIds);

        byte[] GetFileBytes(Guid fileStreamId);

        FileStore_Add_Result GetFileStoreAddResult(string filename);
    }
}