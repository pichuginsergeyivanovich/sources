﻿using System;
using System.Collections.Generic;
using System.Linq;
using Ninject;
using NNK.Messenger.Business.Dapper;
using NNK.Messenger.Core;
using NNK.Messenger.Data;

namespace NNK.Messenger.Business
{
    public class ChatUsersHelper
    {
        private readonly IUserSessionOperations _usops;

        public ChatUsersHelper(IUserSessionOperations usops)
        {
            _usops = usops;
        }

       // readonly List<ChatUser> _users=new List<ChatUser>();
        //private static ChatUsersHelper _instance;

        private readonly object _locker = new object();

        public ChatUsersHelper GetInstance()
        {
            return this;
        }

        public List<ChatUser> Users
        {
            get
            {
                //return _users;

                var us = _usops.GetUserSessions();

                return us.Select(i => new ChatUser()
                {
                    ConnectionId = i.ConnectionId.ToString(),
                    Name = i.Username

                }).ToList();
            }
        }
        //[Inject]
        /*public static ChatUsersHelper Instance { get; set; /*get
            {
                if(_instance!=null)
                    return _instance;

                lock (_locker)
                {
                    return _instance ?? (_instance = new ChatUsersHelper());
                }
            }*/
       // }



        public ChatUser OnConnected(string userName, string userId, bool isAuth, string hubcontextConnectionId)
        {
            lock (_locker)
            {
                var cu = new ChatUser() {ConnectionId = hubcontextConnectionId, Name = $"@{userName}"};

                if (!Users.Any(x => x != null && x.ConnectionId == hubcontextConnectionId))
                {
                    _usops.AddUserSession(new UserSession() {ConnectionId = Guid.Parse(hubcontextConnectionId),Username = $"@{userName}" });
                    //Instance._users.Add(cu);
                }

                return cu;
            }
        }

        public ChatUser OnDisconnected(string hubcontextConnectionId)
        {
            var item = Users.FirstOrDefault(x => x != null && x.ConnectionId == hubcontextConnectionId);

            if (item != null)
            {
                _usops.RemoveUserSession(Guid.Parse(hubcontextConnectionId));
                //Instance._users.Remove(item);
            }

            return item;
        }
        public ChatUser[] GetConnectedParty(IEnumerable<string> party)
        {
            var connectedParty = Users.Where(i => i != null && party.Contains(i.Name)).ToList();

            return connectedParty.ToArray();
        }

        public string[] GetConnectedPartyIds(IEnumerable<string> party)
        {
            var connectedParty = Users.Where(i => i != null && party.Contains(i.Name)).ToList();

            var connectedPartyIds = connectedParty.Select(i => i.ConnectionId).ToArray();

            return connectedPartyIds;
        }



    }
}
