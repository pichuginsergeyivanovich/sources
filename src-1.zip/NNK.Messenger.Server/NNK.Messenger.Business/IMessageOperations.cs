using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using NNK.Messenger.Core;
using NNK.Messenger.Data;

namespace NNK.Messenger.Business
{
    public interface IMessageOperations
    {
        Message AddMessage(Guid chatDecoded, string authorDecoded, string textDecoded);

        Message AddMessage(Guid chatDecoded, string authorDecoded, string textDecoded, DateTime created, Guid? newMessageId = default(Guid?));

        IEnumerable<Message> GetMessages(Guid chatId, string timeLabel=null, string msgChkSum=null);

        IEnumerable<Guid> GetChatMessagesIDs(Guid? chatId);

        IEnumerable<Message> GetChatMessages(Guid? chatId);

        void KillMessages(Guid chatId);

        //        ChatMessage CreateInviteMessage(Guid chat, string user, string inviter, string text);
        //
        //        ChatMessage CreateInviteAcceptMessage(Guid chatId, string invited, string text);
        //
        //        ChatMessage CreateInviteRejectMessage(Guid chatId, string invited, string text);
        ChatMessage CreateCustomChatMessage(Guid chatId, string creator, string text);

        Message Get(Guid sid);

        void UpdateMessageStatus(Guid gsid, bool srvDelivered, bool delivered, bool read);

        ChatMessage AsFullChatMessage(Message message, string attachMetadata);
        void UpdateMessageText(Guid msid, string newtext);

        IEnumerable<MessageStatus> GetSidInfo(Guid msid, string username);
    }
}