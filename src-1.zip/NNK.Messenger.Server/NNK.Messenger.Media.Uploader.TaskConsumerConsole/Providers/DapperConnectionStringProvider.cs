﻿using NNK.Messenger.Core;

namespace NNK.Messenger.Media.Uploader.TaskConsumerConsole.Providers
{
    public class DapperConnectionStringProvider : IDapperConnectionStringProvider
    {
        public string ConnectionString => Properties.Settings.Default.NNKMessengerConnectionString;
    }
}