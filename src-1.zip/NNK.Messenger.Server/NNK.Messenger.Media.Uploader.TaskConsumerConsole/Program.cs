﻿using System;
using System.Threading;
using NNK.Logging;
using NNK.Logging.Loggers;
using NNK.Messenger.Business.Dapper;
using NNK.Messenger.Media.Uploader.RabbitTasks;
using NNK.RabbitMQ.Core;
using NNK.Messenger.Business;
using NNK.Messenger.Media.Uploader.TaskConsumerConsole.Helpers;
using NNK.Messenger.Media.Uploader.TaskConsumerConsole.Providers;

namespace NNK.Messenger.Media.Uploader.TaskConsumerConsole
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("press key to start resolver...");
            Console.ReadLine();
            Console.WriteLine("rabbitmq resolver started");
            ILogger logger = new ConsoleLogger();

            var dp = new DapperConnectionStringProvider();

            IAttachMetadataOperations amops = new AttachMetadataOperations(dp);

            IFileStoreOperations fops = new FileStoreOperations(dp);

            IAttachmentOperations aops = new AttachmentOperations(fops, dp);

            IPartyOperations pops = new PartyOperations(dp);

            IChatOperations cops = new ChatOperations(dp, pops);

            IMessageOperations mops = new MessageOperations(dp, cops, amops);

            ICryptoOperations crops = new CryptoOperations(logger);

            IRabbitMqTaskNotifier notifier=new RabbitMqProcessMediaTaskSignalRNotifier(logger, Properties.Settings.Default.signalRHubUrl);

            IRabbitMqTaskNotifier pnotifier = new RabbitMqProcessMediaTaskSignalRUploadProgressNotifier(logger, Properties.Settings.Default.signalRHubUrl);

            IRabbitMqTaskResolver resolver = new RabbitMqProcessMediaTaskResolver(logger,crops, fops, aops, amops, cops, mops, notifier,pnotifier, ServerSideKeyHelper.Instance.PublicKey, Properties.Settings.Default.MediaTempHost);

            IRabbitMqConnectionFactoryProvider rabbitMqConnectionFactoryProvider = new RabbitMqConnectionFactoryProvider(new RabbitMqProjectSettingsProvider());

            var worker = new RabbitMqWorker(rabbitMqConnectionFactoryProvider, resolver, logger, Properties.Settings.Default.rabbitMqQueueName);

            var t = new Thread(worker.Run);
            
            t.Start();

            t.Join();

        }
    }
}
