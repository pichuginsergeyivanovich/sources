﻿using System;
using System.Collections.Generic;
using System.Data.SqlTypes;
using System.IO;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace SqlCrypt
{
    public class SqlCrypt
    {

        public static SqlBinary AesEncrypt(byte[] key, string plaintext, byte[] iv)
        {
            using (Aes aes = new AesCryptoServiceProvider())
            {
                aes.Key = key;

                aes.IV = iv;

                using (var ciphertext = new MemoryStream())
                {
                    using (var cs = new CryptoStream(ciphertext, aes.CreateEncryptor(), CryptoStreamMode.Write))
                    {
                        byte[] plaintextMessage = Encoding.UTF8.GetBytes(plaintext);

                        cs.Write(plaintextMessage, 0, plaintextMessage.Length);

                        cs.Close();

                        return ciphertext.ToArray();
                    }
                }
            }
        }
        [Microsoft.SqlServer.Server.SqlFunction]
        public static SqlBinary AesGenerateIV()
        {
            using (Aes aes = new AesCryptoServiceProvider())
            {
                aes.GenerateIV();

                return aes.IV;
            }
        }
        [Microsoft.SqlServer.Server.SqlFunction]
        public static SqlBinary AesGenerateKey()
        {
            using (Aes aes = new AesCryptoServiceProvider())
            {
                aes.GenerateKey();

                return aes.Key;
            }
        }

        [Microsoft.SqlServer.Server.SqlFunction]
        public static SqlString ToUnicodeString(byte[] bb)
        {
            return Encoding.Unicode.GetString(bb);
        }
        [Microsoft.SqlServer.Server.SqlFunction]
        public static SqlString ToUtf8String(byte[] bb)
        {
            return Encoding.UTF8.GetString(bb);
        }
        [Microsoft.SqlServer.Server.SqlFunction]
        public static SqlString Privet()
        {
            return "Привет";
        }
        [Microsoft.SqlServer.Server.SqlFunction]
        public static SqlBinary AesDecrypt(byte[] key, byte[] encrypted, byte[] iv)
        {
            using (Aes aes = new AesCryptoServiceProvider())
            {
                aes.Key = key;
                aes.IV = iv;

                using (var plaintext = new MemoryStream())
                {
                    using (var cs = new CryptoStream(plaintext, aes.CreateDecryptor(), CryptoStreamMode.Write))
                    {
                        cs.Write(encrypted, 0, encrypted.Length);
                        cs.Close();
                        return plaintext.ToArray();
                    }
                }
            }
        }

        [Microsoft.SqlServer.Server.SqlFunction]
        public static bool IsBase64String(String str)
        {
            if (string.IsNullOrEmpty(str))
                return false;

            if (str.Contains(" "))
                return false;

            if (str.Contains("null"))
                return false;

            //our messages ends with 16 chars of aes IV 
            if (str.Length <= 16)
                return false;

            var pattern = "^([A-Za-z0-9+/]{4})*([A-Za-z0-9+/]{4}|[A-Za-z0-9+/]{3}=|[A-Za-z0-9+/]{2}==)$";

            var m = Regex.Match(str, pattern);

            return m.Success;
        }

        [Microsoft.SqlServer.Server.SqlFunction]
        public static SqlString ContentTypeFromJsonMetadata(string json)
        {
            if (string.IsNullOrEmpty(json))
                return string.Empty;

            var pairs = json.Split(new[] { "," }, StringSplitOptions.RemoveEmptyEntries);

            var l = pairs
                .Where(i => i.Trim().StartsWith("\"type\":"))
                .Select(i => i.Replace("\"type\":", ""))
                .Select(i => i.Replace("\"", ""))
                .Select(i => i.Replace(" ", ""))
                .Distinct()
                .ToArray();

            return string.Join(",", l);
        }
    }
}
