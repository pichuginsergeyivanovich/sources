﻿using System;
using System.Collections.Generic;
using System.Linq;
using Microsoft.AspNet.SignalR;
using Ninject;
using NNK.Beeline.Services.Business.Data;
using NNK.Beeline.Services.Business.Providers;
using NNK.Beeline.Services.Business.Services;
using NNK.Messenger.Business;
using NNK.Messenger.Business.Dapper;
using NNK.Messenger.Core;
using NNK.Messenger.SignalR.Helpers;
using NNK.Messenger.SignalR.Hubs;
using NNK.Messenger.SignalR.Providers;
using NNK.RabbitMQ.Core;

namespace NNK.Messenger.SignalR
{

    public class NinjectSignalRDependencyResolver : DefaultDependencyResolver
    {
        private readonly IKernel _kernel;
        public NinjectSignalRDependencyResolver(IKernel kernel)
        {
            _kernel = kernel;
            AddBindings();
        }
        public override object GetService(Type serviceType)
        {
            return _kernel.TryGet(serviceType) ?? base.GetService(serviceType);
        }

        public override IEnumerable<object> GetServices(Type serviceType)
        {
            return _kernel.GetAll(serviceType).Concat(base.GetServices(serviceType));
        }
        public void AddBindings()
        {
            try {
                _kernel.Bind<NNK.Logging.ILogger>().ToMethod((i) => TextFileLoggerSingleton.Instanse);

                _kernel.Bind<ISmsTaskRepository>().To<SmsTaskRepository>();

                _kernel.Bind<IChatOperations>().To<NNK.Messenger.Business.Dapper.ChatOperations>();

                _kernel.Bind<IAttachMetadataOperations>().To<NNK.Messenger.Business.Dapper.AttachMetadataOperations>();

                _kernel.Bind<IMessageOperations>().To<NNK.Messenger.Business.Dapper.MessageOperations>();

                _kernel.Bind<IUserOperations>().To<NNK.Messenger.Business.Dapper.UserOperations>();

                _kernel.Bind<IOperationsOperations>().To<NNK.Messenger.Business.Dapper.OperationsOperations>();

                _kernel.Bind<IIdentityOperations>().To<NNK.Messenger.Business.Dapper.IdentityOperations>();

                _kernel.Bind<IUserProvider>().To<EmptyUserProvider>();

                _kernel.Bind<NNK.RabbitMQ.Core.IRabbitMqSettingsProvider>().To<RabbitMqProjectSettingsPushProvider>();

                _kernel.Bind<NNK.Beeline.Services.Business.Providers.IRabbitMqSettingsProvider>().To<RabbitMqProjectSettingsProvider>();

                _kernel.Bind<IRecipientRepository>().To<RecipientRepository>();

                _kernel.Bind<ISmppPacketRepository>().To<SmppPacketRepository>();

                _kernel.Bind<ISmsServiceOperations>().To<SmsServiceOperations>();

                _kernel.Bind<IExchangeServiceProviderOptions>().To<ExchangeServiceProviderProjectSettingsOptions>();

                _kernel.Bind<IExchangeServiceProvider>().To<ExchangeServiceProvider>();

                _kernel.Bind<IAttachmentOperations>().To<NNK.Messenger.Business.Dapper.AttachmentOperations>();

                _kernel.Bind<IFileStoreOperations>().To<NNK.Messenger.Business.Dapper.FileStoreOperations>();

                _kernel.Bind<INotificationOperations>().To<NNK.Messenger.Business.Dapper.NotificationOperations>();

                _kernel.Bind<IPartyOperations>().To<NNK.Messenger.Business.Dapper.PartyOperations>();

                _kernel.Bind<IInviteOperations>().To<NNK.Messenger.Business.Dapper.InviteOperations>();

                _kernel.Bind<ICryptoOperations>().To<CryptoOperations>();

                _kernel.Bind<IProfileOperations>().To<ProfileOperations>();

                _kernel.Bind<IChangelogOperations>().To<ChangelogOperations>();

                

                _kernel.Bind<PushOperations>().ToSelf();

                //_kernel.Bind<IUserSessionOperations>().To<UserSessionOperations>();
                _kernel.Bind<IUserSessionOperations>().To<RedissedUserSessionOperations>();
                

                //_kernel.Bind<ChatUsersHelper>().ToMethod((i) => ChatUsersHelper.Instance).InSingletonScope();
                _kernel.Bind<ChatUsersHelper>().ToSelf().InSingletonScope();

                _kernel.Bind<IDapperConnectionStringProvider>()
                    .To<DapperAspNetIdentityConnectionStringProvider>()
                    .WhenInjectedExactlyInto<NNK.Messenger.Business.Dapper.UserOperations>();

                _kernel.Bind<IDapperConnectionStringProvider>().To<DapperConnectionStringProvider>();

                _kernel.Bind<NNK.RabbitMQ.Core.RabbitMqConnectionFactoryProvider>().ToSelf();

                _kernel.Bind<RabbitMqClient>().ToSelf();

                _kernel.Bind<ChatHub>().ToSelf();//.InSingletonScope();

                TextFileLoggerSingleton.Instanse.Message("NinjectSignalRDependencyResolver. add binding to ChatHub");

            }
            catch(Exception ex)
            {
                TextFileLoggerSingleton.Instanse.Error(ex);
            }
        }
    }
}
