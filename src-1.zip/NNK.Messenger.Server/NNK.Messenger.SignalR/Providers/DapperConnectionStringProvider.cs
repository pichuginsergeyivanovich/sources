﻿using NNK.Messenger.Core;

namespace NNK.Messenger.SignalR.Providers
{
    public class DapperConnectionStringProvider : IDapperConnectionStringProvider
    {
        //public string ConnectionString => "Data Source = 10.1.41.60; Initial Catalog = NNK.Messenger.Test; Integrated Security = True; ";
        public string ConnectionString => Properties.Settings.Default.NNKMessengerConnectionString;
    }
}
