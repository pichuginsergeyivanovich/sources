﻿using NNK.Beeline.Services.Business.Providers;

namespace NNK.Messenger.SignalR.Providers
{
    public class ExchangeServiceProviderProjectSettingsOptions : IExchangeServiceProviderOptions
    {
        public string Domain => Properties.Settings.Default.NnkDomain;

        public string Password => Properties.Settings.Default.SupportExchangeAccountPassword;

        public string Url => Properties.Settings.Default.NnkExchangeUrl;

        public string UserName => Properties.Settings.Default.SupportExchangeAccountName;
    }

}
