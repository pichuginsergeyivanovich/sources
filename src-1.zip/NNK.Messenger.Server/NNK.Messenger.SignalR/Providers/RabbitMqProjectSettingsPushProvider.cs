﻿namespace NNK.Messenger.SignalR.Providers
{
    public class RabbitMqProjectSettingsPushProvider : NNK.RabbitMQ.Core.IRabbitMqSettingsProvider
    {
        public string Host => Properties.Settings.Default.push_rabbitMqServerIp;

        public string Password => Properties.Settings.Default.push_rabbitMqServerPassword;

        public string User => Properties.Settings.Default.push_rabbitMqServerUserName;
    }
}
