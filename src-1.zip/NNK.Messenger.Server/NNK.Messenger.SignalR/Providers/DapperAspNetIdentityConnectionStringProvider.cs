﻿using NNK.Messenger.Core;

namespace NNK.Messenger.SignalR.Providers
{
    public class DapperAspNetIdentityConnectionStringProvider : IDapperConnectionStringProvider
    {
        public string ConnectionString => Properties.Settings.Default.AspNetIdentityConnectionString;
    }
}
