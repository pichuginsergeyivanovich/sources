﻿namespace NNK.Messenger.SignalR.Providers
{
    public class RabbitMqProjectSettingsProvider : NNK.Beeline.Services.Business.Providers.IRabbitMqSettingsProvider, NNK.RabbitMQ.Core.IRabbitMqSettingsProvider
    {
        public string Host => Properties.Settings.Default.rabbitMqServerIp;

        public string Password => Properties.Settings.Default.rabbitMqServerPassword;

        public string User => Properties.Settings.Default.rabbitMqServerUserName;
    }
}
