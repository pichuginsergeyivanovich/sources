﻿using NNK.Logging;

namespace NNK.Messenger.SignalR.Providers
{
    public class WebLogPathProvider : ILogParametersProvider
    {
        public string LogPath => Properties.Settings.Default.LogPath;
    }
}
