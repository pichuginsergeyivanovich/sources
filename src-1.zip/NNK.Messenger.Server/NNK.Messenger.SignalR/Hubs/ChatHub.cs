﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Threading.Tasks;
using System.Web.Hosting;
using Microsoft.AspNet.Identity;
using Microsoft.AspNet.SignalR;
using Microsoft.AspNet.SignalR.Hubs;
using Microsoft.Owin;
using NNK.Beeline.Services.Business.Providers;
using NNK.Beeline.Services.Business.Services;
using NNK.Messenger.AspNetIdentity;
using NNK.Messenger.Business;
using NNK.Messenger.Core;
using NNK.Messenger.SignalR.Helpers;

namespace NNK.Messenger.SignalR.Hubs
{
    /// <summary>
    /// Вызывается с клиента по signalR. 
    /// </summary>
    [HubName("chatHub")]
    public class ChatHub : Hub, IChatHub
    {

        static readonly Dictionary<string,TransferInfo> _fileTransferSessionStore=new Dictionary<string, TransferInfo>();

        /// <summary>
        /// 21.12.2017
        /// Описание добавится позже
        /// </summary>
        /// <param name="sidStr"></param>
        /// <param name="text"></param>
        /// <param name="fileName"></param>
        /// <param name="size"></param>
        /// <param name="type"></param>
        /// <returns></returns>
        public TransferInfo OpenFileTransferSession(string sidStr, string text, string fileName, ulong size, string type)
        {
            try
            {
                
                lock (_tlocker)
                {

                    var key = $"{sidStr}-{fileName}-{size}";

                    var ti = new TransferInfo
                        {
                            Sid = Guid.Parse(sidStr),
                            Message = text,
                            Filename = fileName,
                            SessionId = key,
                            Offset = 0,
                            Path = Path.Combine(HostingEnvironment.MapPath("~/Resources"), fileName),
                            Size = size,
                            Type = type
                        };

                        _fileTransferSessionStore.Add(ti.SessionId, ti);

                    _logger.Message("OpenFileTransferSession return with session - " + ti.SessionId);

                    Clients.Caller.openFileTransferSession(ti);

                        return ti;
                    
                }
            }
            catch (Exception ex)
            {
                _logger.Error(ex);

                if (ex.InnerException!=null)
                    _logger.Error(ex.InnerException);

                throw;
            }

        }

        IEnumerable<TransferInfo>getBySid(Guid sid)
        {
            var l = new List<TransferInfo>();
            foreach (var i in _fileTransferSessionStore)
            {
                if (i.Value.Sid == sid)
                    l.Add(i.Value);
            }
            return l.ToArray();

        }

        public async Task ResendConfirmedAttachMessage(string msid)
        {

            try
            {
                await _controller.ResendConfirmedAttachMessage(msid);
            }
            catch (Exception ex)
            {
                _logger.Error(ex);
            }
        }

        public static void ResendConfirmedAttachMessagePrivate(string msid, string user)
        {
            try
            {
                ChatHubController.ResendConfirmedAttachMessagePrivate(msid, user);
            }
            catch (Exception ex)
            {
                TextFileLoggerSingleton.Instanse.Error(ex);
            }

        }

        /// <summary>
        /// Описание добавится позже
        /// </summary>
        /// <param name="msid"></param>
        /// <param name="text"></param>
        /// <param name="chatId"></param>
        /// <returns></returns>
        public async Task CloseFileTransferSession(string msid, string text, string chatId)
        {
            try
            {
                var sid = Guid.Parse(msid);
                    
                var items = getBySid(sid);

                var message = text;

                await _controller.CloseFileTransferSessionAddAttachments(items, sid);

                await _controller.AddAttachmentMessage(message, sid, Guid.Parse(chatId));

                foreach (var i in items)
                {
                    if (_fileTransferSessionStore.ContainsKey(i.SessionId))
                        _fileTransferSessionStore.Remove(i.SessionId);
                }

                await Clients.Caller.closeFileTransferSession(msid);

            }
            catch (Exception ex)
            {
                _logger.Error(ex);

                throw;
            }
        }

        object _tlocker = new object();

        /// <summary>
        /// Описание добавится позже
        /// </summary>
        /// <param name="sidStr"></param>
        /// <param name="fileName"></param>
        /// <param name="size"></param>
        /// <param name="partIndexStr"></param>
        /// <param name="bytesStr"></param>
        /// <param name="chatIdStr"></param>
        public void TransferFilePart(string sidStr, string fileName, ulong size, string partIndexStr, string bytesStr, string chatIdStr)
        {
            var key = $"{sidStr}-{fileName}-{size}";

            var sid = Guid.Parse(sidStr);

            var chatId = Guid.Parse(chatIdStr);

            var partIndex = int.Parse(partIndexStr);

            lock (_tlocker)
            {
                try {
                    var bytes = Convert.FromBase64String(bytesStr);
                    _logger.Message("TransferFilePart called with filename- " + fileName);
                    _logger.Message("TransferFilePart called with bytes length- " + bytes.Length);
                    _logger.Message("TransferFilePart called with sid - " + sid);
                    _logger.Message("TransferFilePart called with chatId - " + chatId);
                    _logger.Message("TransferFilePart called with partIndex - " + partIndex);
                    _logger.Message("TransferFilePart called with size - " + size);

                    if (!_fileTransferSessionStore.ContainsKey(key))
                        return;

                    var ti = _fileTransferSessionStore[key];

                    _logger.Message("TransferFilePart called with complete - " + ti.Complete);
                    _logger.Message("TransferFilePart called with offset - " + ti.Offset);

                    using (var fs = File.OpenWrite(ti.Path))
                    {
                        

                        fs.Seek(ti.Offset, SeekOrigin.Begin);

                        fs.Write(bytes, 0, bytes.Length);

                        fs.Close();

                        ti.Offset += bytes.Length;

                        Clients.Caller.transferFileSession(new { sid, key, offset = ti.Offset, percent = (double)ti.Offset / (double)ti.Size });

                        _logger.Message("TransferFilePart returned percent -  " + (double)ti.Offset / (double)ti.Size);





                        if (ti.Complete)
                        {
                            //_controller.EncryptDataFile(ServerSideKeyHelper.Instance.PublicKey, ti.Path, ti.Path + ".secret");

                            _logger.Message("TransferFilePart: transfer complete, delete work data");

                            return;
                        }

                    }
                    
                }
                catch(Exception ex)
                {
                    _logger.Error(ex);
                }
            }
        }
        
        private readonly NNK.Logging.ILogger _logger;
        private readonly IIdentityOperations _idops;
        private readonly PushOperations _puops;
        private readonly IProfileOperations _props;
        private ICryptoOperations _crops;
        private IAttachmentOperations _aops;
        private IFileStoreOperations _fops;
        private INotificationOperations _nops;
        private IPartyOperations _pops;
        private IChatOperations _cops;
        private IAttachMetadataOperations _amops;
        private IMessageOperations _mops;
        private IUserOperations _uops;

        private IOwinContext _context;
        private IOperationsOperations _oops;

        private IInviteOperations _iops;

        private UserManager<User, int> _userManager;

        private ISmsServiceOperations _smsServiceOps;

        private readonly ChatHubController _controller;

        private IExchangeServiceProvider _exchangeProvider;

        private ChatUsersHelper _chatUsersHelper;

        private IChangelogOperations _clops;

        private NNK.RabbitMQ.Core.RabbitMqConnectionFactoryProvider _rcfp;

        public ChatHubController GetController()
        {
            return _controller;
        }

        public HubCallerContext GetContext()
        {
            return Context;
        }

        /*
        public ChatHub(ChatHubController controller, ILogger logger)
        {
            _controller = controller;

            _logger = logger;

        }*/
        
        public ChatHub(
            //NNK.Logging.ILogger logger,
            //ICryptoOperations crops,
            //IAttachmentOperations aops,
            //IFileStoreOperations fops,
            //INotificationOperations nops,
            //IPartyOperations pops,
            //IChatOperations cops,
            //IAttachMetadataOperations amops,
            //IMessageOperations mops,
            //IUserOperations uops,
            //IOwinContext context,
            //IOperationsOperations oops,
            //IInviteOperations iops,
            //UserManager<User, int> userManager,
            //ISmsServiceOperations smsServiceOps,
            //IExchangeServiceProvider exchangeProvider,
            //ChatUsersHelper chatUsersHelper,
            //IIdentityOperations idops,
            //PushOperations puops,            
            //NNK.RabbitMQ.Core.RabbitMqConnectionFactoryProvider rcfp,
            //IProfileOperations props,
            //IChangelogOperations clops
            //RabbitMqClient rc
            )
        {

            if (!(GlobalHost.DependencyResolver  is NinjectSignalRDependencyResolver))
            {
                GlobalHost.DependencyResolver = new NinjectSignalRDependencyResolver(new Ninject.StandardKernel());
            }



            this._logger = (NNK.Logging.ILogger) GlobalHost.DependencyResolver.GetService(typeof(NNK.Logging.ILogger));

            this._crops = (ICryptoOperations)GlobalHost.DependencyResolver.GetService(typeof(ICryptoOperations));

            this._aops = (IAttachmentOperations)GlobalHost.DependencyResolver.GetService(typeof(IAttachmentOperations));

            this._fops = (IFileStoreOperations)GlobalHost.DependencyResolver.GetService(typeof(IFileStoreOperations));

            this._nops = (INotificationOperations)GlobalHost.DependencyResolver.GetService(typeof(INotificationOperations));

            this._pops = (IPartyOperations)GlobalHost.DependencyResolver.GetService(typeof(IPartyOperations));

            this._cops = (IChatOperations)GlobalHost.DependencyResolver.GetService(typeof(IChatOperations));

            this._amops = (IAttachMetadataOperations)GlobalHost.DependencyResolver.GetService(typeof(IAttachMetadataOperations));

            this._mops = (IMessageOperations)GlobalHost.DependencyResolver.GetService(typeof(IMessageOperations));

            this._uops = (IUserOperations)GlobalHost.DependencyResolver.GetService(typeof(IUserOperations));

            this._context = (IOwinContext)GlobalHost.DependencyResolver.GetService(typeof(IOwinContext));

            this._oops = (IOperationsOperations)GlobalHost.DependencyResolver.GetService(typeof(IOperationsOperations));

            this._iops = (IInviteOperations)GlobalHost.DependencyResolver.GetService(typeof(IInviteOperations));

            this._userManager = (UserManager<User, int>)GlobalHost.DependencyResolver.GetService(typeof(UserManager<User, int>));

            this._smsServiceOps = (ISmsServiceOperations)GlobalHost.DependencyResolver.GetService(typeof(ISmsServiceOperations));

            this._exchangeProvider = (IExchangeServiceProvider)GlobalHost.DependencyResolver.GetService(typeof(IExchangeServiceProvider));

            this._chatUsersHelper = (ChatUsersHelper)GlobalHost.DependencyResolver.GetService(typeof(ChatUsersHelper));

            this._idops = (IIdentityOperations)GlobalHost.DependencyResolver.GetService(typeof(IIdentityOperations));

            this._puops = (PushOperations)GlobalHost.DependencyResolver.GetService(typeof(PushOperations));

            this._rcfp = (NNK.RabbitMQ.Core.RabbitMqConnectionFactoryProvider)GlobalHost.DependencyResolver.GetService(typeof(NNK.RabbitMQ.Core.RabbitMqConnectionFactoryProvider));

            this._props = (IProfileOperations)GlobalHost.DependencyResolver.GetService(typeof(IProfileOperations));

            this._clops = (IChangelogOperations)GlobalHost.DependencyResolver.GetService(typeof(IChangelogOperations));
            

            _controller = new ChatHubController(
                 Properties.Settings.Default.TokenURL,
                _logger,
                _crops,
                _aops,
                _fops,
                _nops,
                _pops,
                _cops,
                _amops,
                _mops,
                _uops,
                _context,
                _oops,
                _iops,
                _userManager,
                _smsServiceOps,
                _exchangeProvider,
                _chatUsersHelper,
                _idops,
                _puops,
                _rcfp,
                _props,
                _clops
            );

            _controller.SetupHubCallerConnectionContext(() => Clients);

            _controller.SetupHubCallerContext(() => Context);

            _logger.Message("in chat hub constructor");


        }
        private static IHubConnectionContext<dynamic> GetClients()
        {
            return GlobalHost.ConnectionManager.GetHubContext<ChatHub>().Clients;
        }
        public static void Send(ChatHubControllerSendResult res)
        {
            IHubConnectionContext<dynamic> clients = GetClients();

            clients.Clients(res.connectedPartyIds).addMessage(res);
            
        }


        /// <summary>
        /// Возвращает токен аутентификации. 
        /// Вызывает на вызвавшем клиенте функцию getToken(obj), где obj - информация в формате json с токеном
        /// </summary>
        /// <param name="username"></param>
        /// <param name="password"></param>
        /// <returns></returns>
        public async Task Token(string username, string password)
        {
            try
            {
                await _controller.Token(username, password);
            }
            catch (Exception ex)
            {
                _logger.Error(ex);
            }
        }

        /// <summary>
        /// Принимает сообщение от клиента. (chatId="new" или null, chksum и msgchksum не заполняются)
        /// Записывает в бд и возвращает его в json с серверными параметрами. 
        /// У всех подключенных клиентов с пользователями чата данного сообщения вызывается метод addMessage(newMessage), где newMessage - полученный json
        /// </summary>
        /// <param name="message"></param>
        /// <returns>объект отправки: {align:"-webkit-right",author:"@test2",chatId:undefined,created:"2017-08-25T13:34:34.032Z",message:"ppp",party:undefined,sid:"37ac7faa-3dc7-4277-8e8d-128175547873",user:"@test2"}
        /// объект возврата: такой же но с заполненными chatId, chksum и msgchksum
        /// </returns>
        [Microsoft.AspNet.SignalR.Authorize]
        public async Task Send(ChatMessage message)
        {
            try
            {
                 var result = await _controller.Send(message);

            }
            catch (Exception ex)
            {
                _logger.Error(ex);

                throw;
            }
        }

        [Microsoft.AspNet.SignalR.Authorize]
        public async Task SendStatusTyping(string chatId)
        {
            try
            {
                var userName = Context.Request.User.Identity.Name;

                var userId = Context.Request.User.Identity.GetUserId();

                var isAuth = Context.Request.User.Identity.IsAuthenticated;

                await _controller.SendStatusTyping(userId, userName, chatId);

            }
            catch (Exception ex)
            {
                _logger.Error(ex);

                throw;
            }
        }
        [Microsoft.AspNet.SignalR.Authorize]
        public async Task GetOnlineUsers()
        {
            try
            {
                await _controller.GetOnlineUsers();
            }
            catch (Exception ex)
            {
                _logger.Error(ex);

                throw;
            }
        }

        [Microsoft.AspNet.SignalR.Authorize]
        public async Task SaveProfile(string base64Json)
        {
            try
            {
                var userName = Context.Request.User.Identity.Name;

                var userId = Context.Request.User.Identity.GetUserId();

                var isAuth = Context.Request.User.Identity.IsAuthenticated;

                await _controller.SaveProfile(userId, userName, base64Json);
            }
            catch (Exception ex)
            {
                _logger.Error(ex);

                throw;
            }
        }
        [Microsoft.AspNet.SignalR.Authorize]
        public async Task GetProfile()
        {
            try
            {
                var userName = Context.Request.User.Identity.Name;

                var userId = Context.Request.User.Identity.GetUserId();

                var isAuth = Context.Request.User.Identity.IsAuthenticated;

                await _controller.GetProfile(userId, userName);
            }
            catch (Exception ex)
            {
                _logger.Error(ex);

                throw;
            }

        }

        /// <summary>
        /// 21.12.2017
        /// Функция шифрует серверный симметричный ключ ассиметричным публичным пользовательским ключом для передачи серверного ключа пользователю. 
        /// На вызвавшем клиенте вызывается answerForMainQuestionOfLifeUniverseAndEtc(obj) obj - base64 кодированный шифр
        /// </summary>
        /// <returns></returns>
        [Microsoft.AspNet.SignalR.Authorize]
        public async Task AskForMainQuestionOfLifeUniverseAndEtc()
        {
            try
            {
                 await _controller.AskForMainQuestionOfLifeUniverseAndEtc(Context.User.Identity.GetUserId());
            }
            catch (Exception ex)
            {
                _logger.Error(ex);

                throw;
            }
        }

        /// <summary>
        /// 21.12.2017
        /// Версия функции Send, с шифрованием серверным ключом текста сообщения. Остальное всё как в функции Send.
        /// </summary>
        /// <param name="message"></param>
        /// <returns></returns>
        [Microsoft.AspNet.SignalR.Authorize]
        //[Pushable]
        public async Task SendE(ChatMessage message)
        {
            try
            {
                await OnConnected();

                var result = await _controller.SendE(message);
            }
            catch (Exception ex)
            {
                _logger.Error(ex);

                throw;
            }
        }

        [Microsoft.AspNet.SignalR.Authorize]
        //[Pushable]
        public async Task SendE_(ChatMessage message)
        {
            try
            {
                await OnConnected();

                var result = await _controller.SendE_(message);
            }
            catch (Exception ex)
            {
                _logger.Error(ex);

                throw;
            }
        }

        /// <summary>
        /// 23.11.2018
        /// Версия функции SendE1, с созданием нового чата из сообщения. Остальное всё как в функции SendE.
        /// </summary>
        /// <param name="message"></param>
        /// <returns></returns>
        [Microsoft.AspNet.SignalR.Authorize]
        public async Task E1Send(ChatMessage message)
        {
            try
            {
                await OnConnected();

                await _controller.E1Send(message);
            }
            catch (Exception ex)
            {
                _logger.Error(ex);

                throw;
            }
        }
        public override Task OnReconnected()
        {
            try
            {
                if (Context.Request.User == null)
                    return base.OnReconnected();

                var userName = Context.Request.User.Identity.Name;

                var userId = Context.Request.User.Identity.GetUserId();

                var isAuth = Context.Request.User.Identity.IsAuthenticated;

                _controller.OnConnected(userName, userId, isAuth);

            }
            catch (Exception ex)
            {
                _logger.Error(ex);
            }


            return base.OnReconnected();
        }
        /// <summary>
        /// Системная ф-я.
        /// В процессе выполнения вызывает 
        /// 1. на вызвавшем клиенте функцию onConnected(obj), где obj - инфо о подключённом пользователе
        /// 2. на всех клиентах кроме вызвавшего функцию onUserConnected(obj), где obj - инфо о подключённом пользователе
        /// </summary>
        /// <returns></returns>
        [Microsoft.AspNet.SignalR.Authorize]
        public override Task OnConnected()
        {
            try
            {
                if (Context.Request.User == null)
                    return base.OnConnected();

                var userName = Context.Request.User.Identity.Name;

                var userId = Context.Request.User.Identity.GetUserId();

                var isAuth = Context.Request.User.Identity.IsAuthenticated;

                _controller.OnConnected(userName, userId, isAuth);

            }
            catch (Exception ex)
            {
                _logger.Error(ex);
            }
            return base.OnConnected();
        }

        /// <summary>
        /// Системная ф-я.
        /// В процессе выполнения вызывает на всех клиентах кроме вызвавшего функцию onUserDisconnected(obj), где obj - инфо об отключённом пользователе
        /// </summary>
        /// <param name="stopCalled"></param>
        /// <returns></returns>
        [Microsoft.AspNet.SignalR.Authorize]
        public override Task OnDisconnected(bool stopCalled)
        {
            try
            {
                _controller.OnDisconnected();
            }
            catch (Exception ex)
            {
                _logger.Error(ex);
            }

            return base.OnDisconnected(stopCalled);
        }

        [Microsoft.AspNet.SignalR.Authorize]
        public async Task GetChatMessagesToUser(string chatId)
        {
            try
            {
                if (string.IsNullOrEmpty(chatId))
                    throw new ApplicationException("Chat is null or empty");

                //var chatMessages = 
                await _controller.GetChatMessagesToUser(Guid.Parse(chatId));
            }
            catch (Exception ex)
            {
                _logger.Error(ex);
                throw;
            }
        }

        /// <summary>
        /// Получает все сообщения всех чатов пользователя user в формате словаря ключ=id guid чата, value=массив сообщений чата
        /// Вызывает на вызвавшем клиенте функцию getAllMessages(dict), где dict - словарь с сообщениями
        /// </summary>
        /// <param name="user">имя пользователя</param>
        /// <param name="timeLabel">метка времени - необязательный параметр</param>
        /// <param name="msgChkSum">контрольная сумма чата - необязательный параметр</param>
        /// <returns></returns>
        [Microsoft.AspNet.SignalR.Authorize]
        public async Task GetAllMessages(string user, string timeLabel = null, string msgChkSum = null)
        {
            try
            {
                var dict = await _controller.ChatMessages(user, timeLabel, msgChkSum);
            }
            catch (Exception ex)
            {
                _logger.Error(ex);
                throw;
            }
        }

        /// <summary>
        /// Получает все сообщения пользователя user для чата chat 
        /// Вызывает на вызвавшем клиенте функцию getChatMessages(chatMessages), где chatMessages - массив сообщений чата
        /// </summary>
        /// <param name="user"></param>
        /// <param name="chat"></param>
        /// <param name="msgChkSum">контрольная сумма всего чата с сообщениями, вычисляется после отправки очередного сообщения. Можно сохранить на клиенте и включив в данный вызов получим только новые сообщения(после отправленного)</param>
        /// <returns></returns>
        [Microsoft.AspNet.SignalR.Authorize]
        public async Task GetUserChatMessages(string user, string chat, string msgChkSum = null)
        {
            try
            {
                var v1 = await _controller.GetUserChatMessages(user, chat, msgChkSum, Context.ConnectionId);
            }
            catch (Exception ex)
            {
                _logger.Error(ex);
                throw;
            }
        }

        /// <summary>
        /// Получает описания всех чатов пользователя user. 
        /// Вызывает на вызвавшем клиенте функцию getAllChats(chats), где chats - массив с описаниями чата
        /// </summary>
        /// <param name="user">имя пользователя</param>
        /// <param name="timeLabel">метка времени - необязательный параметр</param>
        /// <returns></returns>
        [Microsoft.AspNet.SignalR.Authorize]
        public async Task GetAllChats(string user, string timeLabel = null)
        {
            try
            {
                var chats = await _controller.GetAllChats(user, timeLabel);
            }
            catch (Exception ex)
            {
                _logger.Error(ex);
                throw;
            }
        }

        /// <summary>
        /// Получает описания всех учатсников чатов пользователя user. 
        /// Вызывает на вызвавшем клиенте функцию getAllParty(patries), где parties массив с описанием участника чата 
        /// </summary>
        /// <param name="user">имя пользователя</param>
        /// <param name="timeLabel">метка времени - необязательный параметр</param>
        /// <returns></returns>
        [Microsoft.AspNet.SignalR.Authorize]
        public async Task GetAllParty(string user, string timeLabel = null)
        {
            try
            {
                var chats = await _controller.GetAllParty(user, timeLabel);
            }
            catch (Exception ex)
            {
                _logger.Error(ex);
                throw;
            }
        }

        /// <summary>
        /// Получает имена всех пользователей на сервере.
        /// Вызывает на вызвавшем клиенте функцию getAllUsers(users), где users массив с именами пользователей 
        /// </summary>
        /// <param name="timeLabel"></param>
        /// <returns>пример [{Email:"admin@example.com",Modified:"2017-08-06T12:40:13.847,"PhoneNumber:null,UserID:1,UserName:"admin"}]</returns>
        [Microsoft.AspNet.SignalR.Authorize]
        public async Task GetAllUsers(string timeLabel = null)
        {
            try
            {
                var users = await _controller.GetAllUsers(timeLabel);
            }
            catch (Exception ex)
            {
                _logger.Error(ex);
            }
        }

        /// <summary>
        /// Получает описания всех чатов пользователя user. 
        /// Вызывает на вызвавшем клиенте функцию getUserChatList(chats), где chats - массив с описаниями чата
        /// </summary>
        /// <param name="user"></param>
        /// <returns></returns>
        [Microsoft.AspNet.SignalR.Authorize]
        public async Task GetUserChatList(string user)
        {
            try
            {
                var chats = await _controller.GetUserChatList(user);
            }
            catch (Exception ex)
            {
                _logger.Error(ex);
                throw;
            }
        }
        
        /// <summary>
        /// Если вызов проходит, на вызвавшем клиенте функцию ping(true), иначе - ошибка.
        /// </summary>
        /// <returns></returns>
        [Microsoft.AspNet.SignalR.Authorize]
        public async Task<bool> Ping()
        {
            try
            {
                await _controller.Ping();

                return true;
                //return await Task.Run(() => true);
            }
            catch (Exception ex)
            {
                _logger.Error(ex);

                return false;
            }
        }
        
        /// <summary>
        /// Проверяет существование пользователя по определённому параметру. 
        /// Можно проверить существование пользователя по имени, почте и номеру телефона.
        /// В качестве параметра передаётся json строка, закодированная в base64. 
        /// На js она собирается так(для почты):
        /// var pair=btoa(JSON.stringify({'value':'sample@sample.ru','key':'email'}));
        /// Для имени пользователя key='login'
        /// Для номера телефона key='sms'
        /// На вызвавшем клиенте вызывается функция validate(boolean), где boolean - true, если пользователь найден в бд по параметру, иначе - false
        /// Функция используется для валидации формы регистрации нового пользователя
        /// </summary>
        /// <param name="pair"></param>
        /// <returns></returns>
        public async Task Validate(string pair)
        {
            try
            {
                var res = await _controller.Validate(pair);
            }
            catch (Exception ex)
            {
                _logger.Error(ex);

                throw;
            }
        }

        /// <summary>
        /// Создаёт в системе "операцию, требующую подтверждения".
        /// На данный момент id="register", methhod="sms", data - json строка кодированная в base64
        /// На js собирается так: var data=btoa(JSON.stringify(this.reg_login_data)=='{}'?'empty':JSON.stringify(this.reg_login_data));
        /// Где this.reg_login_data - экземпляр класса:
        /// class RegLoginData{
        /// login:string;
        /// password:string;
        /// confirm_password:string;
        /// phone:string;
        /// email:string;
        /// }
        /// На вызвавшем клиенте вызывает функцию operation(result), где result - id строка с guid созданной в бд операцией.
        /// </summary>
        /// <param name="id"></param>
        /// <param name="method"></param>
        /// <param name="data"></param>
        /// <returns></returns>
        public async Task Operation(string id, string method, string data)
        {
            try
            {
                var result = await _controller.Operation(id, method, data);
            }
            catch (Exception ex)
            {
                _logger.Error(ex);
            }
        }

        /// <summary>
        /// Подтверждает "операцию, требующую подтверждения", полученным по смс кодом. Сейчас код просто генерируется в бд, получить его пока можно только вручную. В дальнейшем планируется присылать на телефон через смс.
        /// На вызвавшем клиенте вызывается функция confirmOperation("ok"), если всё прошло хорошо, иначе - confirmOperation("failed\r\n"+ result.Errors), где result.Errors - ошибки
        /// </summary>
        /// <param name="id">id операции(в base64)</param>
        /// <param name="code">(в base64)</param>
        /// <returns></returns>
        public async Task ConfirmOperation(string id, string code)
        {
            try
            {
                await _controller.ConfirmOperation(id, code);
            }
            catch (Exception ex)
            {
                _logger.Error(ex);
            }
        }

        protected string GetIpAddress()
        {
            string ipAddress;
            object tempObject;

            Context.Request.Environment.TryGetValue("server.RemoteIpAddress", out tempObject);

            if (tempObject != null)
            {
                ipAddress = (string)tempObject;
            }
            else
            {
                ipAddress = "";
            }

            return ipAddress;
        }

        /// <summary>
        /// Ф-я сохраняет в бд информацию о доставле сообщения на клиент.
        /// Функция вызывает у автора сообщения, к которому относится нотификация функцию getMessageReadStatus(statusObj)
        /// statusObj - {
        ///                 sid, - id сообщения
        ///                 party - кол-во получателей сообщения,
        ///                 delivered - флаг доставки сообщения всем получателям, если всем доставлено тогда - true,
        ///                 read - флаг почтения сообщения всеми получателями, если всеми прочитано тогда - true,
        ///                 srvDelivered - флаг доставки сообщения на сервер
        ///};
        /// </summary>
        /// <param name="sid"></param>
        /// <param name="clientDate"></param>
        /// <param name="clientDescr"></param>
        /// <returns></returns>
        public async Task SendMessageNotification(string sid, DateTime clientDate, string clientDescr)
        {
            try
            {
                await _controller.SendMessageNotification(sid, clientDate, clientDescr, GetIpAddress(), Context.ConnectionId, $"@{Context.Request.User?.Identity.GetUserName()}");
            }
            catch (Exception ex)
            {
                _logger.Error(ex);
            }
        }
        
        /// <summary>
        /// 21.12.2017
        /// Ф-я сохраняет в бд информацию о прочтении сообщения на клиенте.
        /// Функция вызывает у автора сообщения, к которому относится нотификация функцию getMessageReadStatus(statusObj)
        /// statusObj - {
        ///                 sid, - id сообщения
        ///                 party - кол-во получателей сообщения,
        ///                 delivered - флаг доставки сообщения всем получателям, если всем доставлено тогда - true,
        ///                 read - флаг почтения сообщения всеми получателями, если всеми прочитано тогда - true,
        ///                 srvDelivered - флаг доставки сообщения на сервер
        ///};
        /// </summary>
        /// <param name="sid"></param>
        /// <param name="clientDate"></param>
        /// <param name="clientDescr"></param>
        /// <returns></returns>
        [Microsoft.AspNet.SignalR.Authorize]
        public async Task SendMessageNotification2(string sid, DateTime clientDate, string clientDescr)
        {
            try
            {
                _logger.Message($"cid:{Context.ConnectionId}, sid:{sid} message readed on {clientDate.ToUniversalTime()}, user:{Context.Request.User?.Identity.GetUserName()} ");

                await _controller.SendMessageNotification2(sid, clientDate, clientDescr, GetIpAddress(), Context.ConnectionId, $"@{Context.Request.User?.Identity.GetUserName()}");
            }
            catch (Exception ex)
            {
                _logger.Error(ex);
            }
        }

        [Microsoft.AspNet.SignalR.Authorize]
        public async Task SendMessageNotification3(string chatid, DateTime clientDate, string clientDescr)
        {
            try
            {
                _logger.Message($"cid:{Context.ConnectionId}, chat:{chatid} messages read on {clientDate.ToUniversalTime()}, user:{Context.Request.User?.Identity.Name/*.GetUserName()*/} ");

                await _controller.SendMessageNotification3(chatid, clientDate, clientDescr, GetIpAddress(), Context.ConnectionId, $"@{Context.Request.User?.Identity.Name/*.GetUserName()*/}");
            }
            catch (Exception ex)
            {
                _logger.Error(ex);
            }
        }
        /// <summary>
        /// Временная -функция. Возвращает код подтверждения для операции.
        /// На вызвавшем клиенте вызывается ф-я getConfirmSecret(code.GenCode)
        /// </summary>
        /// <param name="operationId">(в base64)</param>
        /// <returns></returns>
        public async Task GetConfirmSecret(string operationId)
        {
            try
            {
                await _controller.GetConfirmSecret(operationId);
            }
            catch (Exception ex)
            {
                _logger.Error(ex);

                throw;
            }

        }

        /// <summary>
        /// Получает все приглашения пользователя в чаты.
        /// На вызвавшем клиенте вызывает ф-ю getFreshInvites(invites), где invites - массив с приглашениями
        /// </summary>
        /// <param name="user"></param>
        /// <returns></returns>
        [Microsoft.AspNet.SignalR.Authorize]
        public async Task GetUserInvites(string user)
        {
            try
            {
                var invites = await _controller.GetUserInvites(user);
            }
            catch (Exception ex)
            {
                _logger.Error(ex);

                throw;
            }
        }

        /// <summary>
        /// В процессе выполнения удаляется вся информация о чате в бд.
        /// На всех клиентах вызывается ф-я onKillChat(chatId);
        /// </summary>
        /// <param name="chatId"></param>
        /// <returns></returns>
        [Microsoft.AspNet.SignalR.Authorize]
        public async Task KillChat(Guid? chatId)
        {
            try
            {
                await _controller.KillChat(chatId);
            }
            catch (Exception ex)
            {
                _logger.Error(ex);
            }
        }


        /// <summary>
        /// Регистрирует приглашение пользователя в чат.
        /// На вызвавшем клиенте вызывает ф-у onUserInvited({chatId:chatId, inviter:user});
        /// У всех подключенных клиентов с пользователями чата данного сообщения вызывается метод addMessage(newMessage) с сообщением о приглашении пользователя в чат
        /// </summary>
        /// <param name="chatId"></param>
        /// <param name="user"></param>
        /// <param name="inviter"></param>
        /// <returns></returns>
        [Microsoft.AspNet.SignalR.Authorize]
        public async Task InviteUser(string chatId, string user, string inviter)
        {
            try
            {
                var result = await _controller.InviteUser(chatId, user, inviter);
            }
            catch (Exception ex)
            {
                _logger.Error(ex);

                throw;
            }
        }

        /// <summary>
        /// Ф-я отклоняет приглашение в чат.
        /// У всех подключенных клиентов с пользователями чата вызывается метод addMessage(newMessage) с сообщением об отклонении приглашения пользователя в чат
        /// У всех подключенных клиентов с пользователями чата вызывается метод onUserInviteRejected(user)
        /// </summary>
        /// <param name="inviteId"></param>
        /// <returns></returns>
        [Microsoft.AspNet.SignalR.Authorize]
        public async Task RejectInvite(string inviteId)
        {
            try
            {
                var result = await _controller.RejectInvite(inviteId);
            }
            catch (Exception ex)
            {
                _logger.Error(ex);
            }
        }

        /// <summary>
        /// Ф-я принимает приглашение в чат. Добавляет пользователя принявшего приглашение в чат в учатники чата.
        /// У всех подключенных клиентов с пользователями чата вызывается метод addMessage(newMessage) с сообщением о присоединении к чату пользователя
        /// У всех подключенных клиентов с пользователями чата вызывается метод onUserInviteAccepted(user)
        /// </summary>
        /// <param name="inviteId"></param>
        /// <returns></returns>
        [Microsoft.AspNet.SignalR.Authorize]
        public async Task AcceptInvite(string inviteId)
        {
            try
            {
                var result = await _controller.AcceptInvite(inviteId);
            }
            catch (Exception ex)
            {
                _logger.Error(ex);
            }
        }

        /// <summary>
        /// Удаляет приглашение из бд.
        /// На вызвавшем клиенте вызывается ф-я onInviteDeleted(inviteId);
        /// </summary>
        /// <param name="inviteId"></param>
        /// <returns></returns>
        [Microsoft.AspNet.SignalR.Authorize]
        public async Task DeleteInvite(string inviteId)
        {
            try
            {
                await _controller.DeleteInvite(inviteId);
            }
            catch (Exception ex)
            {
                _logger.Error(ex);
            }
        }

        /// <summary>
        /// Присылает описание файловых вложений к сообщению c id=msid
        /// На вызвавшем клиенте вызывается ф-я await onMetadataSent(1);
        /// </summary>
        /// <param name="msid"></param>
        /// <param name="meta"></param>
        /// <returns></returns>
        [Microsoft.AspNet.SignalR.Authorize]
        public async Task SendMetadata(Guid msid, string meta)
        {
            try
            {
                await _controller.SendMetadata(msid, meta);
            }
            catch (Exception ex)
            {
                _logger.Error(ex);
            }
        }




        /// <summary>
        /// Удаляет пользователя user из участников чата chatId в объекте чата и из участников чата в объектах(таблицах) party.
        /// На всех подключённых клиентах вызывается ф-я onUserLeftChat({chat, user});
        /// </summary>
        /// <param name="chatId"></param>
        /// <param name="user"></param>
        /// <returns></returns>
        [Microsoft.AspNet.SignalR.Authorize]
        public async Task LeaveChat(Guid? chatId, string user)
        {
            try
            {
                await _controller.LeaveChat(chatId, user);
            }
            catch (Exception ex)
            {
                _logger.Error(ex);
            }
        }

        /// <summary>
        /// Функция создаёт групповой чат.
        /// После создания на вызвавшем клиенте вызывается ф-я onGroupChatCreated(chatId);
        /// На всех других подключённых клиентах вызывается onNewChatCreated(chatId);
        /// </summary>
        /// <param name="selected">список участников</param>
        /// <param name="title">название чата</param>
        /// <param name="user">автор-кто создаёт</param>
        /// <returns></returns>
        [Microsoft.AspNet.SignalR.Authorize]
        public async Task CreateGroupChat(string[] selected, string title, string user)
        {
            try
            {
                var result = await _controller.CreateGroupChat(selected, title, user);
            }
            catch (Exception ex)
            {
                _logger.Error(ex);
            }
        }

        /// <summary>
        /// 21.12.2017
        /// Функция создания закрытого(секретного) группового чата.
        /// После создания на вызвавшем клиенте вызывается ф-я onGroupChatCreated(chatId);
        /// На всех других подключённых клиентах вызывается onNewChatCreated(chatId);
        /// </summary>
        /// <param name="selected"></param>
        /// <param name="title"></param>
        /// <param name="user"></param>
        /// <param name="passwordb64"></param>
        /// <param name="hidden"></param>
        /// <returns></returns>
        [Microsoft.AspNet.SignalR.Authorize]
        public async Task CreateSecretGroupChat(string[] selected, string title, string user, string passwordb64=null, bool hidden=false)
        {
            try
            {
                var result = await _controller.CreateGroupChat(selected, title, user, passwordb64, hidden);
            }
            catch (Exception ex)
            {
                _logger.Error(ex);
            }
        }

        /// <summary>
        /// 21.12.2017
        /// Проверяет вход в чат по паролю.
        /// На вызвавшем клиенте вызывается chatPasswordValid(res), res - true, если вход по паролю осуществлён
        /// </summary>
        /// <param name="chatId"></param>
        /// <param name="passwordb64"></param>
        /// <returns></returns>
        [Microsoft.AspNet.SignalR.Authorize]
        public async Task ValidateSecretChat(Guid? chatId, string passwordb64)
        {
            try
            {
                var result = await _controller.ValidateSecretChat(chatId, passwordb64);
            }
            catch (Exception ex)
            {
                _logger.Error(ex);
            }
        }

        /// <summary>
        /// 21.12.2017
        /// Регистрирует пользовательские ключи на сервере.
        /// На данный момент ожидается такая структура:
        /// На сервере из неё(да данный момент) вычитываются поля identityKey(публичный rsa(модулус)) и devKey(токен устройства для пушей в hex строке)
        /// {
        ///    "identityKey":ToBase64String(rsa.ExportParameters(false).Modulus),
        ///    "identityKeyE":ToBase64String(rsa.ExportParameters(false).Exponent),
        ///    "devKey":"B0AA31BF43C1FADB78B6CB0D9E8E6BF8CA1225D68B756F5F0D450FB8CA10CAA9",
        ///    "signedPreKey":this.signedPreKey.publicKey,
        ///    "signedPreKeyHash":this.signedPreKeyHash,
        ///    "oneTimeKeys":[]
        ///};
        /// </summary>
        /// <param name="b64PublicKeys"></param>
        /// <param name="forceRegister"></param>
        /// <returns></returns>
        [Microsoft.AspNet.SignalR.Authorize]
        public async Task RegisterUserKeys(string b64PublicKeys, bool forceRegister=false)
        {
            try
            {
                var u = Context.User.Identity.GetUserId();

                await _controller.RegisterUserKeys(b64PublicKeys,u, forceRegister);
            }
            catch (Exception ex)
            {
                _logger.Error(ex);
            }
        }


        public async Task RegisterUserKeys1(string b64PublicKeys, bool forceRegister = false)
        {
            try
            {
                var u = Context.User.Identity.GetUserId();

                await _controller.RegisterUserKeys(b64PublicKeys, u, forceRegister);
            }
            catch (Exception ex)
            {
                _logger.Error(ex);
            }
        }

        /// <summary>
        /// Возвращает пользовательские ключи. На вызвавшем клиенте вызывается onGetUserKeys(keys) по факту identityKey и devKey
        /// </summary>
        /// <param name="user"></param>
        /// <returns></returns>
        [Microsoft.AspNet.SignalR.Authorize]
        public async Task GetUserKeys(string user)
        {
            try
            {
                await _controller.GetUserKeys(user);
            }
            catch (Exception ex)
            {
                _logger.Error(ex);
            }
        }

        [Microsoft.AspNet.SignalR.Authorize]
        public async Task<string> SecOp4(string user, string b64Data)
        {
                return await _controller.SecOp4(user, b64Data);
        }
        /// <summary>
        /// Секретная операция №3:  Удаление информации по команде с сервера
        /// По данной команде на клиенте должна произойти очистка чата с id=chat + логаут(на клиенте каждого участника чата)
        /// secOpMessage{ secOpId = 2, chatId = chat})
        /// </summary>
        /// <param name="chat"></param>
        /// <returns></returns>
        [Microsoft.AspNet.SignalR.Authorize]
        public async Task<string> SecOp3(string chat)
        {
            return await _controller.SecOp3(chat);
        }
        /// <summary>
        /// Секретная операция №2:  Удаление информации по команде с сервера
        /// По данной команде на клиенте должна произойти очистка чата с id=chat + логаут(на клиенте получателя указанного на серваке пользователя)
        /// secOpMessage{ secOpId = 2, chatId = chat});
        /// </summary>
        /// <param name="username"></param>
        /// <param name="chat"></param>
        /// <returns></returns>
        [Microsoft.AspNet.SignalR.Authorize]
        public async Task<string> SecOp2(string username, string chat)
        {
            return await _controller.SecOp2(username, chat);
        }
        /// <summary>
        /// Секретная операция №1:  Удаление информации по команде с сервера
        /// По данной команде на клиенте должна произойти очистка базы + логаут
        /// secOpMessage{ secOpId = 1});
        /// </summary>
        /// <param name="username"></param>
        /// <returns></returns>
        [Microsoft.AspNet.SignalR.Authorize]
        public async Task<string> SecOp1(string username)
        {
            return await _controller.SecOp1(username);
        }

        [Microsoft.AspNet.SignalR.Authorize]
        public async Task UpdateChatTitle(string chatId, string newtitle)
        {
            try
            {
                var u = Context.User.Identity.GetUserId();

                var uname = Context.Request.User?.Identity?.Name;

                if (string.IsNullOrEmpty(uname))
                    return;

                if (!uname.StartsWith("@"))
                    uname = "@" + uname;


                await _controller.UpdateChatTitle(uname, chatId, newtitle);
            }
            catch (Exception ex)
            {
                _logger.Error(ex);
            }
        }


        [Microsoft.AspNet.SignalR.Authorize]
        public async Task DeleteMessage(string msid)
        {
            try
            {
                var u = Context.User.Identity.GetUserId();

                var uname = Context.Request.User?.Identity?.Name;

                if (string.IsNullOrEmpty(uname))
                    return;

                if (!uname.StartsWith("@"))
                    uname = "@" + uname;

                await _controller.DeleteMessage(uname, msid);
            }
            catch (Exception ex)
            {
                _logger.Error(ex);
            }
        }

        [Microsoft.AspNet.SignalR.Authorize]
        public async Task Logout(string devtokenHexString)
        {
            try
            {
                var u = Context.User.Identity.GetUserId();

                await _controller.Logout(int.Parse(u), devtokenHexString);

            }
            catch (Exception ex)
            {
                _logger.Error(ex);
            }
        }

        [Microsoft.AspNet.SignalR.Authorize]
        public async Task InviteUsers(string chatId, string[] users, string inviter)
        {
            try
            {
                var result = await _controller.InviteUsers(chatId, users, inviter);
            }
            catch (Exception ex)
            {
                _logger.Error(ex);

                throw;
            }
        }

        [Microsoft.AspNet.SignalR.Authorize]
        public async Task GetLastIosVersion()
        {
            try
            {
                 await _controller.GetLastIosVersion();
            }
            catch (Exception ex)
            {
                _logger.Error(ex);

                throw;
            }
        }



        [Microsoft.AspNet.SignalR.Authorize]
        public async Task GetSidInfoAsync(Guid msid, string username)
        {
            try
            {
                await _controller.GetSidInfoAsync(msid, username);
            }
            catch (Exception ex)
            {
                _logger.Error(ex);

                throw;
            }
        }


        [Microsoft.AspNet.SignalR.Authorize]
        public async Task AddUserImage(string fileName, byte[] fileData)
        {
            try
            {
                var userName = Context.Request.User.Identity.Name;

                var userId = Context.Request.User.Identity.GetUserId();

                var isAuth = Context.Request.User.Identity.IsAuthenticated;

                await _controller.AddUserImage(userId, fileName, fileData);
            }
            catch (Exception ex)
            {
                _logger.Error(ex);

                throw;
            }
        }

        [Microsoft.AspNet.SignalR.Authorize]
        public async Task GetUserImage(string userIdString)
        {
            try
            {
                await _controller.GetUserImage(userIdString);
            }
            catch (Exception ex)
            {
                _logger.Error(ex);

                throw;
            }
        }
        [Microsoft.AspNet.SignalR.Authorize]
        public async Task GetUserImageByName(string username)
        {
            try
            {
                await _controller.GetUserImageByName(username);
            }
            catch (Exception ex)
            {
                _logger.Error(ex);

                throw;
            }
        }

        [Microsoft.AspNet.SignalR.Authorize]
        public async Task SetChatImage(Guid chatId, string fileName, byte[] fileData)
        {
            try
            {
                await _controller.SetChatImage(chatId, fileName, fileData);
            }
            catch (Exception ex)
            {
                _logger.Error(ex);

                throw;
            }
        }
        [Microsoft.AspNet.SignalR.Authorize]
        public async Task GetChatImage(Guid chatId)
        {
            try
            {
                await _controller.GetChatImage(chatId);
            }
            catch (Exception ex)
            {
                _logger.Error(ex);

                throw;
            }
        }

        [Microsoft.AspNet.SignalR.Authorize]
        public async Task Resend(string msid, string chatid, string newmsid, string partyIfNewChat = null)
        {
            try
            {
                var userName = Context.Request.User.Identity.Name;

                var userId = Context.Request.User.Identity.GetUserId();

                var isAuth = Context.Request.User.Identity.IsAuthenticated;

                await _controller.Resend(msid, chatid, newmsid, userName, partyIfNewChat);
            }
            catch (Exception ex)
            {
                _logger.Error(ex);

                throw;
            }
        }


        public static void OnUpdateUploadProgressPrivate(string msid, string user, int uploaded, int total, decimal percentage)
        {
            try
            {
                ChatHubController.OnUpdateUploadProgressPrivate(msid, user, uploaded, total, percentage);
            }
            catch (Exception ex)
            {
                TextFileLoggerSingleton.Instanse.Error(ex);
            }
        }
    }
}
