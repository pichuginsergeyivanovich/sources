using System;
using System.Threading.Tasks;
using NNK.Messenger.Core;

namespace NNK.Messenger.SignalR.Hubs
{
    public interface IChatHub
    {
        Task Upload(string user);
        ChatHubController GetController();
        Task GetUserChatMessages(string user, string chat, string msgChkSum = null);

        Task GetUserChatList(string user);
       
        Task Operation(string id, string method, string data);

        Task ConfirmOperation(string id, string code);

        Task Validate(string pair);

        Task<bool> Ping();
        
        Task Token(string username, string password);

        Task Send(ChatMessage message);

        Task GetAllMessages(string user, string timeLabel = null, string msgChkSum = null);

        Task GetAllChats(string user, string timeLabel = null);

        Task GetAllParty(string user, string timeLabel = null);

        Task GetAllUsers(string timeLabel = null);

        Task OnConnected();

        Task OnDisconnected(bool stopCalled);

        Task GetConfirmSecret(string operationId);

        Task KillChat(Guid? chatId);

        Task InviteUser(string chatId, string user, string inviter);

        Task GetUserInvites(string user);

        Task AcceptInvite(string inviteId);

        Task RejectInvite(string inviteId);

        Task DeleteInvite(string inviteId);

        Task SendMetadata(Guid msid, string meta);

        Task LeaveChat(Guid? chatId, string user);

        Task CreateGroupChat(string[] selected, string title, string user);

        TransferInfo OpenFileTransferSession(string sidStr, string text, string fileName, ulong size, string type);

        Task CloseFileTransferSession(string msid, string text, string chatId);

        void TransferFilePart(string sidStr, string fileName, ulong size, string partIndexStr, string bytesStr, string chatIdStr);

        Task AskForMainQuestionOfLifeUniverseAndEtc();

        Task SendE(ChatMessage message);

        Task SendMessageNotification(string sid, DateTime clientDate, string clientDescr);


        Task SendMessageNotification2(string sid, DateTime clientDate, string clientDescr);

        Task SendMessageNotification3(string chatid, DateTime clientDate, string clientDescr);

        Task CreateSecretGroupChat(string[] selected, string title, string user, string passwordb64 = null, bool hidden = false);

        Task ValidateSecretChat(Guid? chatId, string passwordb64);

        Task RegisterUserKeys(string b64PublicKeys, bool forceRegister = false);

        Task GetUserKeys(string user);

        Task Resend(string msid, string chatid, string newmsid, string partyIfNewChat = null);

    }
}