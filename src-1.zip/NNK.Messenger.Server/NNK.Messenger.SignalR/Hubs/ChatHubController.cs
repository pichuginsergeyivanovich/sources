﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net.Http;
using System.Security.Cryptography;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using Microsoft.AspNet.Identity;
using Microsoft.AspNet.SignalR;
using Microsoft.AspNet.SignalR.Hubs;
using Microsoft.Exchange.WebServices.Data;
using Microsoft.Owin;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using NNK.Beeline.Services.Business.Providers;
using NNK.Beeline.Services.Business.Services;
using NNK.Beeline.Services.Data;
using NNK.Messenger.AspNetIdentity;
using NNK.Messenger.Business;
using NNK.Messenger.Business.Redis;
using NNK.Messenger.Core;
using NNK.Messenger.Data;
using NNK.Messenger.SignalR.Helpers;
using NNK.Messenger.SignalR.Models;
using NNK.RabbitMQ.Core;
using Task = System.Threading.Tasks.Task;

namespace NNK.Messenger.SignalR.Hubs
{
    public class ChatHubController { 
        private readonly NNK.Logging.ILogger _logger;
        private readonly ICryptoOperations _crops;
        private readonly IAttachmentOperations _aops;
        private readonly IFileStoreOperations _fops;
        private readonly INotificationOperations _nops;
        private readonly IPartyOperations _pops;
        private readonly IChatOperations _cops;
        private readonly IAttachMetadataOperations _amops;
        private readonly IMessageOperations _mops;
        private readonly IUserOperations _uops;
        private readonly IOwinContext _context;
        private readonly IOperationsOperations _oops;
        private readonly IInviteOperations _iops;
        private readonly UserManager<User, int> _userManager;
        private readonly ISmsServiceOperations _smsServiceOps;
        private readonly IExchangeServiceProvider _exchangeProvider;
        private readonly ChatUsersHelper _chatUsersHelper;
        private readonly IIdentityOperations _idops;
        private readonly NNK.RabbitMQ.Core.RabbitMqConnectionFactoryProvider _rcfp;
        private readonly IProfileOperations _props;
        private readonly IChangelogOperations _clops;
        private Func<IHubCallerConnectionContext<dynamic>> _getclients;
        private Func<HubCallerContext> _gethubcontext;
        private readonly string _tokenUrl;
        RabbitMqClient _rc;


        public ChatHubController(
            string tokenUrl,
            NNK.Logging.ILogger logger,
            ICryptoOperations crops,
            IAttachmentOperations aops,
            IFileStoreOperations fops,
            INotificationOperations nops,
            IPartyOperations pops,
            IChatOperations cops, 
            IAttachMetadataOperations amops, 
            IMessageOperations mops, 
            IUserOperations uops,
            IOwinContext context,
            IOperationsOperations oops,
            IInviteOperations iops,
            UserManager<User, int> userManager,
            ISmsServiceOperations smsServiceOps,
            IExchangeServiceProvider exchangeProvider,
            ChatUsersHelper chatUsersHelper,
            IIdentityOperations idops,
            PushOperations puops,
            NNK.RabbitMQ.Core.RabbitMqConnectionFactoryProvider rcfp,
            IProfileOperations props,
            IChangelogOperations clops
            ){

            _logger = logger;
            _crops = crops;
            _aops = aops;
            _fops = fops;
            _nops = nops;
            _pops = pops;
            _cops = cops;
            _amops = amops;
            _mops = mops;
            _uops = uops;
            _context = context;
            _oops = oops;
            _iops = iops;
            _userManager = userManager;
            _smsServiceOps = smsServiceOps;
            _exchangeProvider = exchangeProvider;
            _chatUsersHelper = chatUsersHelper;
            _idops = idops;
            _tokenUrl = tokenUrl;
            _rcfp = rcfp;
            _props = props;
            _clops = clops;
        }
        HubCallerContext _hubcontext => _gethubcontext();
        IHubCallerConnectionContext<dynamic> _clients => _getclients();
        public void SetupHubCallerContext(Func<HubCallerContext> gethubcontext)
        {
            _gethubcontext = gethubcontext;
        }
        public void SetupHubCallerConnectionContext(Func<IHubCallerConnectionContext<dynamic>> getclients)
        {
            _getclients = getclients;
        }
        async Task ResetUserPassword(string user)
        {

           // var u = _uops.GetByName(user);

              _uops.ResetUserPassword(user);


        }
        static Dictionary<string, int>_loginRetries=new Dictionary<string, int>();
        public async Task<string> Token(string username, string password)
        {
            _logger.Message($"Token for user: {username}");

            var client = new HttpClient();

            client.DefaultRequestHeaders.Add("Accept", "application/json");

            var dict = new Dictionary<string, string>
                {
                    {"grant_type", "password"},
                    {"username", username},
                    {"password", password}
                };

            HttpContent body = new FormUrlEncodedContent(dict);

            var response = client.PostAsync(new Uri(_tokenUrl), body);

            var jwt = response.Result.Content.ReadAsStringAsync().Result;


            if (jwt.Contains("error") && jwt.Contains("invalid_grant") && jwt.Contains("The user name or password is incorrect."))
            {
                if (_loginRetries.ContainsKey(username))
                {
                    var tries = _loginRetries[username];

                    tries++;

                    _loginRetries[username] = tries;

                    _logger.Message($"login failed tries: {username}, {tries}");


                    if (tries >= 5)
                    {
                        await ResetUserPassword(username);

                        _logger.Message($"reset user password: {username}");
                    }
                }
                else
                    _loginRetries[username] = 1;
            }
            else
            {
                _loginRetries[username] = 0;

                _logger.Message($"login tries cleared: {username}");
            }

            await _clients.Caller.getToken(jwt);

            return jwt;
        }

        private readonly object _locker=new object();

        public void OnConnected(string userName, string userId, bool isAuth)
        {

            lock (_locker)
            {
                if (_hubcontext == null)
                {
                    _logger.Message($"OnConnected/OnREConnected: _hubcontext is null");

                    return;
                }

                var cu = _chatUsersHelper.OnConnected(userName, userId, isAuth, _hubcontext.ConnectionId);

                _logger.Message($"new/re connection from user: {cu.Name}, {cu.ConnectionId}");

                _clients.Caller.onConnected(
                    new { connectionId = _hubcontext.ConnectionId, userName = userName });

                _clients.AllExcept(_hubcontext.ConnectionId)
                    .onUserConnected(new { connectionId = _hubcontext.ConnectionId, userName = userName });
            }
        }
        public void OnConnected()
        {

            lock (_locker)
            {
                if (_hubcontext == null)
                {
                    _logger.Message($"OnConnected: _hubcontext is null");

                    return;
                }

                var userName = GetUsernameFromContext();

                var userId = _context.Request.User.Identity.GetUserId();

                var isAuth = _context.Request.User.Identity.IsAuthenticated;

                var cu = _chatUsersHelper.OnConnected(userName, userId, isAuth, _hubcontext.ConnectionId);

                _logger.Message($"new connection from user: {cu.Name}, {cu.ConnectionId}");

                _clients.Caller.onConnected(new {connectionId = _hubcontext.ConnectionId, userName = userName});

                _clients.AllExcept(_hubcontext.ConnectionId).onUserConnected(new {connectionId = _hubcontext.ConnectionId, userName = userName});
            }
        }
        public void OnDisconnected()
        {
            lock (_locker)
            {
                try
                {
                    var item=_chatUsersHelper.OnDisconnected(_hubcontext.ConnectionId);

                    _logger.Message($"user disconnected: {item?.Name},{item?.ConnectionId}");

                    _clients.AllExcept(_hubcontext.ConnectionId).onUserDisconnected(new { connectionId = _hubcontext.ConnectionId, username = item?.Name});

                }
                catch (Exception e)
                {
                    _logger.Error(e);
                }
            }
        }
        string[] GetPartyFromChatMessage(ChatMessage message)
        {
            return GetPartyFromChat(_cops, message.ChatId, message.Party);
        }
        static string[] GetPartyFromChat(IChatOperations cops, string chatId, string partyIfNewChat=null)
        {
            var party = new List<string>();

            if (chatId.StartsWith("new") || chatId == null || !cops.Exist(Guid.Parse(chatId)))
            {
                party =
                    partyIfNewChat.Split(new[] { "," }, StringSplitOptions.RemoveEmptyEntries)
                        .Select(i => i.Trim())
                        .ToList();
            }
            else
            {
                party = (cops.GetChatParty(Guid.Parse(chatId))).ToList();
            }

            party.Remove("empty");

            return party.Distinct().ToArray();
        }
        public async Task<ChatHubControllerSendResult> Send(ChatMessage message)
        {
            var result = new ChatHubControllerSendResult();

            var party = GetPartyFromChatMessage(message);

            message.Party = string.Join(",", party);

            _logger.Message($"call hub Send from: {message.User} with sid:{message.SID}, party: {message.Party}");

            result.IsNewChat = (message.ChatId.StartsWith("new") || message.ChatId == null);

            if (!result.IsNewChat)
            {
                //var c = await _cops.GetAsync(Guid.Parse(message.ChatId));
                var c = _cops.Get(Guid.Parse(message.ChatId));

                if (c == null)
                {
                    result.IsError = true;

                    throw new ApplicationException($"Chat {Guid.Parse(message.ChatId)} does not exist");
                }
            }


            //byte[] iv = new byte[0];

            //var encrypt = EncryptDataString(ServerSideKeyHelper.Instance.PublicKey, message.Message, out iv);




            var dbMessage = new ChatControllerProxy(_cops,_mops).PostMessage2(message.User, message.Message, message.Party, message.ChatId, message.Created.ToUniversalTime(), message.SID);

            //var pops = new PartyOperations();

            _pops.LinkPartyToChat(party.Distinct().ToArray(), dbMessage.ChatID);

            var connectedParty = _chatUsersHelper.GetConnectedParty(party);

            var connectedPartyIds = connectedParty.Select(i => i.ConnectionId).ToArray();

            result.connectedPartyIds = connectedPartyIds;

            

            var newMessage = _mops.AsFullChatMessage(dbMessage, _amops.GetMetadata(dbMessage.ID));

            result.ChatId = dbMessage.ChatID;

            result.Message = newMessage;

            foreach (var u in connectedParty)
            {
                _logger.Message($"call addMessage to user-{u.Name}, connectionId: {u.ConnectionId}, sid:{newMessage.SID}");
            }


            if (result.IsNewChat)
                await _clients.Clients(result.connectedPartyIds).onNewChatCreated(result.ChatId);

            await _clients.Clients(result.connectedPartyIds).addMessage(result.Message);

            return result;
        }
        byte[] RSAEncrypt(byte[] DataToEncrypt, RSAParameters RSAKeyInfo, bool DoOAEPPadding)
        {
            try
            {
                byte[] encryptedData;
                using (RSACryptoServiceProvider RSA = new RSACryptoServiceProvider())
                {

                    RSA.ImportParameters(RSAKeyInfo);

                    encryptedData = RSA.Encrypt(DataToEncrypt, DoOAEPPadding);
                }
                return encryptedData;
            }
            catch (CryptographicException e)
            {
                Console.WriteLine(e.Message);

                return null;
            }

        }
        public async Task AskForMainQuestionOfLifeUniverseAndEtc(string userId)
        {

            if (string.IsNullOrEmpty(userId))
                return;


            var userIdentity = _idops.Get(int.Parse(userId));

            using (var rsa = new RSACryptoServiceProvider(1024))
            {

                _logger.Message($"user key: {Convert.ToBase64String(userIdentity.IdentityKey)}, userId:{userId}");

                rsa.FromXmlString($"<RSAKeyValue><Modulus>{Convert.ToBase64String(userIdentity.IdentityKey)}</Modulus><Exponent>AQAB</Exponent></RSAKeyValue>");

                var pub = rsa.ExportParameters(false);

                var encrypted = rsa.Encrypt(Encoding.UTF8.GetBytes(ServerSideKeyHelper.Instance.PublicKeyAsString),false);

                var encryptedb64 = Convert.ToBase64String(encrypted);

                _logger.Message("rsa encrypted: " + encryptedb64);
                _logger.Message("rsa encrypted bytes: " + string.Join(",", encrypted));
                _logger.Message("rsa encrypted len: " + encrypted.Length);

                await _clients.Caller.answerForMainQuestionOfLifeUniverseAndEtc(encryptedb64);

                return;
            }
        }
        private string encryptString(string src)
        {
            byte[] iv = new byte[16];

            var key = ServerSideKeyHelper.Instance.PublicKey;

            var encrypted = _crops.EncryptDataString(key, src, out iv);

            var res = new byte[encrypted.Length + 16];

            Buffer.BlockCopy(encrypted, 0, res, 0, encrypted.Length);

            Buffer.BlockCopy(iv, 0, res, encrypted.Length, 16);

            var encryptedb64 = Convert.ToBase64String(res);

            return encryptedb64;
        }
        public async Task E1Send(ChatMessage message)
        {
            _logger.Message($"call hub Send from: {message.User} with sid:{message.SID}, party: {message.Party}");

            Chat chat = null;

            if (message.IsNewChat)
            {
                chat = _cops.GetChatFromParty(message.Party, message.User) ?? CreateChatFromMessage(message);


                    var res = new { chat.ID, chat.Author, chat.Created, chat.IsHidden, chat.Modified, chat.Party, chat.Title, chat.IsGroup };

                    var connectedParty0 = _chatUsersHelper.GetConnectedParty(chat.PartyAsArray());

                    var connectedPartyIds0 = connectedParty0.Select(i => i.ConnectionId).ToArray();

                    await _clients.Clients(connectedPartyIds0).onNewChatCreated(res);
             
            }
            else
            {
                chat = _cops.Get(Guid.Parse(message.ChatId));
            }

            _pops.LinkPartyToChat(chat.PartyAsArray(), chat.ID);

            var encryptedb64 = encryptString(message.Message);

            _logger.Message("encryptedb64(enc+iv): " + encryptedb64);

            var dbMessage = _mops.AddMessage(Guid.Parse(message.ChatId), message.User, encryptedb64, DateTime.UtcNow);

            var newMessage = _mops.AsFullChatMessage(dbMessage, _amops.GetMetadata(dbMessage.ID));

            //prepare connected clients connections

            var connectedParty = _chatUsersHelper.GetConnectedParty(chat.PartyAsArray());

            var connectedPartyIds = connectedParty.Select(i => i.ConnectionId).ToArray();

            foreach (var u in connectedParty)
            {
                _logger.Message($"call addMessage to user-{u.Name}, connectionId: {u.ConnectionId}, sid:{newMessage.SID}");
            }

            await _clients.Clients(connectedPartyIds).addMessage(newMessage);


        }
        public async Task SendE1(ChatMessage message)
        {
            _logger.Message($"call hub Send from: {message.User} with sid:{message.SID}, party: {message.Party}");

            var chat = message.IsNewChat ? CreateChatFromMessage(message) : _cops.Get(Guid.Parse(message.ChatId));

            _pops.LinkPartyToChat(chat.PartyAsArray(), chat.ID);
            
            var encryptedb64 = encryptString(message.Message);

            _logger.Message("encryptedb64(enc+iv): " + encryptedb64);

            var dbMessage = _mops.AddMessage(Guid.Parse(message.ChatId), message.User, encryptedb64, DateTime.UtcNow);

            var newMessage = _mops.AsFullChatMessage(dbMessage, _amops.GetMetadata(dbMessage.ID));

            //prepare connected clients connections

            var connectedParty = _chatUsersHelper.GetConnectedParty(chat.PartyAsArray());

            var connectedPartyIds = connectedParty.Select(i => i.ConnectionId).ToArray();

            foreach (var u in connectedParty)
            {
                _logger.Message($"call addMessage to user-{u.Name}, connectionId: {u.ConnectionId}, sid:{newMessage.SID}");
            }

            if (message.IsNewChat)
            {
                //newchat clients callback

                var res = new { chat.ID, chat.Author, chat.Created, chat.IsHidden, chat.Modified, chat.Party, chat.Title, chat.IsGroup };

                await _clients.Clients(connectedPartyIds).onNewChatCreated(res);
            }
            
            //send message clients callback

            await _clients.Clients(connectedPartyIds).addMessage(newMessage);


            //add task to push service

            if (_rc == null)
                _rc = new RabbitMqClient(_rcfp, _logger);

            if (chat.IsHidden==false)
                _rc.AddTask(new AddMessagePushTask(message.User, message.ChatId));
        }
        private Chat CreateChatFromParams(string chatIdString, string partyString, string userString, bool isNewChatHidden=false)
        {
            Guid chatId;

            if (!Guid.TryParse(chatIdString, out chatId))
                throw new ApplicationException("Error. ChatId in message is not Guid.");

            var partyList =
                partyString.Split(new[] { "," }, StringSplitOptions.RemoveEmptyEntries)
                    .Select(i => i.Trim())
                    .ToList();

            partyList.Remove("empty");

            if (!partyList.Contains(userString))
                partyList.Add(userString);

            var party = partyList.Distinct().ToList();

            var list = party.ToList();

            list.Remove(userString);


            var c = new Chat
            {
                ID = Guid.Parse(chatIdString),
                Author = userString,
                Created = DateTime.UtcNow,
                Party = string.Join(",", party),
                Title = string.Join(",", list),
                IsHidden = isNewChatHidden
            };

            var chat = _cops.CreateChat(c, c.ID);

            return chat;
        }
        private Chat CreateChatFromMessage(ChatMessage message)
        {
            Guid chatId;

            if (!Guid.TryParse(message.ChatId, out chatId))
                throw new ApplicationException("Error. ChatId in message is not Guid.");

            var partyList =
                message.Party.Split(new[] {","}, StringSplitOptions.RemoveEmptyEntries)
                    .Select(i => i.Trim())
                    .ToList();

            partyList.Remove("empty");

            if (!partyList.Contains(message.User))
                partyList.Add(message.User);

            var party = partyList.Distinct().ToList();

            var list = party.ToList();

            list.Remove(message.User);


            var c = new Chat
            {
                ID = Guid.Parse(message.ChatId),
                Author = message.User,
                Created = DateTime.UtcNow,
                Party = string.Join(",", party),
                Title = string.Join(",", list),
                IsHidden = message.IsNewChatHidden ?? false
            };

            var chat = _cops.CreateChat(c,c.ID);

            return chat;
        }
        public async Task<ChatHubControllerSendResult> SendE(ChatMessage message)
        {
            var result = new ChatHubControllerSendResult();

            bool isChatHidden = false;

            var original = message.Message;

            var party = GetPartyFromChatMessage(message);

            message.Party = string.Join(",", party);

            _logger.Message($"call hub Send from: {message.User} with sid:{message.SID}, party: {message.Party}");

            result.IsNewChat = (message.ChatId.StartsWith("new") || message.ChatId == null)|| message.IsNewChat;

            if (!result.IsNewChat)
            {
                var c = _cops.Get(Guid.Parse(message.ChatId));

                if (c == null)
                {
                    result.IsError = true;

                    throw new ApplicationException($"Chat {Guid.Parse(message.ChatId)} does not exist");
                }
                else
                {
                    isChatHidden = c.IsHidden??false;
                }
            }
            else if (message.NewChatId == Guid.Empty)
                message.NewChatId = Guid.NewGuid();
            //var d = new Dictionary<string, object>();

                //var idops = new IdentityOperations();

            var author =  _uops.GetByName(message.User);

            var author_identity =  _idops.Get(author.UserID);

            byte[] iv = new byte[16];

            //RNGCryptoServiceProvider.Create().GetBytes(salt);

            //var key = new Rfc2898DeriveBytes(ServerSideKeyHelper.Instance.PublicKey, salt, 1000);

            //var iv = key.GetBytes(16);

            //var secret = key.GetBytes(32);

            var key = ServerSideKeyHelper.Instance.PublicKey;
            _logger.Message("key: " + Convert.ToBase64String(key));

            //var key = author_identity.IdentityKey;
            var encrypted = _crops.EncryptDataString(key, message.Message, out iv);

            //_logger.Message("server pri: " + Convert.ToBase64String(ServerSideKeyHelper.Instance.PrivateKey));
            _logger.Message("encrypted: "+Convert.ToBase64String(encrypted));
            //_logger.Message("sec: " + Convert.ToBase64String(secret));
            _logger.Message("iv: " + Convert.ToBase64String(iv));


            var res = new byte[encrypted.Length + 16];

            Buffer.BlockCopy(encrypted, 0, res, 0, encrypted.Length);
            Buffer.BlockCopy(iv, 0, res, encrypted.Length, 16);

            var encryptedb64 = Convert.ToBase64String(res);
            _logger.Message("encryptedb64(enc+iv): " + encryptedb64);

            message.Message = encryptedb64;


            //foreach (var p in party.Distinct().ToArray())
            //{
            //    var u = await _uops.GetByNameAsync(p);

            //    var uid = await idops.GetAsync(u.Id);

            //    byte[] iv = new byte[0];

            //    var encrypted = EncryptDataString(uid.IdentityKey, message.Message, out iv);

            //    var ucm = new ChatMessage(message.User, Convert.ToBase64String(encrypted), message.Party, message.ChatId);

            //    ucm.IV = Convert.ToBase64String(iv);

            //    d.Add(p, ucm);
            //}

            //var encryptedSoul = EncryptDataString(ServerSideKeyHelper.Instance.PublicKey, message.Message, out iv);

            message.Created = DateTime.UtcNow;

            //var dbMessage = await new ChatControllerProxy(_cops,_mops).PostMessageAsync2(message.User, message.Message, message.Party, message.ChatId, message.Created, message.SID);
            var dbMessage = new ChatControllerProxy(_cops, _mops).PostMessage2(message.User, message.Message, message.Party, message.ChatId, message.Created, message.SID, message.NewChatId);



            //var pops = new PartyOperations();

            _pops.LinkPartyToChat(party.Distinct().ToArray(), dbMessage.ChatID);

            var connectedParty = _chatUsersHelper.GetConnectedParty(party);

            var connectedPartyIds = connectedParty.Select(i => i.ConnectionId).ToArray();

            result.connectedPartyIds = connectedPartyIds;

            var newMessage = _mops.AsFullChatMessage(dbMessage, _amops.GetMetadata(dbMessage.ID));

            result.ChatId = dbMessage.ChatID;

            result.Message = newMessage;

            //result.Message.Message = original;

            foreach (var u in connectedParty)
            {
                _logger.Message($"call addMessage to user-{u.Name}, connectionId: {u.ConnectionId}, sid:{newMessage.SID}");
            }

            if (result.IsNewChat)
            {
                var rc = _cops.Get(result.ChatId);


                var res1 = new { rc.ID, rc.Author, rc.Created, rc.IsHidden, rc.Modified, rc.Party, rc.Title, rc.IsGroup };

                await _clients.Clients(result.connectedPartyIds).onNewChatCreated(res1);


                //var partyStrong = string.Join(",", party.Where(i => i != message.User).ToArray());

                //var text = encryptString($"Пользователь {message.User} создал новый чат с {partyStrong}");

                //var sysMessage = _mops.CreateCustomChatMessage(dbMessage.ChatID, message.User, text);

                //await _clients.Clients(result.connectedPartyIds).addMessage(sysMessage);
            }
            await _clients.Clients(result.connectedPartyIds).addMessage(result.Message);

            
            //add task to push service

            if(_rc==null)
                _rc=new RabbitMqClient(_rcfp, _logger);

            if (!isChatHidden)
                _rc.AddTask(new AddMessagePushTask(message.User, message.ChatId));
      
            return result;
        }
        /// <summary>
        /// SendE c поддержкой флага IsPlain для пушей
        /// </summary>
        /// <param name="message"></param>
        /// <returns></returns>
        public async Task<ChatHubControllerSendResult> SendE_(ChatMessage message)
        {
            var result = new ChatHubControllerSendResult();

            bool isChatHidden = false;

            var original = message.Message;

            var party = GetPartyFromChatMessage(message);

            message.Party = string.Join(",", party);

            _logger.Message($"call hub Send from: {message.User} with sid:{message.SID}, party: {message.Party}");

            result.IsNewChat = (message.ChatId.StartsWith("new") || message.ChatId == null) || message.IsNewChat;

            if (!result.IsNewChat)
            {
                var c = _cops.Get(Guid.Parse(message.ChatId));

                if (c == null)
                {
                    result.IsError = true;

                    throw new ApplicationException($"Chat {Guid.Parse(message.ChatId)} does not exist");
                }
                else
                {
                    isChatHidden = c.IsHidden ?? false;
                }
            }
            else if (message.NewChatId == Guid.Empty)
                message.NewChatId = Guid.NewGuid();
            //var d = new Dictionary<string, object>();

            //var idops = new IdentityOperations();

            var author = _uops.GetByName(message.User);

            var author_identity = _idops.Get(author.UserID);

            byte[] iv = new byte[16];

            //RNGCryptoServiceProvider.Create().GetBytes(salt);

            //var key = new Rfc2898DeriveBytes(ServerSideKeyHelper.Instance.PublicKey, salt, 1000);

            //var iv = key.GetBytes(16);

            //var secret = key.GetBytes(32);

            var key = ServerSideKeyHelper.Instance.PublicKey;
            _logger.Message("key: " + Convert.ToBase64String(key));

            //var key = author_identity.IdentityKey;
            var encrypted = _crops.EncryptDataString(key, message.Message, out iv);

            //_logger.Message("server pri: " + Convert.ToBase64String(ServerSideKeyHelper.Instance.PrivateKey));
            _logger.Message("encrypted: " + Convert.ToBase64String(encrypted));
            //_logger.Message("sec: " + Convert.ToBase64String(secret));
            _logger.Message("iv: " + Convert.ToBase64String(iv));


            var res = new byte[encrypted.Length + 16];

            Buffer.BlockCopy(encrypted, 0, res, 0, encrypted.Length);
            Buffer.BlockCopy(iv, 0, res, encrypted.Length, 16);

            var encryptedb64 = Convert.ToBase64String(res);
            _logger.Message("encryptedb64(enc+iv): " + encryptedb64);

            message.Message = encryptedb64;


            //foreach (var p in party.Distinct().ToArray())
            //{
            //    var u = await _uops.GetByNameAsync(p);

            //    var uid = await idops.GetAsync(u.Id);

            //    byte[] iv = new byte[0];

            //    var encrypted = EncryptDataString(uid.IdentityKey, message.Message, out iv);

            //    var ucm = new ChatMessage(message.User, Convert.ToBase64String(encrypted), message.Party, message.ChatId);

            //    ucm.IV = Convert.ToBase64String(iv);

            //    d.Add(p, ucm);
            //}

            //var encryptedSoul = EncryptDataString(ServerSideKeyHelper.Instance.PublicKey, message.Message, out iv);

            message.Created = DateTime.UtcNow;

            //var dbMessage = await new ChatControllerProxy(_cops,_mops).PostMessageAsync2(message.User, message.Message, message.Party, message.ChatId, message.Created, message.SID);
            var dbMessage = new ChatControllerProxy(_cops, _mops).PostMessage2(message.User, message.Message, message.Party, message.ChatId, message.Created, message.SID, message.NewChatId);



            //var pops = new PartyOperations();

            _pops.LinkPartyToChat(party.Distinct().ToArray(), dbMessage.ChatID);

            var connectedParty = _chatUsersHelper.GetConnectedParty(party);

            var connectedPartyIds = connectedParty.Select(i => i.ConnectionId).ToArray();

            result.connectedPartyIds = connectedPartyIds;

            var newMessage = _mops.AsFullChatMessage(dbMessage, _amops.GetMetadata(dbMessage.ID));

            result.ChatId = dbMessage.ChatID;

            result.Message = newMessage;

            //result.Message.Message = original;

            foreach (var u in connectedParty)
            {
                _logger.Message($"call addMessage to user-{u.Name}, connectionId: {u.ConnectionId}, sid:{newMessage.SID}");
            }

            if (result.IsNewChat)
            {
                var rc = _cops.Get(result.ChatId);


                var res1 = new { rc.ID, rc.Author, rc.Created, rc.IsHidden, rc.Modified, rc.Party, rc.Title, rc.IsGroup };

                await _clients.Clients(result.connectedPartyIds).onNewChatCreated(res1);


                //var partyStrong = string.Join(",", party.Where(i => i != message.User).ToArray());

                //var text = encryptString($"Пользователь {message.User} создал новый чат с {partyStrong}");

                //var sysMessage = _mops.CreateCustomChatMessage(dbMessage.ChatID, message.User, text);

                //await _clients.Clients(result.connectedPartyIds).addMessage(sysMessage);
            }
            await _clients.Clients(result.connectedPartyIds).addMessage(result.Message);


            //add task to push service

            if (_rc == null)
                _rc = new RabbitMqClient(_rcfp, _logger);

            if (!isChatHidden)
            {
                if(message.IsPlain??false)
                    _rc.AddTask(new AddMessagePushTask2(message.User, message.ChatId, original));
                else
                    _rc.AddTask(new AddMessagePushTask(message.User, message.ChatId));

            }

            return result;
        }
        public async Task<ChatHubControllerSendResult> SendE2(ChatMessage message)
        {
            var result = new ChatHubControllerSendResult();

            var original = message.Message;

            var party = GetPartyFromChatMessage(message);

            message.Party = string.Join(",", party);

            _logger.Message($"call hub Send from: {message.User} with sid:{message.SID}, party: {message.Party}");

            result.IsNewChat = (message.ChatId.StartsWith("new") || message.ChatId == null);

            if (!result.IsNewChat)
            {
                var c = _cops.Get(Guid.Parse(message.ChatId));

                if (c == null)
                {
                    result.IsError = true;

                    throw new ApplicationException($"Chat {Guid.Parse(message.ChatId)} does not exist");
                }
            }

            //var d = new Dictionary<string, object>();

            //var idops = new IdentityOperations();

            var author =  _uops.GetByName(message.User);

            var author_identity =  _idops.Get(author.UserID);

            byte[] iv = new byte[16];

            //RNGCryptoServiceProvider.Create().GetBytes(salt);

            //var key = new Rfc2898DeriveBytes(ServerSideKeyHelper.Instance.PublicKey, salt, 1000);

            //var iv = key.GetBytes(16);

            //var secret = key.GetBytes(32);
            var key = ServerSideKeyHelper.Instance.PublicKey;
            _logger.Message("key: " + Convert.ToBase64String(key));

            //var key = author_identity.IdentityKey;
            var encrypted = _crops.EncryptDataString(key, message.Message, out iv);

            //_logger.Message("server pri: " + Convert.ToBase64String(ServerSideKeyHelper.Instance.PrivateKey));
            _logger.Message("encrypted: " + Convert.ToBase64String(encrypted));
            //_logger.Message("sec: " + Convert.ToBase64String(secret));
            _logger.Message("iv: " + Convert.ToBase64String(iv));


            //TODO: here key must be hashed and hash must be added at the end of the outgoing encrypted message bytes before encode to base64

            var ha = new MD5Cng();

            var keyhash = ha.ComputeHash(key);

            var res = new byte[encrypted.Length + iv.Length + keyhash.Length];

            Buffer.BlockCopy(encrypted, 0, res, 0, encrypted.Length);
            Buffer.BlockCopy(iv, 0, res, encrypted.Length, iv.Length);
            Buffer.BlockCopy(keyhash, 0, res, encrypted.Length + iv.Length, keyhash.Length);

            var encryptedb64 = Convert.ToBase64String(res);

            _logger.Message("encryptedb64(enc+iv+keyhash): " + encryptedb64);

            message.Message = encryptedb64;


            //foreach (var p in party.Distinct().ToArray())
            //{
            //    var u = await _uops.GetByNameAsync(p);

            //    var uid = await idops.GetAsync(u.Id);

            //    byte[] iv = new byte[0];

            //    var encrypted = EncryptDataString(uid.IdentityKey, message.Message, out iv);

            //    var ucm = new ChatMessage(message.User, Convert.ToBase64String(encrypted), message.Party, message.ChatId);

            //    ucm.IV = Convert.ToBase64String(iv);

            //    d.Add(p, ucm);
            //}

            //var encryptedSoul = EncryptDataString(ServerSideKeyHelper.Instance.PublicKey, message.Message, out iv);

            message.Created = DateTime.UtcNow;

            var dbMessage =  new ChatControllerProxy(_cops,_mops).PostMessage2(message.User, message.Message, message.Party, message.ChatId, message.Created, message.SID);



            //var pops = new PartyOperations();

            _pops.LinkPartyToChat(party.Distinct().ToArray(), dbMessage.ChatID);

            var connectedParty = _chatUsersHelper.GetConnectedParty(party);

            var connectedPartyIds = connectedParty.Select(i => i.ConnectionId).ToArray();

            result.connectedPartyIds = connectedPartyIds;



            var newMessage = _mops.AsFullChatMessage(dbMessage, _amops.GetMetadata(dbMessage.ID));

            result.ChatId = dbMessage.ChatID;

            result.Message = newMessage;

            //result.Message.Message = original;

            foreach (var u in connectedParty)
            {
                _logger.Message($"call addMessage to user-{u.Name}, connectionId: {u.ConnectionId}, sid:{newMessage.SID}");
            }


            if (result.IsNewChat)
                await _clients.Clients(result.connectedPartyIds).onNewChatCreated(result.ChatId);

            await _clients.Clients(result.connectedPartyIds).addMessage(result.Message);

            return result;
        }
        public async Task<ChatMessage[]> GetChatMessagesToUser(Guid chatId)
        {
            var userName = GetUsernameFromContext();


            if (!_cops.IsUserChat(chatId, $"@{userName}"))
                throw new ApplicationException("Access to foreign' chat messages denied");

            var messages = _mops.GetMessages(chatId);

            var result = new List<ChatMessage>();

            foreach (var m in messages)
            {
                var md = _amops.GetMetadata(m.ID);

                var rm = _mops.AsFullChatMessage(m, md);

                result.Add(rm);
            }

            var ret = result.ToArray();

            await _clients.Caller.getChatMessages(ret);

            return ret;
        }
        public async Task<ChatMessage[]> AsFullChatMessagesAsync(Message[] messages)
        {
            var list = new List<ChatMessage>();

            if (!messages.Any())
                return new ChatMessage[0];

            var party = _cops.GetChatParty(messages.FirstOrDefault().ChatID);

            foreach (var message in messages)
            {
                var cm = new ChatMessage(message.Author, message.Text, string.Join(",", party), message.ChatID.ToString())
                {
                    SID = message.ID,
                    Created = message.Created,
                    ChkSum = message.ChkSum.ToString(),
                    MsgChkSum = message.MsgChkSum.ToString(),
                    Metadata=_amops.GetMetadata(message.ID),
                    Read = message.StatusRead.HasValue && message.StatusRead.Value,
                    Delivered = message.StatusDelivered.HasValue && message.StatusDelivered.Value ,
                    SrvDelivered = message.StatusSrvDelivered.HasValue && message.StatusSrvDelivered.Value,

                };

                list.Add(cm);
            }

            return list.ToArray();
        }
        public async Task<Dictionary<string, ChatMessage[]>> ChatMessages(string user, string timeLabel, string msgChkSum)
        {
            if (string.IsNullOrEmpty(user))
                throw new ApplicationException("User is null or empty");

            var userName = GetUsernameFromContext();

            if (user!=$"@{userName}")
                throw new ApplicationException("User from arguments differs from authenticated");


            _logger.Message($"GetAllMessages called with user:{user}, timeLabel:{timeLabel}, msgChkSum:{msgChkSum}");

            var chatIds = _cops.GetChatIDsList(user);

            var dict = new Dictionary<string, ChatMessage[]>();

            foreach (var ch in chatIds)
            {
                try
                {
                    _logger.Message($"GetAllMessages: chat-{ch}");

                    var v = _mops.GetMessages(Guid.Parse(ch), timeLabel, msgChkSum);

                    var v1 = await AsFullChatMessagesAsync(v?.ToArray());

                    dict.Add(ch, v1);

                    _logger.Message($"GetAllMessages: messages count: {dict[ch].Length}");
                }
                catch (Exception ex)
                {
                    _logger.Error(ex);
                }
            }

            await _clients.Caller.getAllMessages(dict);

            return dict;
        }
        public async Task<ChatMessage[]> GetUserChatMessages(string user, string chat, string msgChkSum, string connectionId)
        {
            var userName = GetUsernameFromContext();

            _logger.Message($"{connectionId}=>:GetUserChatMessages called with user:{user}, chat:{chat}, msgChkSum:{msgChkSum}, auth user:{userName}");

            if (string.IsNullOrEmpty(user))
                throw new ApplicationException("User is null or empty");

            if (string.IsNullOrEmpty(chat))
                throw new ApplicationException("Chat is null or empty");

            var chatIdAsGuid = Guid.Parse(chat);

            var attachesToCache = _aops.GetChatAttachments(chatIdAsGuid)
                .ToDictionary(i=>i.ID.ToString(), j=>j.FilePath.EndsWith(".secret")? j.FilePath:$"{j.FilePath}.secret");

            RedisCache.SetCacheValues("dbo.Attach_", attachesToCache);
            
            if (user != $"@{userName}")
                throw new ApplicationException("User from arguments differs from authenticated");

            if (!_cops.IsUserChat(Guid.Parse(chat), $"@{userName}"))
                throw new ApplicationException("Access to foreign' chat messages denied");



            var v = _mops.GetMessages(Guid.Parse(chat), null, msgChkSum);

            var v1 = await AsFullChatMessagesAsync(v.ToArray());

            


            _logger.Message($"GetUserChatMessages: messages count: {v1.Length}");

            await _clients.Caller.getUserChatMessages(v1);



            return v1;
        }
        public async Task<Chat[]> GetAllChats(string user, string timeLabel)
        {
            if (string.IsNullOrEmpty(user))
                throw new ApplicationException("User is null or empty");

            var userName = GetUsernameFromContext();

            if (user != $"@{userName}")
                throw new ApplicationException("User from arguments differs from authenticated");


            var chats = _cops.GetAllChatsList(user, timeLabel);

            await _clients.Caller.getAllChats(chats);


            return chats;
        }
        public async Task<Party[]> GetAllParty(string user, string timeLabel)
        {
            if (string.IsNullOrEmpty(user))
                throw new ApplicationException("User is null or empty");

            var userName = GetUsernameFromContext();

            if (user != $"@{userName}")
                throw new ApplicationException("User from arguments differs from authenticated");

            var chats = _cops.GetAllParty(user, timeLabel);

            await _clients.Caller.getAllParty(chats);

            return chats;
        }
        public async Task<vw_User[]> GetAllUsers(string timeLabel)
        {
            var users = _uops.GetListForSync(timeLabel).ToArray();

            await _clients.Caller.getAllUsers(users);

            return users;
        }
        public async Task<vw_user_chat_list[]> GetUserChatList(string user)
        {
            _logger.Message($"Thread: {Thread.CurrentThread.ManagedThreadId}: GetUserChatList called with user:{user} with connectionId:{_hubcontext.ConnectionId}");

            if (string.IsNullOrEmpty(user))
                throw new ApplicationException("User is null or empty");

            var userName = GetUsernameFromContext();

            if (user != $"@{userName}")
                throw new ApplicationException("User from arguments differs from authenticated");

            var chats = _cops.GetChatList(user);

            await _clients.Caller.getUserChatList(chats);

            return chats;
        }
        string GetUsernameFromContext()
        {
            return _hubcontext.Request.User.Identity.Name;
        }
        public async Task Ping()
        {
            var user = GetUsernameFromContext();

            await _clients.Caller.ping(true);

            _logger.Message($"ping called with user:{user}");

        }
        public async Task<bool> Validate(string pair)
        {
            var valueDecoded = Encoding.UTF8.GetString(Convert.FromBase64String(pair));

            var jobj = JObject.Parse(valueDecoded);

            var key = (string)jobj.GetValue("key");

            if (string.IsNullOrEmpty(key))
                throw new ApplicationException("Validate key is null or empty");

            var val = (string)jobj.GetValue("value");

            var dict = new Dictionary<string, Func<string, Task<bool>>>()
            {
                {"email", this.GetEmailExist},
                {"sms", this.GetSmsExist},
                {"login", this.GetLoginExist}
            };

            if (!dict.Keys.Contains(key))
                throw new NotSupportedException("Нет метода валидации для ключа - " + key);

            var ret = await dict[key](val);

            await _clients.Caller.validate(ret);
            await _clients.Caller.validateKey(new {key, ret});

            return ret;
        }
        private async Task<bool> GetSmsExist(string phone)
        {
            return _uops.GetByPhone(phone);
        }
        private async Task<bool> GetEmailExist(string email)
        {
            return _uops.GetByEmail(email);
        }
        private async Task<bool> GetLoginExist(string login)
        {
            return _uops.GetByLogin(login);
        }
        public async Task<Data.Operation> Operation(string id, string method, string data)
        {
            var result = _oops.Add(id, method, data);

            await _clients.Caller.operation(result.ID);

            return result;
        }
        public async Task ConfirmOperation(string id, string code)
        {

            var idDecoded = Encoding.UTF8.GetString(Convert.FromBase64String(id));

            var codeDecoded = Encoding.UTF8.GetString(Convert.FromBase64String(code));

            _logger.Message($"ConfirmOperation with id={idDecoded}, code={codeDecoded}");

            var r = _oops.Confirm(idDecoded, codeDecoded);
            
            if (r == null)
            {
                _clients.Caller.confirmOperation("failed");
                return;
            }

            var obj = JObject.Parse(r.Data);
            

            var resultSuccess = false;

            var resultErrors = string.Empty;

            if (r.Name == "register")
            {

                var user = new User()
                {
                    UserName = (string) obj.GetValue("login"),
                    PhoneNumber = (string) obj.GetValue("phone"),
                    Email = (string) obj.GetValue("email"),
                };
                bool is_virtual = false;

                var isUserVirtual = bool.TryParse((string) obj.GetValue("isvirtual"),out is_virtual);
                
                _logger.Message($"ConfirmOperation before create user with id={r.ID}, data={r.Data}");

                var result = this._userManager.Create(user, (string) obj.GetValue("password"));

                if (result.Succeeded)
                {
                    _oops.OperationProcessedCreated(r.ID);

                    var u = _uops.GetByName(user.UserName);

                    if (!_props.ExistProfile(u.UserID))
                    {
                        var p = new Profile()
                        {
                            UserName = user.UserName,
                            Created = DateTime.UtcNow,
                            SettingsTouchIdEnabled = false,
                            SettingsSoundsEnabled = false,
                            IsVirtual = is_virtual
                        };
                        _props.SaveProfile(u.UserID,p);
                    }
                    else
                    {
                        var p = _props.GetProfile(u.UserID);

                        p.IsVirtual = is_virtual;

                        _props.SaveProfile(u.UserID, p);

                    }
                }

                resultSuccess = result.Succeeded;

                resultErrors = string.Join(",", result.Errors);

            }
            else if (r.Name == "restore")
            {

                var userIdString = (string) obj.GetValue("login");

                var u = _uops.GetByName(userIdString);

                int userId = 0;

                if (int.TryParse(u?.UserID.ToString(), out userId))
                {

                    var rtoken = await this._userManager.GeneratePasswordResetTokenAsync(userId);

                    var result = await this._userManager.ResetPasswordAsync(userId, rtoken, (string)obj.GetValue("password"));

                    resultSuccess = result.Succeeded;

                    resultErrors = string.Join(",", result.Errors);
                }

                if (resultSuccess)
                {
                    _oops.OperationProcessedCreated(r.ID);
                }
            }
        
            if (resultSuccess)
                _clients.Caller.confirmOperation("ok");
            else
                _clients.Caller.confirmOperation("failed\r\n" + resultErrors);

        }
        public async Task SendMessageNotification(string sid, DateTime clientDate, string clientDescr, string ip, string connectionId, string username)
        {
            var desc = $"connectionId={connectionId}, descr={clientDescr}";

            _nops.AddNotification(NotificationTypeEnum.NT_DELIVERY, Guid.Parse(sid), clientDate, desc, ip, username);

            await GetMessageStatus(sid);
        }
        public async Task SendMessageNotification2(string sid, DateTime clientDate, string clientDescr, string ip, string connectionId, string username)
        {
            var desc = $"connectionId={connectionId}, descr={clientDescr}, sid={sid}";

            _nops.AddNotification(NotificationTypeEnum.NT_READ, Guid.Parse(sid), clientDate, desc, ip, username);

            await GetMessageStatus(sid);
        }
        public async Task SendMessageNotification3(string chatid, DateTime clientDate, string clientDescr, string ip, string connectionId, string username)
        {
             var desc = $"connectionId={connectionId}, descr={clientDescr}, chatid={chatid}";

             var  ids = _nops.AddBulkNotification(NotificationTypeEnum.NT_READ, Guid.Parse(chatid), clientDate, desc, ip, username);

            //                foreach (var id in ids)
            //                {
            //                    await GetMessageStatus(id.ToString());
            //                }
            var statuses = _nops.GetChangeStatusSids(Guid.Parse(chatid));

            var party = _cops.GetChatParty(Guid.Parse(chatid));

            var connectedParty = _chatUsersHelper.GetConnectedParty(party);

            var connectedPartyIds = connectedParty.Select(i => i.ConnectionId).ToArray();

            //await _clients.Clients(connectedPartyIds).getMessageReadStatusesByChat(statuses);

            foreach (var s in statuses)
            {
                try
                {
                    _mops.UpdateMessageStatus(s.ID, true, s.StatusDelivered==1, s.StatusRead==1);

                    var statusObj = new
                    {
                        sid = s.ID,
                        party = "",
                        delivered = s.StatusDelivered==1,
                        read = s.StatusRead==1,
                        srvDelivered = true
                    };

                    await _clients.Clients(connectedPartyIds).getMessageReadStatus(statusObj);


                }
                catch (Exception ex)
                {
                    _logger.Error(ex);
                }

            }

        }
        public async Task SendMessageNotification4(string chatid, DateTime clientDate, string clientDescr, string ip, string connectionId, string username)
        {
            var desc = $"connectionId={connectionId}, descr={clientDescr}, chatid={chatid}";

            var ids = _nops.AddBulkNotification(NotificationTypeEnum.NT_READ, Guid.Parse(chatid), clientDate, desc, ip, username);

            var statuses = _nops.GetChangeStatusSids(Guid.Parse(chatid));

            var party = _cops.GetChatParty(Guid.Parse(chatid));

            var connectedParty = _chatUsersHelper.GetConnectedParty(party);

            var connectedPartyIds = connectedParty.Select(i => i.ConnectionId).ToArray();

            //result.connectedPartyIds = connectedPartyIds;

            //var connectedParty = _chatUsersHelper.GetConnectedParty(new[] { (string)pre.author });

            //var connectedPartyIds = connectedParty.Select(i => i.ConnectionId).ToArray();

            await _clients.Clients(connectedPartyIds).getMessageReadStatusesByChat(statuses);

            foreach (var s in statuses)
            {
                _mops.UpdateMessageStatus(s.ID, true, s.StatusDelivered, s.StatusRead);



            }

        }
        public async Task<dynamic> CalcMessageStatus(Guid gsid)
        {

            var message = _mops.Get(gsid);

            var flagServerDeliveryStatus = message != null;

            var notifsDelivery = _nops.GetNotifications(gsid, NotificationTypeEnum.NT_DELIVERY);

            var notifsRead = _nops.GetNotifications(gsid, NotificationTypeEnum.NT_READ);

            _logger.Message($"message sid:{gsid}");
            _logger.Message($"message chat:{message?.ChatID}");

            var party = _cops.GetChatParty(message.ChatID).ToArray();

            var partyList = party.ToList();

            //удаляем из списка автора сообщения
            partyList.Remove(message.Author);

            var listOfDelivered = notifsDelivery.Where(i => i.username != message.Author).Select(i => i.username).Distinct().ToArray();

            var listOfRead = notifsRead.Where(i => i.username != message.Author).Select(i => i.username).Distinct().ToArray();

            var statusObj = new
            {
                author=message.Author,
                sid = gsid,
                party = party.Length,
                delivered = ItemsEqual(listOfDelivered, partyList.ToArray()),
                read = ItemsEqual(listOfRead, partyList.ToArray()),
                srvDelivered = flagServerDeliveryStatus
            };

            _logger.Message($"Read Notification Status: read:{listOfRead.Length}, list: {string.Join(", ", listOfRead)}, equals:{statusObj.read}");

            _logger.Message($"Delivery Notification Status: delivered:{listOfDelivered.Length}, list: {string.Join(", ", listOfDelivered)}, equals:{statusObj.delivered}");

            _mops.UpdateMessageStatus(gsid, statusObj.srvDelivered, statusObj.delivered, statusObj.read);

            return statusObj;
        }
        public async Task GetMessageStatus(string sid)
        {
            var gsid = Guid.Parse(sid);

            var pre= await CalcMessageStatus(gsid);

            var statusObj = new
            {
                sid = pre.sid,
                party = pre.party,
                delivered = pre.delivered,
                read = pre.read,
                srvDelivered = pre.srvDelivered
            };

            var connectedParty = _chatUsersHelper.GetConnectedParty(new [] { (string)pre.author });

            var connectedPartyIds = connectedParty.Select(i => i.ConnectionId).ToArray();

            _clients.Clients(connectedPartyIds).getMessageReadStatus(statusObj);
        }
        public static bool ItemsEqual<TSource>(TSource[] array1, TSource[] array2)
        {
            if (array1 == null && array2 == null)
                return true;
            if (array1 == null || array2 == null)
                return false;
            return array1.Count() == array2.Count() && !array1.Except(array2).Any();
        }
        public void SendSms(string user, string phone, string message)
        {

            if (!string.IsNullOrEmpty(phone))
            {

                var task = new SmsTask
                {
                    SmsTaskId = Guid.NewGuid(),
                    From = "IT NNK",
                    Etc = phone,
                    MessageText = message,
                    Created = DateTime.Now,
                    RecipientIds = "0",
                    StatusId = 1,
                    StatusTime = DateTime.Now,
                    IsServiceTask = true
                };

                //8796
                _smsServiceOps.SendSmsFromWeb(task);

                _logger.Message($"смс с кодом подтверждения операции отправлена пользователю: {user}");
            }
        }
        public void SendEmail(string user, string email, string message, string title)
        {

            var body = new MessageBody(BodyType.Text, message);

            _exchangeProvider.SendMessage(email, title, body);

            _logger.Message($"письмо с кодом подтверждения операции отправлено пользователю: {user}");

        }
        public async Task GetConfirmSecret(string operationId)
        {


            var idDecoded = Encoding.UTF8.GetString(Convert.FromBase64String(operationId));

            var code = _oops.GetConfirmSecretCode(Guid.Parse(idDecoded));

            
            if (code != null)
            {

                var obj = JObject.Parse(code.Data);

                var user = new User()
                {
                    UserName = (string)obj.GetValue("login"),
                    PhoneNumber = (string)obj.GetValue("phone"),
                    Email = (string)obj.GetValue("email")
                };

                if (code.Name == "register")
                {
                    if (code.Method == "sms")
                    {
                        SendSms(user.UserName, user.PhoneNumber, code.GenCode);

                        await _clients.Caller.getCowWeight(code.GenCode.Length);
                    }
                    else
                    {
                        SendEmail(user.UserName, user.Email, code.GenCode, "Код подтверждения регистрации");
                    }
                }
                else if (code.Name == "restore")
                {
                    var u = _uops.GetByName(user.UserName);

                    if (code.Method == "sms")
                    {
                        SendSms(u.UserName, u.PhoneNumber, code.GenCode);

                        await _clients.Caller.getCowWeight(code.GenCode.Length);
                    }
                    else
                    {
                        SendEmail(u.UserName, u.Email, code.GenCode, "Код подтверждения смены пароля");
                    }

                }
            }
        }
        public async Task DeleteMessage(string user, string msid)
        {
            var m = _mops.Get(Guid.Parse(msid));

            if (user!=m.Author)
                throw new ApplicationException("Could not delete foreign messages");

            var etext = encryptString("Данное сообщение удалено");

            _mops.UpdateMessageText(Guid.Parse(msid),etext);

            _amops.KillMetadata(Guid.Parse(msid));

            var deleted = _mops.Get(Guid.Parse(msid));

            var party = _cops.GetChatParty(m.ChatID).ToList();

            var connectedParty = _chatUsersHelper.GetConnectedParty(party);

            var connectedPartyIds = connectedParty.Select(i => i.ConnectionId).ToArray();

            await _clients.Clients(connectedPartyIds).messageDeleted(m.ID, etext);

            await _clients.Clients(connectedPartyIds).messageDeleted2(new { m.ID, etext, deleted.MsgChkSum});

        }
        public async Task UpdateChatTitle(string atuser, string chatId, string newtitle)
        {
            if (string.IsNullOrEmpty(atuser))
                throw new ApplicationException("User is null or empty");

            if (!_cops.IsUserChat(Guid.Parse(chatId), $"{atuser}"))
                throw new ApplicationException("Access to foreign' chat messages denied");

            _cops.UpdateChatTitle(Guid.Parse(chatId), newtitle);

            var party = _cops.GetChatParty(Guid.Parse(chatId)).ToList();

            var connectedParty = _chatUsersHelper.GetConnectedParty(party);

            var connectedPartyIds = connectedParty.Select(i => i.ConnectionId).ToArray();

            await _clients.Clients(connectedPartyIds).chatTitleUpdated(chatId, newtitle);
            await _clients.Clients(connectedPartyIds).chatTitleUpdated2(new { chatId, newtitle});

        }
        public async Task<Invite[]> GetUserInvites(string user)
        {
            if (string.IsNullOrEmpty(user))
                throw new ApplicationException("User is null or empty");

            var userName = GetUsernameFromContext();

            if (user != $"@{userName}")
                throw new ApplicationException("User from arguments differs from authenticated");


            var invites = _iops.GetAllByUser(user);

            _logger.Message($"call to GetUserInvites ({user}) returns {invites.Length} items");

            await _clients.Caller.getFreshInvites(invites);

            return invites;
        }
        public async Task KillChat(Guid? chatId)
        {

            var mids = new Guid[0];

            var fids = new Guid[0];

            _logger.Message($"KillChat {chatId}");


            var chat = _cops.Get(chatId.Value);

            if (chat != null)
            {
                var user = GetUsernameFromContext();

                string userName = $"@{user}";

                if (chat.IsGroup && chat.Author != userName)
                {
                    _logger.Message($"Ошибка. Попытка удалить чат пользователем {userName}. Удалить чат может только автор чата {chat.Author}. Чат не удалён.");

                    throw new ApplicationException("Удалить чат может только автор чата");
                }

                try
                {
                    //get messages ids from chatId
                    mids =  _mops.GetChatMessagesIDs(chatId)?.ToArray();

                    _logger.Message($"get messages ids from chatId {chatId}");
                }
                catch (Exception ex)
                {
                    _logger.Error(ex);
                }

                try
                {
                    //kill messages notifications
                    _nops.KillChatMessageNotifications(mids);

                    _logger.Message($"kill messages notifications");
                }
                catch (Exception ex)
                {
                    _logger.Error(ex);
                }


                try
                {
                    //get filestream ids for messages attaches 
                    fids = _aops.GetAttachIds(mids);

                    _logger.Message($"get filestream ids for messages attaches");
                }
                catch (Exception ex)
                {
                    _logger.Error(ex);
                }


                try
                {
                    //kill messages attaches
                    _aops.KillChatMessageAttaches(mids);

                    _logger.Message($"kill messages attaches");
                }
                catch (Exception ex)
                {
                    _logger.Error(ex);
                }


                try
                {
                    //kill files from db
                    _fops.KillFiles(fids);

                    _logger.Message($"kill files from db");
                }
                catch (Exception ex)
                {
                    _logger.Error(ex);
                }


                try
                {
                    //kill messages
                    _mops.KillMessages(chatId.Value);

                    _logger.Message($"kill messages");
                }
                catch (Exception ex)
                {
                    _logger.Error(ex);
                }


                try
                {
                    //kill chat parties
                    _pops.KillParty(chatId.Value);

                    _logger.Message($"kill chat parties");
                }
                catch (Exception ex)
                {
                    _logger.Error(ex);
                }


                try
                {
                    //kill chat
                    _cops.KillChat(chatId.Value);

                    _logger.Message($"kill chat");
                }
                catch (Exception ex)
                {
                    _logger.Error(ex);
                }

                await _clients.All.onKillChat(chatId.Value.ToString());
            }
        }
        public async Task<ChatHubControllerInviteUserResult> InviteUser(string chatId, string user, string inviter)
        {
            var result = new ChatHubControllerInviteUserResult();

            _logger.Message($"user {user} is invited into chat -{chatId} by {inviter}");

            var chat = Guid.Parse(chatId);

            var chatObj = _cops.Get(chat);

            var invite = _iops.CreateInvite(chat, inviter, user, chatObj.IsHidden);

            var party = _cops.GetChatParty(chat).ToList();

            var connectedParty = _chatUsersHelper.GetConnectedParty(party);

            var connectedPartyIds = connectedParty.Select(i => i.ConnectionId).ToArray();

            result.ConnectionParty = connectedPartyIds;

            var text = encryptString($"Пользователь {inviter} пригласил в чат пользователя {user}");

            //var dbMessage = _mops.CreateInviteMessage(chat, user, inviter, text);

            var newMessage = _mops.CreateCustomChatMessage(chat, inviter, text);

            foreach (var u in result.ConnectionParty)
            {
                _logger.Message($"call addMessage to user connectionId: {u}");
            }

            result.Message = newMessage;

            var invitedConnectedParty = _chatUsersHelper.GetInstance().Users.Where(i => i.Name == user).Select(i=>i.ConnectionId).ToArray();

            await _clients.Caller.onUserInvited(new { chatId, inviter });

            DebugConnectedUsers();

            if (invitedConnectedParty.Any())
            {
                _logger.Message($"call onInviteToChat to invited user: {user}");

                await _clients.Clients(invitedConnectedParty).onInviteToChat(invite);
            }
            await _clients.Clients(result.ConnectionParty).addMessage(result.Message);

            return result;
        }
        public async Task<ChatHubControllerInviteUserResult> InviteUsers(string chatId, string[] users, string inviter)
        {
            var result = new ChatHubControllerInviteUserResult();

            _logger.Message($"users {string.Join(", ",users)} is invited into chat -{chatId} by {inviter}");

            var chat = Guid.Parse(chatId);

            var chatObj = _cops.Get(chat);

            var party = _cops.GetChatParty(chat).ToList();

            var connectedParty = _chatUsersHelper.GetConnectedParty(party);

            var connectedPartyIds = connectedParty.Select(i => i.ConnectionId).ToArray();

            result.ConnectionParty = connectedPartyIds;

            var text = encryptString($"Пользователь {inviter} пригласил в чат пользователей {string.Join(", ", users)}");

            var inviteList = new List<Invite>();

            foreach (var user in users)
            {
                try
                {
                    var invite = _iops.CreateInvite(chat, inviter, user, chatObj.IsHidden);

                    inviteList.Add(invite);
                }
                catch (Exception ex)
                {
                    _logger.Error(ex);
                }

            }

            var newMessage = _mops.CreateCustomChatMessage(chat, inviter, text);

            foreach (var u in result.ConnectionParty)
            {
                _logger.Message($"call addMessage to user connectionId: {u}");
            }

            result.Message = newMessage;


            foreach (var invite in inviteList)
            {
                var invitedConnectedParty = _chatUsersHelper.GetInstance().Users.Where(i => i.Name==invite.Invited).Select(i => i.ConnectionId).ToArray();

                if (invitedConnectedParty.Any())
                {
                    _logger.Message($"call onInviteToChat to invited user: {invite.Invited}");

                    await _clients.Clients(invitedConnectedParty).onInviteToChat(invite);
                }

            }
            await _clients.Caller.onUserInvited(new { chatId, inviter });

            DebugConnectedUsers();

            await _clients.Clients(result.ConnectionParty).addMessage(result.Message);

            return result;
        }
        public async Task<ChatHubInviteResult> RejectInvite(string inviteId)
        {
            var result = new ChatHubInviteResult();

            string user = $"@{GetUsernameFromContext()}";

            _logger.Message($"user {user} reject invite {inviteId}");

            var invite = _iops.Get(Guid.Parse(inviteId));

            var rejected = _iops.RejectInvite(invite);

            var party = _cops.GetChatParty(rejected.ChatId).ToList();

            var connectedParty =_chatUsersHelper.GetConnectedParty(party);

            var connectedPartyIds = connectedParty.Select(i => i.ConnectionId).ToArray();

            result.ConnectionParty = connectedPartyIds;

            var text = encryptString($"Пользователь {rejected.Invited} отклонил приглашение в чат");

            var newMessage = _mops.CreateCustomChatMessage(rejected.ChatId, rejected.Invited, text);

            //var dbMessage =  _mops.CreateInviteRejectMessage(rejected.ChatId, rejected.Invited, text);

            //var newMessage =  _mops.AsFullChatMessage(dbMessage, _amops.GetMetadata(dbMessage.ID));


            foreach (var u in connectedParty)
            {
                _logger.Message($"call Message to user connectionId: {u}");
            }

            result.Message = newMessage;

            result.Invite = rejected;

            _iops.Delete(Guid.Parse(inviteId));

            await _clients.Clients(result.ConnectionParty).addMessage(result.Message);

            await _clients.Clients(result.ConnectionParty).onUserInviteRejected(result.Invite.Invited);

            await _clients.Clients(result.ConnectionParty).onInviteRejected(result.Invite);

            return result;
        }
        public async Task<ChatHubInviteResult> AcceptInvite(string inviteId)
        {
            var result = new ChatHubInviteResult();

            string user = $"@{GetUsernameFromContext()}";

            _logger.Message($"user {user} accepts invite {inviteId}");

            var invite = _iops.Get(Guid.Parse(inviteId));

            if (invite == null)//??
                return result;

            var accepted = _iops.AcceptInvite(invite);

            _cops.UpdateChatParty(accepted.ChatId, accepted.Invited);

            var party = _cops.GetChatParty(accepted.ChatId).ToList();

            var connectedParty =_chatUsersHelper.GetConnectedParty(party);

            var connectedPartyIds = connectedParty.Select(i => i.ConnectionId).ToArray();

            result.ConnectionParty = connectedPartyIds;


            var text = encryptString($"Пользователь {accepted.Invited} присоединился к чату");

            //var dbMessage =  _mops.CreateInviteAcceptMessage(accepted.ChatId, accepted.Invited, text);

            //result.Message =  _mops.AsFullChatMessage(dbMessage, null);

            result.Message = _mops.CreateCustomChatMessage(accepted.ChatId, accepted.Invited, text);


            foreach (var u in connectedParty)
            {
                _logger.Message($"call Message to user connectionId: {u}");
            }

            result.Invite = accepted;

            await _clients.Clients(result.ConnectionParty).addMessage(result.Message);

            await _clients.Caller.onUserInviteAccepted(result.Invite.Invited);

            await _clients.Caller.onInviteAccepted(result.Invite);

            return result;
        }
        public async Task DeleteInvite(string inviteId)
        {

            string user = $"@{GetUsernameFromContext()}";

            _iops.Delete(Guid.Parse(inviteId));

            _logger.Message("DeleteInvite completes with success");

            await _clients.Caller.onInviteDeleted(inviteId);
        }
        public async Task SendMetadata(Guid msid, string meta)
        {
            try
            {
                var metaDecoded = System.Uri.UnescapeDataString(Encoding.UTF8.GetString(Convert.FromBase64String(meta)));

                var am = _amops.AddAttachMetadata(metaDecoded, msid);//insert or return

                await _clients.Caller.onMetadataSent(msid);

                _logger.Message($"metadata for {msid} processed");
            }
            catch (Exception ex)
            {
                _logger.Message($"metadata for {msid} error:");
                
                _logger.Error(ex);

                await _clients.Caller.onMetadataSent(0);
            }
        }
        public async Task LeaveChat(Guid? chatId, string user)
        {
            _logger.Message($"User - {user} has left chat: {chatId}");

            if (chatId.HasValue)
            {
                _cops.RemoveChatUser(chatId.Value, user);

                var party = _cops.GetChatParty(chatId.Value);

                var partyStrong = party.Where(i => i != user).ToArray();

                var connectedParty = _chatUsersHelper.GetConnectedParty(partyStrong);

                var connectedPartyIds = connectedParty.Select(i => i.ConnectionId).ToArray();

                var text = encryptString($"Пользователь {user} покинул чат");

                var sysMessage = _mops.CreateCustomChatMessage(chatId.Value, user, text);

                await _clients.Clients(connectedPartyIds).addMessage(sysMessage);

            }

            await _clients.All.onUserLeftChat(new { chat = chatId, user });
        }
        public string HashPassword(string password, string b64Salt = null)
        {
            if (password == null)
                throw new ArgumentNullException("password");

            byte[] salt;
            byte[] bytes;


            var rfc2898DeriveBytes = b64Salt == null
                ? new Rfc2898DeriveBytes(password, 16, 1004)
                : new Rfc2898DeriveBytes(password, Convert.FromBase64String(b64Salt), 1004);

            using (rfc2898DeriveBytes)
            {
                salt = rfc2898DeriveBytes.Salt;
                bytes = rfc2898DeriveBytes.GetBytes(32);
                //Console.WriteLine(Convert.ToBase64String(salt) + "|" + Convert.ToBase64String(bytes));
            }
            byte[] inArray = new byte[49];
            Buffer.BlockCopy((Array)salt, 0, (Array)inArray, 1, 16);
            Buffer.BlockCopy((Array)bytes, 0, (Array)inArray, 17, 32);
            return Convert.ToBase64String(inArray);
        }
        public bool ValidatePassword(string passwordHash, string password)
        {
            byte[] numArray = Convert.FromBase64String(passwordHash);

            byte[] salt = new byte[16];
            Buffer.BlockCopy((Array)numArray, 1, (Array)salt, 0, 16);

            byte[] a = new byte[32];
            Buffer.BlockCopy((Array)numArray, 17, (Array)a, 0, 32);

            byte[] bytes;
            Rfc2898DeriveBytes rfc2898DeriveBytes = new Rfc2898DeriveBytes(password, salt, 1004);
            bytes = rfc2898DeriveBytes.GetBytes(32);
            //Console.WriteLine(Convert.ToBase64String(salt));
            //Console.WriteLine(Convert.ToBase64String(bytes));
            //            var j = new List<byte> { 0 };
            //            j.AddRange(salt);
            //            j.AddRange(bytes);
            //Console.WriteLine(Convert.ToBase64String(j.ToArray()));
            return bytes.SequenceEqual(a);
            
        }
        public async Task<ChatHubCreateGroupChatResult> CreateGroupChat(string[] selected, string title, string user, string passwordb64=null, bool hidden=false)
        {
            var result = new ChatHubCreateGroupChatResult();

            _logger.Message($"СreateGroupChat called with User - {user}, title - {title}, party: {string.Join(",", selected)}");

            string chatHash = null;
            if (passwordb64 != null)
            {
                var password = Encoding.UTF8.GetString(Convert.FromBase64String(passwordb64));

                chatHash = HashPassword(password);
            }

            var chat = new Chat {Author = $"{user}", Title = title, IsHidden = hidden, PasswordHash = chatHash, IsGroup = true};

            var partyList = selected.Select(i => i.StartsWith("@") ? $"{i}" : $"@{i}").ToList();

            chat.Party = string.Join(",", partyList);

            var chatDb = _cops.CreateChat(chat);

            var party = chatDb.Party.Split(new[] { "," }, StringSplitOptions.RemoveEmptyEntries).ToList();

            var connectedParty = _chatUsersHelper.GetConnectedParty(party/*.Where(i => i != user).ToList()*/);

            var connectedPartyIds = connectedParty.Select(i => i.ConnectionId).ToArray();

            _logger.Message($"before call onGroupChatCreated with chatId=: {chatDb.ID}");

            foreach (var u in connectedParty)
            {
                _logger.Message($"call onNewChatCreated to user-{u.Name}, connectionId: {u.ConnectionId}");
            }

            result.Chat= chatDb;

            result.ConnectedParty = connectedPartyIds;

            var partyStrong = string.Join(",", partyList.Where(i => i != user).ToArray());

            var text = encryptString($"Пользователь {user} создал новый групповой чат с участниками {partyStrong}");

            var newMessage = _mops.CreateCustomChatMessage(result.Chat.ID, result.Chat.Author, text);


            var res = new { result.Chat.ID, result.Chat.Author, result.Chat.Created, result.Chat.IsHidden, result.Chat.Modified, result.Chat.Party, result.Chat.Title, IsGroup = true };

            //var res2 = new { result.Chat.ID, result.Chat.Author, result.Chat.Created, result.Chat.IsHidden, result.Chat.Modified, result.Chat.Party, result.Chat.Title, IsGroup=true };

            await _clients.Caller.onGroupChatCreated(res);

            await _clients.Clients(result.ConnectedParty).onNewChatCreated(res);

            //await _clients.Clients(result.ConnectedParty).onAddMessage(newMessage);
            await _clients.Clients(result.ConnectedParty).addMessage(newMessage);


            if (result.Chat.IsHidden.HasValue && !result.Chat.IsHidden.Value)
            {
                //add task to push service
                if (_rc == null)
                    _rc = new RabbitMqClient(_rcfp, _logger);

                _rc.AddTask(new CreateGroupChatPushTask(result.Chat.ID.ToString()));
            }

            return result;
        }
        public async Task<bool> ValidateSecretChat(Guid? chatId, string passwordb64)
        {
            var password = Encoding.UTF8.GetString(Convert.FromBase64String(passwordb64));

            var chat = _cops.Get(chatId.Value);

            var res= ValidatePassword(chat.PasswordHash, password);

            _clients.Caller.chatPasswordValid(res);

            return res;
        }
        private void DebugConnectedUsers()
        {
            foreach (var cu in _chatUsersHelper.GetInstance().Users)
            {
                _logger.Message($"user - {cu.Name}, connectionId: {cu.ConnectionId} is online");
            }

        }
        public async Task CloseFileTransferSessionAddAttachments(IEnumerable<TransferInfo>items, Guid sid)
        {
            foreach (var i in items)
            {
                _logger.Message($"add attachment from file {i.Path}");

                var a = _aops.AddAttachment(sid, $"{i.Sid}_{i.Filename}", File.ReadAllBytes(i.Path));

                _amops.LinkAttachMetadata(a);

                await Task.Run(()=> {
                    try
                    {
                        _logger.Message($"delete file {i.Path}");

                        File.Delete(i.Path);
                    }
                    catch(Exception ex)
                    {
                        _logger.Error(ex);

                        throw;
                    }
                });
            }
        }
        public async Task AddAttachmentMessage(string text, Guid sid, Guid chatId)
        {
            try {

                //var a = await _aops.AddAttachmentAsync(sid, $"{sid}_{filename}", bytes);

                //await _amops.LinkAttachMetadataAsync(a);

                var party = _cops.GetChatParty(chatId);

                //var messageParty = string.Join(",", party);
                _logger.Message($"AddAttachmentMessage with sid:{sid}");
                var dbMessage = _mops.AddMessage(chatId, $"@{GetUsernameFromContext()}", text, DateTime.UtcNow, sid);

                var message = _mops. AsFullChatMessage(dbMessage, _amops.GetMetadata(dbMessage.ID));

                var connectedParty = _chatUsersHelper.GetConnectedParty(party);

                var connectedPartyIds = connectedParty.Select(i => i.ConnectionId).ToArray();

                await _clients.Clients(connectedPartyIds).addMessage(message);

                return;
            }
            catch (Exception ex)
            {
                _logger.Error(ex);

                throw;
            }
            
        }
        byte[] BytesFromHexString(string hex)
        {
            var lb = new List<byte>();

            for (var i = 0; i < hex.Length; i += 2)
            {
                var num = byte.Parse(hex.Substring(i, 2), System.Globalization.NumberStyles.HexNumber);

                lb.Add(num);
            }
            return lb.ToArray();
        }
        public async Task RegisterUserKeys(string b64PublicKeys, string userIdStr, bool forceChangeUserKeys=false)
        {
            try {

                var jsonObject = b64PublicKeys;

                _logger.Message($"RegisterUserKeys called with param b64PublicKeys={b64PublicKeys}");

                var jobj = Newtonsoft.Json.Linq.JObject.Parse(jsonObject);

                var identityKey =Convert.FromBase64String((string)jobj.GetValue("identityKey"));

                var signedPreKey = (string)jobj.GetValue("devKey");

                byte[] devBytes = (signedPreKey != null) ? BytesFromHexString(signedPreKey) : new byte[0];

                var keys = _idops.Get(int.Parse(userIdStr));

                _logger.Message($"RegisterUserKeys called with param b64Identity={Convert.ToBase64String(identityKey)} and forceRegister={forceChangeUserKeys}");

                var status = "";

                if (keys != null && !forceChangeUserKeys)
                {

                    _logger.Message($"keys from db b64={Convert.ToBase64String(keys.IdentityKey)}");
                    
                    //throw new ApplicationException("User keys already registered.");

                    status = "User keys already registered.";
                }
                else
                {
                    _logger.Message($"RegisterUserKeys with key={Convert.ToBase64String(identityKey)}, dev={string.Join(",",devBytes)}");

                    _idops.RegisterUserKeys(int.Parse(userIdStr), identityKey, devBytes, null, null);
                }

                await _clients.Caller.onRegisterUserKeys(new {key= Convert.ToBase64String(identityKey), dev= signedPreKey, status =status });

                return;
            }
            catch (Exception ex)
            {
                _logger.Error(ex);

                throw;
            }
        }
        public async Task GetUserKeys(string user)
        {
            _logger.Message($"GetUserKeys called with param user={user}");

            var u = _uops.GetByName(user);

            var keys = _idops.Get(u.UserID);

            await _clients.Caller.onGetUserKeys(keys);
        }
        public async Task<string> SecOp4(string user, string b64Data)
        {
            try
            {
                var u = _uops.GetByName(user);

                var rtoken = await _userManager.GeneratePasswordResetTokenAsync(u.UserID);

                var result = await _userManager.ResetPasswordAsync(u.UserID, rtoken, Encoding.UTF8.GetString(Convert.FromBase64String(b64Data)));

                return "ok";

            }
            catch (Exception ex)
            {
                _logger.Error(ex);

                return "error:\r\n" + ex.ToString();
            }
        }
        public async Task<string> SecOp3(string chat)
        {
            try
            {
                var partyUsers = _cops.GetChatParty(Guid.Parse(chat));

                var connectionIds =
                    _chatUsersHelper.Users.Where(i => partyUsers.Contains(i.Name))
                        .Select(i => i.ConnectionId)
                        .ToArray();

                var connections =
                    _chatUsersHelper.Users.Where(i => partyUsers.Contains(i.Name)).ToArray();

                foreach (var c in connections)
                {
                    TextFileLoggerSingleton.Instanse.Message($"send secop2 to user: {c.Name} cid: {c.ConnectionId}, chat: {chat}");
                }

                await _clients.Clients(connectionIds).secOpMessage(new { secOpId = 3, chatId = chat });

                return $"ok, involved items:{connectionIds.Length}";
            }
            catch (Exception ex)
            {
                return "error:\r\n" + ex.ToString();
            }
        }
        public async Task<string> SecOp2(string username, string chat)
        {
            try
            {
                var connectionIds =
                    _chatUsersHelper.Users.Where(i => i.Name == $"@{username}")
                        .Select(i => i.ConnectionId)
                        .ToArray();

                var connections =
                    _chatUsersHelper.Users.Where(i => i.Name == $"@{username}").ToArray();

                foreach (var c in connections)
                {
                    TextFileLoggerSingleton.Instanse.Message($"send secop2 to user: {c.Name} cid: {c.ConnectionId}, chat: {chat}");
                }

                await _clients.Clients(connectionIds).secOpMessage(new { secOpId = 2, chatId = chat });

                return $"ok, involved items:{connectionIds.Length}";
            }
            catch (Exception ex)
            {
                return "error:\r\n" + ex.ToString();
            }
        }
        public async Task<string> SecOp1(string username)
        {
            try
            {

                var connectionIds = _chatUsersHelper.Users.Where(i => i.Name == $"@{username}").Select(i => i.ConnectionId).ToArray();

                var connections = _chatUsersHelper.Users.Where(i => i.Name == $"@{username}").ToArray();

                foreach (var c in connections)
                {
                    TextFileLoggerSingleton.Instanse.Message($"send secop1 to user: {c.Name} cid: {c.ConnectionId}");
                }

                await _clients.Clients(connectionIds).secOpMessage(new { secOpId = 1 });

                return $"ok, involved items:{connectionIds.Length}";
            }
            catch (Exception ex)
            {
                return "error:\r\n" + ex.ToString();
            }
        }
        public async Task Resend(string msid, string chatid, string newmsid, string username, string partyIfNewChat=null)
        {
            if (Guid.Parse(msid) == Guid.Empty)
                return;

            _logger.Message($"***Resend called with msid: {msid} chatid: {chatid} newmsid:{newmsid}");
            
            _amops.CloneAttachMetadata(Guid.Parse(msid), Guid.Parse(newmsid));

            var attaches = _aops.CloneAttach(Guid.Parse(msid), Guid.Parse(newmsid));

            foreach (var a in attaches)
            {
                _amops.LinkClonedAttachMetadata(a);
            }

            //var dbMessage = _mops.Get(Guid.Parse(msid));

            //var newmsg = _mops.AddMessage(Guid.Parse(chatid), $"@{username}", dbMessage.Text, DateTime.UtcNow,Guid.Parse(newmsid));

            var party = GetPartyFromChat(_cops, chatid, partyIfNewChat).ToList();

            if (!party.Contains($"@{username}"))
                party.Add($"@{username}");

            var partyString = string.Join(",", party);

            var md = _amops.GetMetadata(Guid.Parse(newmsid));

            //string chatIdString, string partyString, string userString, bool isNewChatHidden=false

            var chat = _cops.Get(Guid.Parse(chatid));

            var isNewChat = false;

            if (chat == null)
            {

                chat = _cops.GetChatFromParty(partyString, $"@{username}") ?? CreateChatFromParams(chatid, partyString, $"@{username}", false );

                isNewChat = true;
            }

            var dbMessage = _mops.AddMessage(Guid.Parse(chatid), $"@{username}", "null", DateTime.UtcNow, Guid.Parse(newmsid));

            //var newMessage = _mops.AsFullChatMessage(dbMessage, _amops.GetMetadata(dbMessage.ID));
            
            //var dbMessage = new ChatControllerProxy(_cops, _mops).PostMessage2($"@{username}", "null", partyString,
            //    chatid,
            //    DateTime.Now.ToUniversalTime(), Guid.Parse(newmsid));
            
            var newmessage = _mops.AsFullChatMessage(dbMessage, md);
            
            var connectedParty = _chatUsersHelper.GetConnectedParty(party);

            var connectedPartyIds = connectedParty.Select(i => i.ConnectionId).ToArray();

            if (isNewChat)
            {
                var res =
                    new
                    {
                        chat.ID,
                        chat.Author,
                        chat.Created,
                        chat.IsHidden,
                        chat.Modified,
                        chat.Party,
                        chat.Title,
                        chat.IsGroup
                    };

                await _clients.Clients(connectedPartyIds).onNewChatCreated(res);
            }

            var jobj = Newtonsoft.Json.Linq.JArray.Parse(md);

            _logger.Message($"***GetMetadata in ResendConfirmedAttachMessage: {jobj}");

            foreach (var u in connectedParty)
            {
                _logger.Message($"call addMessage to user-{u.Name}, connectionId: {u.ConnectionId}, sid:{newmessage.SID}");
            }

            await _clients.Clients(connectedPartyIds).addMessage(newmessage);

        }
        //GlobalHost.ConnectionManager.GetHubContext<ChatHub>().Clients
        public static Task ResendConfirmedAttachMessagePrivate(string msid, string user)
        {

            var __clients = GlobalHost.ConnectionManager.GetHubContext<ChatHub>().Clients;

            var __logger = (NNK.Logging.ILogger)GlobalHost.DependencyResolver.GetService(typeof(NNK.Logging.ILogger));

            var __mops = (IMessageOperations)GlobalHost.DependencyResolver.GetService(typeof(IMessageOperations));

            var __cops = (IChatOperations)GlobalHost.DependencyResolver.GetService(typeof(IChatOperations));

            var __amops = (IAttachMetadataOperations)GlobalHost.DependencyResolver.GetService(typeof(IAttachMetadataOperations));

            var __chatUsersHelper = (ChatUsersHelper)GlobalHost.DependencyResolver.GetService(typeof(ChatUsersHelper));


            if (Guid.Parse(msid) == Guid.Empty)
                return Task.CompletedTask;
            
            __logger.Message($"***ResendConfirmedAttachMessage called with msid: {msid}");

            var dbMessage = __mops.Get(Guid.Parse(msid));
            
            var chat = __cops.Get(dbMessage.ChatID);

            var res = new { chat.ID, chat.Author, chat.Created, chat.IsHidden, chat.Modified, chat.Party, chat.Title, chat.IsGroup };

            var obj = JsonConvert.SerializeObject(res,
                new JsonSerializerSettings() { StringEscapeHandling = StringEscapeHandling.EscapeHtml });
            
            var message = __mops.AsFullChatMessage(dbMessage, __amops.GetMetadata(dbMessage.ID));

            var party = GetPartyFromChat(__cops,message.ChatId);

            var connectedParty = __chatUsersHelper.GetConnectedParty(party);

            var connectedPartyIds = connectedParty.Select(i => i.ConnectionId).ToArray();


//            __clients.User()
            __clients.Client(user).onNewChatCreated(res);

            __logger.Message($"call onNewChatCreated with {obj}");
            
            var md = __amops.GetMetadata(Guid.Parse(msid));

            var jobj = Newtonsoft.Json.Linq.JArray.Parse(md);

            __logger.Message($"***GetMetadata in ResendConfirmedAttachMessage: {jobj}");

            foreach (var u in connectedParty)
            {
                __logger.Message($"call addMessage to user-{u.Name}, connectionId: {u.ConnectionId}, sid:{message.SID}");
            }

            __clients.Clients(connectedPartyIds).addMessage(message);

            return Task.CompletedTask;

        }
        public async Task ResendConfirmedAttachMessage(string msid)
        {
            if (Guid.Parse(msid) == Guid.Empty)
                return;

            _logger.Message($"***ResendConfirmedAttachMessage called with msid: {msid}");

            var dbMessage = _mops.Get(Guid.Parse(msid));




            var chat = _cops.Get(dbMessage.ChatID);

            var res =
                new
                {
                    chat.ID,
                    chat.Author,
                    chat.Created,
                    chat.IsHidden,
                    chat.Modified,
                    chat.Party,
                    chat.Title,
                    chat.IsGroup
                };

            var obj = JsonConvert.SerializeObject(res,
                new JsonSerializerSettings() {StringEscapeHandling = StringEscapeHandling.EscapeHtml});







            var message = _mops.AsFullChatMessage(dbMessage, _amops.GetMetadata(dbMessage.ID));

            var party = GetPartyFromChatMessage(message);

            var connectedParty = _chatUsersHelper.GetConnectedParty(party);

            var connectedPartyIds = connectedParty.Select(i => i.ConnectionId).ToArray();



            await _clients.Caller.onNewChatCreated(res);

            _logger.Message($"call onNewChatCreated with {obj}");


            var md = _amops.GetMetadata(Guid.Parse(msid));

            var jobj = Newtonsoft.Json.Linq.JArray.Parse(md);

            _logger.Message($"***GetMetadata in ResendConfirmedAttachMessage: {jobj}");

            foreach (var u in connectedParty)
            {
                _logger.Message($"call addMessage to user-{u.Name}, connectionId: {u.ConnectionId}, sid:{message.SID}");
            }

            await _clients.Clients(connectedPartyIds).addMessage(message);
        }
        public async Task SendStatusTyping(string userId, string userName, string chatId)
        {
            var party = _cops.GetChatParty(Guid.Parse(chatId));

            if (party.ToList().Contains(userName))
                party.ToList().Remove(userName);

            var connectedParty = _chatUsersHelper.GetConnectedParty(party);

            var connectedPartyIds = connectedParty.Select(i => i.ConnectionId).ToArray();

            _logger.Message($"call to SendStatusTyping returns {userName}");

            await _clients.Clients(connectedPartyIds).sendStatusTyping(userName);
        }
        public async Task GetOnlineUsers()
        {
            var users = _chatUsersHelper.Users;

            _logger.Message($"call to GetOnlineUsers returns {string.Join(",", users)}");

            await _clients.Caller.getOnlineUsers(users);
        }
        public async Task SaveProfile(string userIdString, string userName, string base64Json)
        {
            try
            {
                var userId = int.Parse(userIdString);

                var valueDecoded = Encoding.UTF8.GetString(Convert.FromBase64String(base64Json));

                var profile = ProfileFactory.FromJson(valueDecoded);

                if (userName!= profile.UserName)
                    throw new ApplicationException("Auth user differs from profile saved.");

                _props.SaveProfile(userId, profile);

                await _clients.Caller.saveProfile("ok");
            }
            catch (Exception ex)
            {
                await _clients.Caller.saveProfile(ex.ToString());

                throw;
            }
        }
        public async Task GetProfile(string userIdString, string userName)
        {
            var userId = int.Parse(userIdString);

            var profile = _props.GetProfile(userId);

            var obj = string.Empty;

            if (profile != null)
            {
                profile.UserName = userName;

                var jsonObj = new
                {
                    userName = profile.UserName,

                    contacts = profile.Contacts,

                    isLocalNotificationsEnabled = profile.SettingsIsLocalNotificationsEnabled.ToString(),

                    deletedMsgsIds = profile.DeletedMsgIDs,

                    isPinEnabled = profile.SettingsPinEnabled.ToString(),

                    pinCode = profile.SettingsPinCode,

                    isTouchEnabled = profile.SettingsTouchIdEnabled.ToString(),

                    isSoundsEnabled = profile.SettingsSoundsEnabled.ToString(),

                    imageAvatarStreamId=profile.ImageAvatarStreamId.ToString()
                };

                obj = JsonConvert.SerializeObject(jsonObj, new JsonSerializerSettings() { StringEscapeHandling = StringEscapeHandling.Default });
            }
            else
            {
                var jsonObj = new {};

                obj = JsonConvert.SerializeObject(jsonObj, new JsonSerializerSettings() { StringEscapeHandling = StringEscapeHandling.Default });
            }
            

            var objBytes = Encoding.UTF8.GetBytes(obj);

            var objBase64 = Convert.ToBase64String(objBytes);

            await _clients.Caller.getProfile(objBase64);

        }
        public async Task Logout(int uid, string devtokenHexString)
        {
            _logger.Message($"User uid={uid} calls Logout with devtoken={devtokenHexString}");

            _idops.CleanDevToken(uid, PushOperations.BytesFromHexString(devtokenHexString));

            _logger.Message($"Clean devtoken for user uid {uid}");
        }
        public async Task GetLastIosVersion()
        {
            _logger.Message($"call to GetLastIosVersion");

            var changeLog = _clops.GetLast();

            var linkedStamp = _clops.GetNextLinkForStamp(changeLog.Stamp);

            var link = $"{Properties.Settings.Default.GetIosVersionUrlPart}{linkedStamp}";

            await _clients.Caller.getLastVersion(new {changeLog.Version, link });
        }
        public async Task GetSidInfoAsync(Guid msid, string username)
        {
            var result = _mops.GetSidInfo(msid, username);

            await _clients.Caller.getSidInfo(result);
        }
        public async Task AddUserImage(string userIdString, string fileName, byte[] fileData)
        {
            var file = _fops.AddFileOldSchool($"{fileName}_{Guid.NewGuid()}", fileData);
            
            var userId = int.Parse(userIdString);

            var profile = _props.GetProfile(userId);

            if (profile != null)
            {
                var prevfile = profile.ImageAvatarStreamId;

                if (prevfile.HasValue)
                    _fops.DeleteFile(prevfile.Value);

                profile.ImageAvatarStreamId = file.stream_id;

                _props.SaveProfile(userId, profile);
            }
            else
            {
                profile = new Profile()
                {
                    ImageAvatarStreamId = file.stream_id,
                    Created = DateTime.UtcNow
                };
            }
            _props.SaveProfile(userId, profile);

            await _clients.Caller.addUserImage(new {file.stream_id, data = File.ReadAllBytes(file.unc_path)});

            await _clients.All.changeUserImage(userId);
        }
        public async Task GetUserImage(string userIdString)
        {
            var userId = int.Parse(userIdString);

            var profileImage = _props.GetProfileImage(userId);

            if (profileImage.HasValue)
            {
                var bytes = _fops.GetFileBytes(profileImage.Value);

                await _clients.Caller.getUserImage(new {stream_id = profileImage.Value, data = bytes, userId = userId});
            }
            else
            {
                await _clients.Caller.getUserImage(new { stream_id = Guid.Empty, data = new byte[0], userId = userId });
            }
        }
        public async Task GetUserImageByName(string username)
        {
            var user = _uops.GetByName(username);

            if (user?.UserID == null)
                return;

            var profileImage = _props.GetProfileImage(user.UserID);

            var res = new {stream_id = Guid.Empty, data = new byte[0], userId = user.UserID, userName = username};

            if (profileImage.HasValue)
            {
                var bytes = _fops.GetFileBytes(profileImage.Value);

                if (bytes != null)
                {
                    res = new {stream_id = profileImage.Value, data = bytes, userId = user.UserID, userName = username};
                }
            }

            await _clients.Caller.getUserImageByName(res);

        }
        public async Task SetChatImage(Guid chatId, string fileName, byte[] fileData)
        {
            var file = _fops.AddFileOldSchool($"{fileName}_{Guid.NewGuid()}", fileData);

            _cops.SetChatImageStreamId(chatId, file.stream_id);

            _logger.Message($"SetChatImage for chatid:{chatId}");

            await _clients.Caller.addChatImage(new { file.stream_id, data = File.ReadAllBytes(file.unc_path), chatId });
        }
        public async Task GetChatImage(Guid chatId)
        {
            _logger.Message($"GetChatImage for chatid:{chatId}");

            var fileStreamId = _cops.GetChatImageStreamId(chatId);

            if (fileStreamId.HasValue)
            {
                var bytes = _fops.GetFileBytes(fileStreamId.Value);

                if(bytes.Length>300000)
                    throw new Exception("Avatar Image Size Limit is 300kb.");


                await _clients.Caller.getChatImage(new {stream_id = fileStreamId.Value, data = bytes, chatId = chatId});
            }
            else
            {
                await _clients.Caller.getChatImage(new {stream_id = Guid.Empty, data = new byte[0], chatId = chatId});
            }
        }
        public static void OnUpdateUploadProgressPrivate(string msid, string user, int uploaded, int total, decimal percentage)
        {
            var __logger = (NNK.Logging.ILogger)GlobalHost.DependencyResolver.GetService(typeof(NNK.Logging.ILogger));

            __logger.Message($"OnUpdateUploadProgressPrivate called with: msid:{msid} user:{user} U/T/P:{uploaded}/{total}/{percentage}");

            var __clients = GlobalHost.ConnectionManager.GetHubContext<ChatHub>().Clients;

            var __chatUsersHelper = (ChatUsersHelper)GlobalHost.DependencyResolver.GetService(typeof(ChatUsersHelper));

            var connectedParty = __chatUsersHelper.GetConnectedParty(new []{user});

            var connectedPartyIds = connectedParty.Select(i => i.ConnectionId).ToArray();

            __clients.Clients(connectedPartyIds).getMediaUploadProgress(new {msid, uploaded, total, percentage});
        }
    }
}
