﻿using Microsoft.AspNet.SignalR;
using Microsoft.AspNet.SignalR.Hubs;

namespace NNK.Messenger.SignalR.Hubs
{
    [HubName("systemAgentHub")]
    public class SystemAgentHub : Hub
    {
        public void OnResendConfirmedAttachMessagePrivate(string msid, string user)
        {
            ChatHub.ResendConfirmedAttachMessagePrivate(msid, user);
        }

        public void OnUpdateUploadProgressPrivate(string msid, string user, int uploaded, int total, decimal percentage)
        {
            ChatHub.OnUpdateUploadProgressPrivate(msid, user, uploaded, total, percentage);
        }
    }
}