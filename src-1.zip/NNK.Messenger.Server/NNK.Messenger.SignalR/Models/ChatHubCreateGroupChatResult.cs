﻿using NNK.Messenger.Data;

namespace NNK.Messenger.SignalR.Models
{
    public class ChatHubCreateGroupChatResult
    {
        public Chat Chat { get; set; }
        public string[] ConnectedParty { get; set; }
    }
}
