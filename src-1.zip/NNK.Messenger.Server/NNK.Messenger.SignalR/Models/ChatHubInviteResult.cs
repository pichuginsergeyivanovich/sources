﻿using NNK.Messenger.Core;
using NNK.Messenger.Data;

namespace NNK.Messenger.SignalR.Models
{
   public class ChatHubInviteResult
    {
        public string[] ConnectionParty { get; set; }
        public ChatMessage Message { get; set; }
        public Invite Invite { get; set; }

    }
}
