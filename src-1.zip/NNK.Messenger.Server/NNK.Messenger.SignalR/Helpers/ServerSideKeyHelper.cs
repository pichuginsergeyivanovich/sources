﻿using System;
using NNK.Messenger.SignalR.Properties;

namespace NNK.Messenger.SignalR.Helpers
{
    public class ServerSideKeyHelper
    {
        private ServerSideKeyHelper()
        {
         }

        static ServerSideKeyHelper _instance;
        public static ServerSideKeyHelper Instance
        {
            get
            {

                if (_instance == null)
                    _instance = new ServerSideKeyHelper();

                return _instance;
            }
        }

        public byte[] PublicKey => Convert.FromBase64String(Settings.Default.ServerSideKey);

        public string PublicKeyAsString => Settings.Default.ServerSideKey;

    }
}
