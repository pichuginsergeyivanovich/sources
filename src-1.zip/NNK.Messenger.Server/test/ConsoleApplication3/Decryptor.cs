﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Net.Http.Headers;
using System.Numerics;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplication3
{
    public class Decryptor
    {
        public int KeySize { get; set; }
        public byte[]RsaDecryptBlock(byte[]block, dynamic key, bool verify=false)
        {
            var c = new BigInteger(block);
            var n = new BigInteger(key.Modulus);

            //var n = bi.FromBytes(key.Modulus);
            //var c = bi.FromBytes(block);

            //            var k = verify
            //                ? bi.FromBytes(key.Exponent) 
            //                : bi.FromBytes(key.D); 

            var k = verify
                ? new BigInteger(key.Exponent)
                : new BigInteger(key.D);


            BigInteger m;
            // The CRT method of decryption is four times faster overall than calculating c^d mod n.
            // Even though there are more steps in this procedure,
            // the modular exponentation to be carried out uses much shorter exponents and
            // so it is less expensive overall. 

            var crt = !verify;

            if (crt)
            {
                var dP = new BigInteger(key.DP);
                var dQ = new BigInteger(key.DQ);
                var qInv = new BigInteger(key.InverseQ);
                var p = new BigInteger(key.P);
                var q = new BigInteger(key.Q);
                // m1 = (c^dP) mod p
                var m1 = (c ^ dP) % p;
                Console.WriteLine(m1.ToString());
                //var m1 = BigInteger.ModPow(c, dP, p);

                // m2 = (c^dQ) mod q
                // var m2 = BigInteger.ModPow(c, dQ, q);
                var m2 = (c ^ dQ) % q;
                Console.WriteLine(m2.ToString());
                // h = (qInv * (m1 + p - m2)) mod p
                var h = BigInteger.Multiply(qInv, BigInteger.Subtract(BigInteger.Add(m1, p), m2)) % p;

                //var h = bi.MultiplyMod(qInv, bi.Subtract(bi.Add(m1, p), m2), p);


                // m = m2 + (h*q)
                m = BigInteger.Add(m2, BigInteger.Multiply(h, q));
            }
            else
            {
                // Decrypt: m = c^k mod n
                m = BigInteger.ModPow(c, k, n);
            }
            if (m<=n)
                Debug.Write("ERROR: The message m must be less than p*q");


            // Expand to block size with empty bytes.
            var bpb = this.KeySize / 8;             // bytes per block

            var mBytes = new byte[bpb];

            Buffer.BlockCopy(m.ToByteArray(), 0, mBytes, 0, mBytes.Length);
            
            //for (var i = mBytes.Length; i < bpb; i++)mBytes.push(0x00);
            return mBytes;
        }

        public byte[]DecryptBytes(dynamic key, byte[]input, dynamic fOAEP, bool verify)
        {
            var bpb = this.KeySize / 8; // bytes per block

            var output=new ArrayList(); // plaintext array

            for (var b = 0; b < input.Length / bpb; b++)
            {
                var block = new byte[bpb];

                Buffer.BlockCopy(input, b * bpb, block, 0, bpb);

                // RSA Decrypt.
                block = RsaDecryptBlock(block, key, verify);

                // Remove padding.
                //var unpadded = Padding.call(this, block, fOAEP, false, verify);

                // Reverse bytes for compatibility with RSACryptoServiceProvider.
                System.Array.Reverse(block);

                // Add result to output.
                //output = output.concat(unpadded);
                foreach (var item in block)
                {
                    output.Add(item);
                }
                
            }
            return output.Cast<byte>().ToArray();
        }


    }
}

