﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Net.Mime;
using System.Numerics;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplication3
{


    class Program
    {
        static byte[] BytesFromHexString(string hex)
        {
            var lb = new List<byte>();

            for (var i = 0; i < hex.Length; i += 2)
            {
                var num = byte.Parse(hex.Substring(i, 2), System.Globalization.NumberStyles.HexNumber);

                lb.Add(num);
            }
            return lb.ToArray();
        }
        static string HexStringFrom(byte[] bytes)
        {
            var hex = BitConverter.ToString(bytes).Replace("-","");

            return hex;
        }

        static void test()
        {

            var str = "B0AA31BF43C1FADB78B6CB0D9E8E6BF8CA1225D68B756F5F0D450FB8CA10CAA9";

            var bytes = BytesFromHexString(str);

            var s1 = HexStringFrom(bytes);

            Console.ReadLine();

            return;


            RSACryptoServiceProvider rsa = new RSACryptoServiceProvider(1024);

            var xmlParamsDefault = "<RSAKeyValue><Modulus>AK/9EaR7bk/SP4vF1K++XONhqPUWmJLdM7moqwVcjVQb/2KCA1lz2XDA49lLrBYOlhHs6mYGMR1V6d9SETAEI5d55mIbeSvKO3c2RK380VhvLiEySNJJqPo/LQa/bfoiILeUrJvhIX8ooSaelJzMPoyumyCnCcSVxweRQyZrz7eD</Modulus><Exponent>AQAB</Exponent></RSAKeyValue>";

            rsa.FromXmlString(xmlParamsDefault);

            var pub = rsa.ExportParameters(false);

            var encrypted = rsa.Encrypt(Encoding.UTF8.GetBytes("Привет как дела!?"),true);

            


            var encryptedb64 = Convert.ToBase64String(encrypted);

            Console.WriteLine("Привет как дела!?, rsa encrypted: " + encryptedb64);

            Console.ReadLine();

        }

        static void test2()
        {
            var xmlParamsDefault = "<RSAKeyValue><Modulus>178ZLq3lnuVvt4wgUoftKk6Li7m7hy/JCWqQBnZRzX1GX8A10pU7Ouw6o9ntltEYANnCyNZhigIxEBz+7SdaEVG+RJLsiP+T6/DdoKc5/zBA4VAqhZNOS+smtLZ5PLESCyrqIXCaAWLquB47CaLWSgsW2SR3AgoNFY8Lm3djcJ8=</Modulus><Exponent>AQAB</Exponent></RSAKeyValue>";

            RSACryptoServiceProvider rsa = new RSACryptoServiceProvider(1024);


            rsa.FromXmlString(xmlParamsDefault);

            var plaintext = "Жили у бабуси - 3 весёлых гуся!";

            var encrypted = rsa.Encrypt(Encoding.UTF8.GetBytes(plaintext),false);

            var encryptedb64 = Convert.ToBase64String(encrypted);

            Console.WriteLine($"{plaintext}" + ", rsa utf8 bytes: \r\n" + string.Join(",", Encoding.UTF8.GetBytes(plaintext)));

            Console.WriteLine($"{plaintext}" + ", rsa utf8 bytes->encrypted: \r\n" + string.Join(",", encrypted));

            Console.WriteLine($"{plaintext}"+ ", rsa utf8 bytes->encrypted->b64: \r\n" + encryptedb64);

            Console.ReadLine();

            var xmlParamsDefault1 = "<RSAKeyValue><Modulus>178ZLq3lnuVvt4wgUoftKk6Li7m7hy/JCWqQBnZRzX1GX8A10pU7Ouw6o9ntltEYANnCyNZhigIxEBz+7SdaEVG+RJLsiP+T6/DdoKc5/zBA4VAqhZNOS+smtLZ5PLESCyrqIXCaAWLquB47CaLWSgsW2SR3AgoNFY8Lm3djcJ8=</Modulus><Exponent>AQAB</Exponent><P>+bEWYZVbpy4PXzuDzROsCgR3jbbqBG8IgKZYTeT7jGdqV07nKwth3Oy9tUnd+/PsLoHljacpr6zaIrHIX9xuXQ==</P><Q>3TJ3NhSmg1En9bUQJklryRdeWj42PyGC5CCOVTKY4Xc5+kCx0A8W+wJQgznuDlBkt/fSkxN8tuW3ZIHMuxwTKw==</Q><DP>JZqj8kJaMU1gh0khSmtiB4gwsSkRCWXnc+iZd/G6aKTSgR+i9Pqb3HfTAlCDnARaV468kZ7RSmHP4FXCBZ3fCQ==</DP><DQ>byaAyOgvlCUf01QcvWB/jRj1DJveXnLUdxX079LxB7sFoz8HGum6Pn+3PXnKqd6z/c3GPqm4LZ/ZO+QNoKhG6Q==</DQ><InverseQ>309pMIwEfxqPD/iLklmyraKSc7TEF7dn1MWpZKmzDtMM/g2g9SBewmaACH/6was65bblwAlTKd562bciV7sgwg==</InverseQ><D>UT791L5YAoaUk6KJaYsWnSAHHQ9Mt5QfORSQOF7GX4QVxGk125+nNoFPc/TVrD4BtBBNciSJhtdccpz4w4ZWPA4f31ivrOcBbSJrGqWBQv+ou6r6sLRe2OnBmnFiDWOBL/IaTdkxtdHhBBIl92RFVHWdVpl5jWj68k2h5INZIcE=</D></RSAKeyValue>";

            rsa.FromXmlString(xmlParamsDefault1);

            var dec=rsa.Decrypt(encrypted, false);

            Console.WriteLine($"{plaintext}" + ", rsa utf8 bytes: \r\n" + string.Join(",", dec));

            Console.WriteLine($"{plaintext}" + ", rsa utf8: \r\n" + Encoding.UTF8.GetString(dec));

            Console.ReadLine();

            var de=new Decryptor();

            de.KeySize = 1024;

            var ki = rsa.ExportParameters(true);

            var dec1 = de.DecryptBytes(ki, encrypted, false, false);

            Console.WriteLine($"{plaintext}" + ", rsa1 utf8 bytes: \r\n" + string.Join(",", dec1));

            Console.ReadLine();


        }

        static void test3()
        {
            var xmlParamsDefault = "<RSAKeyValue>" +
                                   "<Modulus>ANe/GS6t5Z7lb7eMIFKH7SpOi4u5u4cvyQlqkAZ2Uc19Rl/ANdKVOzrsOqPZ7ZbRGADZwsjWYYoCMRAc/u0nWhFRvkSS7Ij/k+vw3aCnOf8wQOFQKoWTTkvrJrS2eTyxEgsq6iFwmgFi6rgeOwmi1koLFtkkdwIKDRWPC5t3Y3Cf</Modulus>" +
                                   "<Exponent>AQAB</Exponent>" +
                                   "<P>APmxFmGVW6cuD187g80TrAoEd4226gRvCICmWE3k+4xnaldO5ysLYdzsvbVJ3fvz7C6B5Y2nKa+s2iKxyF/cbl0=</P>" +
                                   "<Q>AN0ydzYUpoNRJ/W1ECZJa8kXXlo+Nj8hguQgjlUymOF3OfpAsdAPFvsCUIM57g5QZLf30pMTfLblt2SBzLscEys=</Q>" +
                                   "<DP>JZqj8kJaMU1gh0khSmtiB4gwsSkRCWXnc+iZd/G6aKTSgR+i9Pqb3HfTAlCDnARaV468kZ7RSmHP4FXCBZ3fCQ==</DP>" +
                                   "<DQ>byaAyOgvlCUf01QcvWB/jRj1DJveXnLUdxX079LxB7sFoz8HGum6Pn+3PXnKqd6z/c3GPqm4LZ/ZO+QNoKhG6Q==</DQ>" +
                                   "<InverseQ>AN9PaTCMBH8ajw/4i5JZsq2iknO0xBe3Z9TFqWSpsw7TDP4NoPUgXsJmgAh/+sGrOuW25cAJUyneetm3Ile7IMI=</InverseQ>" +
                                   "<D>UT791L5YAoaUk6KJaYsWnSAHHQ9Mt5QfORSQOF7GX4QVxGk125+nNoFPc/TVrD4BtBBNciSJhtdccpz4w4ZWPA4f31ivrOcBbSJrGqWBQv+ou6r6sLRe2OnBmnFiDWOBL/IaTdkxtdHhBBIl92RFVHWdVpl5jWj68k2h5INZIcE=</D></RSAKeyValue>";
        }
        static void Main(string[] args)
        {
            // a = System.Convert.FromBase64String("Пользователь @putintest присоединился к чату");

            var ha=new MD5Cng();

            //var utf = Encoding.UTF8.GetBytes("a6IiTdknvZD3mTB8LXDMgpC8NvhZRYiqDYPAAjMsdR0=");

            var b64Bytes = Convert.FromBase64String("a6IiTdknvZD3mTB8LXDMgpC8NvhZRYiqDYPAAjMsdR0=");

            var hash = ha.ComputeHash(b64Bytes);


            test2();
            return;

            RSACryptoServiceProvider rsa = new RSACryptoServiceProvider(1024);

            RSAParameters rsaKeyInfo = rsa.ExportParameters(false);

            //var keyb64 = "exHcJqe1/EWC+Pwp2ZKotcnT16uF68GaVwxr9+NQQqRximgrwZJsPJQosWb6idDxiqwp14U8rKZbhDbw1Pweq/NpOSPFPAihgK+3C4rFdpypAPujW4lqvcg1s7gWH1kBnjoskzdXllYD21qUFn7W1A/Il2JDwfxuzZk0Om6E/x0=";
            var keyb64 = "NDc5MzA2NjAxOTE0MTg2MzA2NzA0OTE1NzQ0NTM4OTgwOTIzMTI0MzQzNzU5MzMyOTIwNjgxNTIwNTM5MjY5Mzk5NDE2OTQ3NDk2NDUzMTczNTU0MjEzMDg0MzAyOTcwNjEwMTA2ODU2NDYzNzczMjkyNTA3ODY5MDA3NjA4MDg0ODQyMTQ3MDI2NDg0OTc1MDQxNjczNzAyOA==";

            rsaKeyInfo.Modulus = Convert.FromBase64String(keyb64);

            rsaKeyInfo.Exponent=new BigInteger(3).ToByteArray();

            rsa.ImportParameters(rsaKeyInfo);


            //var xmlParamsDefault ="<RSAKeyValue><Modulus>wYPLmKU+mvNjtksxNTqbM8XgMh+pH7rt0eQgShaHlQs58xxUMZ/4V1jptXKvlGEoeA/VWEyW5btiHXvlYzSMCdEpEJjXaR79RxjKU//6RGa2r6ode0/aZf2dY0x4eYXyOKxQzAB92OgwIuMBj15EsN/lBXbzcSLq6TbFuq+K/gk=</Modulus><Exponent>AQAB</Exponent></RSAKeyValue>";
            //var xmlParamsDefault = "<RSAKeyValue><Modulus>ODY0MjI1MjgzMzA1NDk1ODA3NzMyODIwODQwNjc2NTIyMzUxMTY1ODQ4OTUwMzUyMTk0NzIxNjU2MzU5Mjc2MzM0MTU0MzM5MDQ5MzM4OTIzNDUxMTU4ODc0OTgwNjY4OTY1NTI0ODg0ODU0NzY5Njg2OTU5MTQ2MTMzNDE1MjY4MzI5Nzc2MjczOTE2NzY5NTQyMjAyMzI1OTQzODk1NDc2NzM1MDMzOTk3MzA4Nzg4ODMxNzQ3Njg0ODEyNjEwNjI4MTA4MDQzMTg2NzYyNzI2MTExMTI1NDQwMzg4MzE0MzI3Nzk2MzYzMzcyMjgxNzQ0ODg5MTkxNzUxMjY1ODcxOTkwODU4OTM1ODUwNzcwMzAzODg3NTc2NzUwMzM2NDkzMTI5NjE3ODkyNDc2ODQzODE=</Modulus><Exponent>Mw==</Exponent></RSAKeyValue>";


            //var xmlParamsDefault ="<RSAKeyValue><Modulus>umfQ2YmL1d0vlj5NAOooDaVQwl3HfLwEdLkJptQSII44asc3huI4BC4O8zOpQ1Ya0inPZSwbfeC1V/wwYz1RCYY5obXvGTz/byXjL2DfpxNzQnRMCJfcV8SlaQJtc49utLAz0A8ebhCxSZk0KJYLZy5bKB8FJkguhc21D9rpMmU=</Modulus><Exponent>AQAB</Exponent></RSAKeyValue>";
            var xmlParamsDefault = "<RSAKeyValue><Modulus>lI5Ervx4la4Ria6wPCO29RXnwnIg9MFK7UlQ2k+N0cXnTjUHfyCxs+KVi+RZz+RgvlCzFyplUzLk1VAnWvQl+xacIf1uBpmgDlbTYOXUs1piGIm7yuPn/L5AObG6Qjeg2KOCvhzdzzqUw2canflIirtNoU5tiFV0pLxepUzrAyE=</Modulus><Exponent>AQAB</Exponent><P>xnICjbb3my0deFF4KVtMNxdpG7Kj92JjMaSyNUlOOy5O03VGb1pGbjflUyuWAd6Tjm0AEz/9woF6DcjbxRR2gQ==</P><Q>v6QZd06ZWIX/OOKrdngQmm3uV+aneT6TiZEk46C5fEhzrl3WP5g/ApSt5Vunjgahb4/81p9UIXrBiO1qmqZ8oQ==</Q><DP>jlSlajlJ/H1uPqbINXlq/7SFybzmB4AEv01uF/P87Ut4dAgQPbuU+maSz4VacPrQAH5DaIskGYa+IPboUcEsgQ==</DP><DQ>lbSfoC/qYtjqc4m+4CES91CBLHGmynQz1PdpldhsjcYbeE8dmzhXoLB81/stfSl42ynkHdUBZ9X5cfnlmUINgQ==</DQ><InverseQ>tMOcqqJnOJHw069e+DaJy2yk/OiBas4ETcCWVi7ARWRkhas+LsPa1xq38EtcQ+LKBEBXZPs3B3qLCQkgYIuPRg==</InverseQ><D>ctVWun1nKS0ZWXizuolREDsSn/hhCVGxfaNC4L7GPfXhS08qsFaxhwAL4ctusYk0T2lKRwn6sUmSImKHSYOZJ0VUlKDk/qx4cIM6iL7ood/B5XAa0rJloHwRNw4xSEdyQRFhFkRFsRBNsxEN02Uj6E8jWzBvzh4AmicF8/sdQAE=</D></RSAKeyValue>";

            //            var xmlParamsDefault =
            //                "<RSAKeyValue>" +
            //                "<Modulus>NDc5MzA2NjAxOTE0MTg2MzA2NzA0OTE1NzQ0NTM4OTgwOTIzMTI0MzQzNzU5MzMyOTIwNjgxNTIwNTM5MjY5Mzk5NDE2OTQ3NDk2NDUzMTczNTU0MjEzMDg0MzAyOTcwNjEwMTA2ODU2NDYzNzczMjkyNTA3ODY5MDA3NjA4MDg0ODQyMTQ3MDI2NDg0OTc1MDQxNjczNzAyOA==</Modulus>" +
            //                "<Exponent>Mw==</Exponent>" +
            //                "<P>MTI3MDk0NjI4MDcyNzkxNDUwNDM5NzE2MjM3NTY1NzU0ODIxMDEwNDUzNTgzMTY1ODAyODc5NjkxMTUxOTE4NDM4NTkwNDE3MDEzNTY3MTUyMDI3OTAwNDc0NjU0NTU0ODM5NDc1MTEyMzU5MTcwNTQ4MjU1MjA1MzIwMjIwNjk1MDA3NjMwMDI2NDkyODQ5ODgyMDM0MDAxMTc=</P>" +
            //                "<Q>Njc5OTg1Njg5NzI2MDIzOTUyMzI1MzAxNjU0NDM1NjI3NzYzMzg0NzA0NzI1Mjk1Mzk4ODk4NDgxMjI4Mzg1OTYzNzY0NDIxNjA2NDI4NDk0NzUzMjY1NzYwNzgwMTI4OTU4NzcxMjQxMDE0MzIwNzU4NDMzMjc0OTQzNDgyMzkxNDAxNjQ1ODI1MDg1NzI1MTI5NTk5NTU5Mw==</Q>" +
            //                "<DP>ODQ3Mjk3NTIwNDg1Mjc2MzM2MjY0Nzc0OTE3MTA1MDMyMTQwMDY5NjkwNTU0NDM4Njg1ODY0NjA3Njc5NDU2MjU3MjY5NDQ2NzU3MTE0MzQ2ODUyNjY5ODMxMDMwMzY1NTk2NTAwNzQ5MDYxMTM2OTg4MzY4MDM1NDY4MTM3OTY2NzE3NTMzNTA5OTUyMzMyNTQ2ODkzMzQxMQ==</DP>" +
            //                "<DQ>NDUzMzIzNzkzMTUwNjgyNjM0ODgzNTM0NDM2MjkwNDE4NTA4OTIzMTM2NDgzNTMwMjY1OTMyMzIwODE4OTIzOTc1ODQyOTQ3NzM3NjE4OTk2NTAyMTc3MTczODUzNDE5MzA1ODQ3NDk0MDA5NTQ3MTcyMjg4ODQ5OTYyMzIxNTk0MjY3NzYzODgzMzkwNDgzNDE5NzMzMDM5NQ==</DQ>" +
            //                "<InverseQ>ODY0MjI1MjgzMzA1NDk1ODA3NzMyODIwODQwNjc2NTIyMzUxMTY1ODQ4OTUwMzUyMTk0NzIxNjU2MzU5Mjc2MzM0MTU0MzM5MDQ5MzM4OTIzNDUxMTU4ODc0OTgwNjY4OTY1NTI0ODg0ODU0NzY5Njg2OTU5MTQ2MTMzNDE1MjY4MzI5Nzc2MjczOTE2NzY5NTQyMjAyMzI1OTQzODk1NDc2NzM1MDMzOTk3MzA4Nzg4ODMxNzQ3Njg0ODEyNjEwNjI4MTA4MDQzMTg2NzYyNzI2MTExMTI1NDQwMzg4MzE0MzI3Nzk2MzYzMzcyMjgxNzQ0ODg5MTkxNzUxMjY1ODcxOTkwODU4OTM1ODUwNzcwMzAzODg3NTc2NzUwMzM2NDkzMTI5NjE3ODkyNDc2ODQzODE=</InverseQ>" +
            //                "<D>NTc2MTUwMTg4ODcwMzMwNTM4NDg4NTQ3MjI3MTE3NjgxNTY3NDQzODk5MzAwMjM0Nzk2NDgxMTA0MjM5NTE3NTU2MTAyODkyNjk5NTU5MjgyMzAwNzcyNTgzMzIwNDQ1OTc3MDE2NTg5OTAzMTc5NzkxMzA2MDk3NDIyMjc2ODQ1NTUzMTg0MTgyNjExMTc5Njk0ODAxNTUwNDk5MjAxNTE5NzkzMDkzNDM0NDI0MzYxNjE5MTU4OTExNDc2ODQxMTM2MDM0ODk4NTYyNjYyMTI0NTU3NTc4OTM2OTQ3NjM2NzY5MDU3NTc0NTc5MzY5Nzk2MTA0NDE2MDEwNjA5MDkwMzUzNTA0MjA3ODM0ODI0OTkyODc5MDk1MDY4MzYxMjU2MDg1NDYzNjY0OTg4NTkxMTU=</D>" +
            //                "</RSAKeyValue>";
            //            var xmlParamsDefault =
            //                        "<RSAKeyValue>" +
            //                        "<Modulus>pxtmFnrGI6Sb8ziyY+NRUDuQ4b/ETw5WabQ4daFQqzsCEr/6J/LLBU/2D5mO5/Wu5U/Rya1E55aYFZeaZMNqAw==</Modulus>" +
            //                        "<Exponent>AQAB</Exponent>" +
            //                        "<P>2TsVXWPEvDIJv/gd2rX9k0UOyXuaYgoAchIH6vUicis=</P>" +
            //                        "<Q>xO4+OYREQfqYRQK7y73+RaUG0IxobT0OQ0c+Ok2hc4k=</Q>" +
            //                        "<DP>K7/xgpiIU9rECeyfnp/OjS14V+3T3vDivBaTj6eFI3c=</DP>" +
            //                        "<DQ>K4N9ClZ4gp+tn6oP9t//XEIvtEsiE+kmyqTmUhmvMAk=</DQ>" +
            //                        "<InverseQ>p7o4BOlKZQZ693R1ViZ66y5gTjUkNNTd2za7/1YGBCs=</InverseQ>" +
            //                        "<D>XZqFVrYy4qhECruJgVZFp/GVuD5Y0gev88nVjl5r911QT+I8vgJSklTso7jTlpMtf2oe7UZ0WRWEtgPS3tZn4Q==</D>" +
            //                        "</RSAKeyValue>";
            rsa.FromXmlString(xmlParamsDefault);


            //            var qqq = Convert.FromBase64String("AQAB");

            //            var bi = new BigInteger(qqq);

            var pub = rsa.ExportParameters(false);
           


            var d = (rsaKeyInfo.D == null) ? string.Empty : Convert.ToBase64String(rsaKeyInfo.D);
            var dp = (rsaKeyInfo.DP == null) ? string.Empty : Convert.ToBase64String(rsaKeyInfo.DP);
            var dq = (rsaKeyInfo.DQ == null) ? string.Empty : Convert.ToBase64String(rsaKeyInfo.DQ);
            var e = (rsaKeyInfo.Exponent == null) ? string.Empty : Convert.ToBase64String(rsaKeyInfo.Exponent);
            var iq = (rsaKeyInfo.InverseQ == null) ? string.Empty : Convert.ToBase64String(rsaKeyInfo.InverseQ);
            var m = (rsaKeyInfo.Modulus == null) ? string.Empty : Convert.ToBase64String(rsaKeyInfo.Modulus);
            var p = (rsaKeyInfo.P == null) ? string.Empty : Convert.ToBase64String(rsaKeyInfo.P);
            var q = (rsaKeyInfo.Q == null) ? string.Empty : Convert.ToBase64String(rsaKeyInfo.Q);


            Console.WriteLine($"rsa.d:{d}");
            Console.WriteLine($"rsa.dp:{dp}");
            Console.WriteLine($"rsa.dq:{dq}");
            Console.WriteLine($"rsa.e:{e},{string.Join(",",rsaKeyInfo.Exponent.Select(i=>i.ToString()))}");
            Console.WriteLine($"rsa.iq:{iq}");
            Console.WriteLine($"rsa.m:{m}");
            Console.WriteLine($"rsa.p:{p}");
            Console.WriteLine($"rsa.q:{q}");

            var list = new List<string>();
            list.Add("Привет");
            list.Add("С новым годом!");
            list.Add("С днём рождения!");
            list.Add("Как у ели как у ёлки уху ели злые волки!");

            /*for (var i = 0; i < 10; i++)
            {

                Console.WriteLine("----------------------------------------------------------");

                //var encrypted = rsa.Encrypt(Encoding.UTF8.GetBytes("a6IiTdknvZD3mTB8LXDMgpC8NvhZRYiqDYPAAjMsdR0="), true);
                var encrypted = rsa.Encrypt(Encoding.UTF8.GetBytes("Привет"), true);

                var encryptedb64 = Convert.ToBase64String(encrypted);

                Console.WriteLine("rsa encrypted: " + encryptedb64);

            }*/

            foreach (var l in list)
            {
                var encrypted = rsa.Encrypt(Encoding.UTF8.GetBytes(l), true);

                var encryptedb64 = Convert.ToBase64String(encrypted);

                Console.WriteLine($"{l}, rsa encrypted: " + encryptedb64);

            }
            Console.ReadLine();

        }
    }
}

