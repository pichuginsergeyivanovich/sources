﻿using System;
using System.CodeDom.Compiler;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using Elliptic;

namespace ConsoleApplication2
{
    public partial class Program
    {
        public static string HashPassword1(string password, string b64salt=null)
        {
            if (password == null)
                throw new ArgumentNullException("password");
            byte[] salt;
            byte[] bytes;


            var rfc2898DeriveBytes = b64salt == null
                ? new Rfc2898DeriveBytes(password, 16, 1000)
                : new Rfc2898DeriveBytes(password, Convert.FromBase64String(b64salt), 1000);

            using (rfc2898DeriveBytes)
            {
                salt = rfc2898DeriveBytes.Salt;
                bytes = rfc2898DeriveBytes.GetBytes(32);
                Console.WriteLine(Convert.ToBase64String(salt) + "|" + Convert.ToBase64String(bytes));
            }
            byte[] inArray = new byte[49];
            Buffer.BlockCopy((Array)salt, 0, (Array)inArray, 1, 16);
            Buffer.BlockCopy((Array)bytes, 0, (Array)inArray, 17, 32);
            return Convert.ToBase64String(inArray);
        }
        public static string HashPassword(string password)
        {
            // Generate the hash, with an automatic 32 byte salt
            Rfc2898DeriveBytes rfc2898DeriveBytes = new Rfc2898DeriveBytes(password, 16, 1000);
            byte[] bytes = rfc2898DeriveBytes.GetBytes(32);
            byte[] salt = rfc2898DeriveBytes.Salt;
            //Return the salt and the hash
            return Convert.ToBase64String(salt) + "|" + Convert.ToBase64String(bytes);
        }

        public static void main_for_rfc2898DeriveBytes()
        {
       //Console.WriteLine(HashPassword("putin"));
                Console.WriteLine(HashPassword1("putin", "tY5LZft0Vp7ghM7JzO4CoA=="));


                byte[] numArray = Convert.FromBase64String("ALWOS2X7dFae4ITOyczuAqD7g6WxR2GvfLUFEbVY/k33o9pH7Y67ASU2GIG4RHeiaA==");

                byte[] salt = new byte[16];
                Buffer.BlockCopy((Array)numArray, 1, (Array)salt, 0, 16);

                byte[] a = new byte[32];
                Buffer.BlockCopy((Array)numArray, 17, (Array)a, 0, 32);

                byte[] bytes;
                Rfc2898DeriveBytes rfc2898DeriveBytes = new Rfc2898DeriveBytes("putin", salt, 1000);
                bytes = rfc2898DeriveBytes.GetBytes(32);
                Console.WriteLine(Convert.ToBase64String(salt));
                Console.WriteLine(Convert.ToBase64String(bytes));
                var j = new List<byte> {0};
                j.AddRange(salt);
                j.AddRange(bytes);
                Console.WriteLine(Convert.ToBase64String(j.ToArray()));



                Console.ReadLine();            
        }

        public class Session
        {
            public string FromUser { get; set; }
            public string ToUser { get; set; }
            //A 32-byte value that is used to create Chain Keys
            public byte[] RootKey32=new byte[32];
            //A 32-byte value that is used to create Message Keys
            public byte[] ChainKey32 = new byte[32];
            //An 80-byte value that is used to encrypt message contents. 32 bytes are used for an AES-256 key, 32 bytes for a HMAC-SHA256 key, and 16 bytes for an IV.
            public byte[] MessageKey80 = new byte[80];

        }

        public class UserPublicKeys
        {
            public UserPublicKeys(string name, byte[] identityKey, byte[] signedPreKey, byte[] signedPreKeyHash, Queue<byte[]> oneTimePreKeys)
            {
                IdentityKey = identityKey;

                SignedPreKey = signedPreKey;

                SignedPreKeyHash = signedPreKeyHash;

                OneTimePreKeys = oneTimePreKeys;
            }
            
            public byte[] IdentityKey { get; set; }
            public byte[] SignedPreKey { get; set; }
            public byte[] SignedPreKeyHash { get; set; }
            public Queue<byte[]> OneTimePreKeys { get; set; }
        }

        public class SessionSetupInfo
        {
            public SessionSetupInfo(byte[] identityKey, byte[] signedPreKey, byte[] signedPreKeyHash, byte[] oneTimePreKey)
            {
                IdentityKey = identityKey;

                SignedPreKey = signedPreKey;

                SignedPreKeyHash = signedPreKeyHash;

                OneTimePreKey = oneTimePreKey;

            }

            public byte[] IdentityKey { get; set; }
            public byte[] SignedPreKey { get; set; }
            public byte[] SignedPreKeyHash { get; set; }
            public byte[] OneTimePreKey { get; set; }
        }
        public class Server
        {
            public void AddUser(User user)
            {
                if(!_users.ContainsKey(user.Username))
                    _users.Add(user.Username, user);

                else
                {
                    Debug.WriteLine("user already registered on server");
                }
            }
            Dictionary<string, User> _users = new Dictionary<string, User>();
            Dictionary<string,UserPublicKeys> _userKeys=new Dictionary<string, UserPublicKeys>();

            public void RegisterUser(string name, UserPublicKeys publicKeys)
            {
                if (!_userKeys.ContainsKey(name))
                    _userKeys.Add(name, publicKeys);
                else
                    _userKeys[name] = publicKeys;
            }

            public SessionSetupInfo RequestForUserSessionSetup(string username)
            {
                if (!_userKeys.ContainsKey(username))
                    return null;

                var ui= _userKeys[username];

                //Console.WriteLine($"{username}'s ui.SignedPreKey pub:{Convert.ToBase64String(ui.SignedPreKey)}");

                return new SessionSetupInfo(ui.IdentityKey, ui.SignedPreKey, ui.SignedPreKeyHash, ui.OneTimePreKeys.Dequeue());

                
            }

            public void SendHeader(string username,string EInitiator_b64, string IInitiator_b64)
            {
                if (!_users.ContainsKey(username))
                    return;

                _users[username].RecieveHeader(this, EInitiator_b64, IInitiator_b64);
            }
        }
        public class User
        {
            public string Username { get; set; }
            //A long-term Curve25519 key pair, generated at install time.
            private Key _identityKey;
            //A medium-term Curve25519 key pair, generated at install time, signed by the Identity Key, and rotated on a periodic timed basis.
            private Key _preKey;
            private byte[] _signedPreKeyH256;
            //A queue of Curve25519 key pairs for one time use, generated at install time, and replenished as needed
            private List<Key> _oneTimePreKeysQueue=new List<Key>();

            public UserPublicKeys PublicKeys
            {
                get
                {
                    var q = new Queue<byte[]>();
                    foreach (var k in _oneTimePreKeysQueue)
                    {
                        q.Enqueue(k.PublicKey);
                    }
                    
                    return new UserPublicKeys(Username, _identityKey.PublicKey, _preKey.PublicKey, _signedPreKeyH256, q);
                }
                
            }

            public void Setup()
            {

                _identityKey = Key.Generate();

                Console.WriteLine($"{Username}'s identity pri:{Convert.ToBase64String(_identityKey.PrivateKey)}");
                Console.WriteLine($"{Username}'s identity pub:{Convert.ToBase64String(_identityKey.PublicKey)}");

                _preKey = Key.Generate();

                Console.WriteLine($"{Username}'s pre pri:{Convert.ToBase64String(_preKey.PrivateKey)}");
                Console.WriteLine($"{Username}'s pre pub:{Convert.ToBase64String(_preKey.PublicKey)}");

                _signedPreKeyH256 = Curve25519.GetSigningKey(_identityKey.PrivateKey);

                for (int i = 0; i < 100; i++)
                {
                    var k = Key.Generate();

                    _oneTimePreKeysQueue.Add(k);
                }
                
            }

            public void InitSessionSetup(Server server, string recipient)
            {
                var recipientKeyInfo = server.RequestForUserSessionSetup(recipient);

                var Irecipient = recipientKeyInfo.IdentityKey;
                var Srecipient = recipientKeyInfo.SignedPreKey;
                var Orecipient = recipientKeyInfo.OneTimePreKey;

                var Einitiator = Key.Generate();
                var Iinitiator = _identityKey.PrivateKey;

//                Console.WriteLine($"Irecipient: {Convert.ToBase64String(Irecipient)}");
//                Console.WriteLine($"Srecipient: {Convert.ToBase64String(Srecipient)}");
//                Console.WriteLine($"Orecipient: {Convert.ToBase64String(Orecipient)}");
//                Console.WriteLine($"Einitiator: {Convert.ToBase64String(Einitiator.PrivateKey)}");
//                Console.WriteLine($"Iinitiator: {Convert.ToBase64String(Iinitiator)}");


                var masterSecret = new byte[128];

                //Console.WriteLine($"{Username}'s identity pri(Iinitiator):{Convert.ToBase64String(Iinitiator)}");
                Console.WriteLine($"{recipient}'s one time pub(Orecipient):{Convert.ToBase64String(Orecipient)}");


                var ECDH_Iinitiator_Srecipient = Curve25519.GetSharedSecret(Iinitiator, Srecipient);
                var ECDH_Einitiator_Irecipient = Curve25519.GetSharedSecret(Einitiator.PrivateKey, Irecipient);
                var ECDH_Einitiator_Srecipient = Curve25519.GetSharedSecret(Einitiator.PrivateKey, Srecipient);
                var ECDH_Einitiator_Orecipient = Curve25519.GetSharedSecret(Einitiator.PrivateKey, Orecipient);


                Buffer.BlockCopy(ECDH_Iinitiator_Srecipient, 00, masterSecret, 0, 32);
                Buffer.BlockCopy(ECDH_Einitiator_Irecipient, 00, masterSecret, 32, 32);
                Buffer.BlockCopy(ECDH_Einitiator_Srecipient, 00, masterSecret, 64, 32);
                Buffer.BlockCopy(ECDH_Einitiator_Orecipient, 00, masterSecret, 96, 32);

                Console.WriteLine($"ECDH_Iinitiator_Srecipient: {Convert.ToBase64String(ECDH_Iinitiator_Srecipient)}");
                Console.WriteLine($"ECDH_Einitiator_Irecipient: {Convert.ToBase64String(ECDH_Einitiator_Irecipient)}");
                Console.WriteLine($"ECDH_Einitiator_Srecipient: {Convert.ToBase64String(ECDH_Einitiator_Srecipient)}");
                Console.WriteLine($"ECDH_Einitiator_Orecipient: {Convert.ToBase64String(ECDH_Einitiator_Orecipient)}");

                var masterSecretB64 = Convert.ToBase64String(masterSecret);

                Console.WriteLine($"\r\nsecret from init: {masterSecretB64}");

                var session = new Session
                {
                    ToUser = recipient,
                    FromUser = Username
                };


                var rfc2898DeriveBytesHkdf = new Func<byte[], byte[]>((s) => {
                    var hkdf = new Rfc2898DeriveBytes(s, Curve25519.CreateRandomPrivateKey(), 1000);
                    return hkdf.GetBytes(64);
                });

                var bytes64Hash = rfc2898DeriveBytesHkdf(masterSecret);

                session.RootKey32=new byte[32];
                Buffer.BlockCopy(session.RootKey32, 00, bytes64Hash, 0, 32);

                session.ChainKey32 = new byte[32];
                Buffer.BlockCopy(session.ChainKey32, 00, bytes64Hash, 32, 32);

                //session.ChainKey32 = rfc2898DeriveBytesHkdf(masterSecret);

                server.SendHeader(recipient, Convert.ToBase64String(Einitiator.PublicKey), Convert.ToBase64String(_identityKey.PublicKey));

            }
            public byte[] MasterSecret { get; set; }
            public void RecieveHeader(Server server, string EInitiator_b64, string IInitiator_b64)
            {
                var Einitiator = Convert.FromBase64String(EInitiator_b64);
                var Iinitiator = Convert.FromBase64String(IInitiator_b64);


                //var recipientKeyInfo = server.RequestForUserSessionSetup(Username);

                var Irecipient = _identityKey.PrivateKey;
                var Srecipient = _preKey.PrivateKey;
                var Orecipient = _oneTimePreKeysQueue.FirstOrDefault();



                //Console.WriteLine($"Irecipient: {Convert.ToBase64String(Irecipient)}");
                //Console.WriteLine($"Srecipient: {Convert.ToBase64String(Srecipient)}");
                //Console.WriteLine($"Orecipient: {Convert.ToBase64String(Orecipient)}");
                //Console.WriteLine($"Einitiator: {Convert.ToBase64String(Einitiator)}");
                //Console.WriteLine($"Iinitiator: {Convert.ToBase64String(Iinitiator)}");

                var masterSecret = new byte[128];

                var ECDH_Iinitiator_Srecipient = Curve25519.GetSharedSecret(Srecipient, Iinitiator);
                var ECDH_Einitiator_Irecipient = Curve25519.GetSharedSecret(Irecipient, Einitiator);
                var ECDH_Einitiator_Srecipient = Curve25519.GetSharedSecret(Srecipient, Einitiator);
                var ECDH_Einitiator_Orecipient = Curve25519.GetSharedSecret(Orecipient.PrivateKey, Einitiator);


                Buffer.BlockCopy(ECDH_Iinitiator_Srecipient, 00, masterSecret, 0, 32);
                Buffer.BlockCopy(ECDH_Einitiator_Irecipient, 00, masterSecret, 32, 32);
                Buffer.BlockCopy(ECDH_Einitiator_Srecipient, 00, masterSecret, 64, 32);
                Buffer.BlockCopy(ECDH_Einitiator_Orecipient, 00, masterSecret, 96, 32);
                Console.WriteLine("\r\n");
                
                Console.WriteLine($"ECDH_Iinitiator_Srecipient: {Convert.ToBase64String(ECDH_Iinitiator_Srecipient)}");
                Console.WriteLine($"ECDH_Einitiator_Irecipient: {Convert.ToBase64String(ECDH_Einitiator_Irecipient)}");
                Console.WriteLine($"ECDH_Einitiator_Srecipient: {Convert.ToBase64String(ECDH_Einitiator_Srecipient)}");
                Console.WriteLine($"ECDH_Einitiator_Orecipient: {Convert.ToBase64String(ECDH_Einitiator_Orecipient)}");
 





                var masterSecretB64 = Convert.ToBase64String(masterSecret);

                Console.WriteLine($"\r\nsecret from recieve: {masterSecretB64}");

            }
        }
        public static void Main(string[] args)
        {
            var server = new Server();

            var user1 = new User {Username = "Alice"};
            user1.Setup();

            var user2 = new User {Username = "Bob"};
            user2.Setup();

            server.AddUser(user1);

            server.AddUser(user2);

            server.RegisterUser(user1.Username, user1.PublicKeys);

            server.RegisterUser(user2.Username, user2.PublicKeys);


            user1.InitSessionSetup(server, user2.Username);

            Console.ReadLine();
        }

        static void Main2(string[] args)
        {
            

            ////Identity key Pair, long term, install time
            //byte[] alicePrivate = Curve25519.ClampPrivateKey(aliceRandomBytes);
            //byte[] alicePublic = Curve25519.GetPublicKey(alicePrivate);

            new User().Setup();
        }
    }
    class Alice
    {
        public static byte[] alicePublicKey;

        public static void Main3(string[] args)
        {
            using (ECDiffieHellmanCng alice = new ECDiffieHellmanCng())
            {

                alice.KeyDerivationFunction = ECDiffieHellmanKeyDerivationFunction.Hash;
                alice.HashAlgorithm = CngAlgorithm.Sha256;
                alicePublicKey = alice.PublicKey.ToByteArray();

                

                Bob bob = new Bob();
                CngKey bobPublicKey = CngKey.Import(bob.bobPublicKey, CngKeyBlobFormat.EccPublicBlob);
                byte[] aliceKey = alice.DeriveKeyMaterial(bobPublicKey);

                byte[] encryptedMessage = null;
                byte[] iv = null;
                Send(aliceKey, "Secret message", out encryptedMessage, out iv);
                bob.Receive(encryptedMessage, iv);
            }

        }

        private static void Send(byte[] key, string secretMessage, out byte[] encryptedMessage, out byte[] iv)
        {
            using (Aes aes = new AesCryptoServiceProvider())
            {
                aes.Key = key;
                iv = aes.IV;

                // Encrypt the message
                using (MemoryStream ciphertext = new MemoryStream())
                using (CryptoStream cs = new CryptoStream(ciphertext, aes.CreateEncryptor(), CryptoStreamMode.Write))
                {
                    byte[] plaintextMessage = Encoding.UTF8.GetBytes(secretMessage);
                    cs.Write(plaintextMessage, 0, plaintextMessage.Length);
                    cs.Close();
                    encryptedMessage = ciphertext.ToArray();
                }
            }
        }

    }
    public class Bob
    {
        public byte[] bobPublicKey;
        private byte[] bobKey;
        public Bob()
        {
            using (ECDiffieHellmanCng bob = new ECDiffieHellmanCng())
            {

                bob.KeyDerivationFunction = ECDiffieHellmanKeyDerivationFunction.Hash;
                bob.HashAlgorithm = CngAlgorithm.Sha256;
                bobPublicKey = bob.PublicKey.ToByteArray();
                bobKey = bob.DeriveKeyMaterial(CngKey.Import(Alice.alicePublicKey, CngKeyBlobFormat.EccPublicBlob));

            } 
        }

        public void Receive(byte[] encryptedMessage, byte[] iv)
        {

            using (Aes aes = new AesCryptoServiceProvider())
            {
                aes.Key = bobKey;
                aes.IV = iv;
                // Decrypt the message
                using (MemoryStream plaintext = new MemoryStream())
                {
                    using (CryptoStream cs = new CryptoStream(plaintext, aes.CreateDecryptor(), CryptoStreamMode.Write))
                    {
                        cs.Write(encryptedMessage, 0, encryptedMessage.Length);
                        cs.Close();
                        string message = Encoding.UTF8.GetString(plaintext.ToArray());
                        Console.WriteLine(message);
                    }
                }
            }
        }

    }
}
