﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using Elliptic;

namespace ConsoleApplication2
{
    public class DoubleRatchet
    {
        const int MAX_SKIP = 10;
        public void RatchetInitAlice(DoubleRatchetState state, byte[] SK, byte[] bob_dh_public_key, Key aliceRatchet)
        {
            state.DHs = aliceRatchet;

            state.DHr = bob_dh_public_key;

            var ecdhOut = Curve25519.GetSharedSecret(state.DHs.PrivateKey, state.DHr);

            var keys = HKDF.KDF_RK(SK, ecdhOut);

            state.RK=keys.PrivateKey;

            state.CKs = keys.PublicKey;

            state.CKr = null;

            state.Ns = 0;

            state.Nr = 0;

            state.PN = 0;

            state.MKSKIPPED = new Dictionary<string, byte[]>();

        }

        public void RatchetInitBob(DoubleRatchetState state , byte[] SK , Key bob_dh_key_pair )
        {
            state.DHs = bob_dh_key_pair;
            state.DHr = null;
            state.RK = SK;
            state.CKs = null;
            state.CKr = null;
            state.Ns = 0;
            state.Nr = 0;
            state.PN = 0;
            state.MKSKIPPED =new Dictionary<string, byte[]>();
        }

        public DoubleRatchetMessage RatchetEncrypt( DoubleRatchetState state , string plaintext)
        {
            var keys = HKDF.KDF_RK(state.CKs, new byte[] {0x2});

            state.CKs = keys.PrivateKey;

            var mk = keys.PublicKey;// KDF_CK(state.CKs)

            Console.WriteLine($"encrypt:message-key-{Convert.ToBase64String(mk)}");

            var header = new DoubleRatchetMessageHeader()
            {
                DH = state.DHs.PublicKey,
                PN = state.PN,
                N = state.Ns
            };
            state.Ns += 1;


            var body = EncryptDataString(mk, plaintext);

            return new DoubleRatchetMessage()
            {
                Header = header,
                Body = body
            };
        }

        public DoubleRatchetMessageBody EncryptDataString(byte[] mk, string plaintext)
        {
            using (Aes aes = new AesCryptoServiceProvider())
            {
                aes.Key = mk;
                var iv = aes.IV;

                // Encrypt the message
                using (var ciphertext = new MemoryStream())
                using (var cs = new CryptoStream(ciphertext, aes.CreateEncryptor(), CryptoStreamMode.Write))
                {
                    byte[] plaintextMessage = Encoding.UTF8.GetBytes(plaintext);

                    cs.Write(plaintextMessage, 0, plaintextMessage.Length);

                    cs.Close();

                    return new DoubleRatchetMessageBody() {Encrypted = ciphertext.ToArray(), IV = iv};
                }
            }
        }
        public void EncryptDataFile(byte[] key, String sourceFile, String destFile)
        {
            // Initialize the keyed hash object.
            using (var hmac = new HMACSHA256(key))
            {
                using (var inStream = new FileStream(sourceFile, FileMode.Open))
                {
                    using (var outStream = new FileStream(destFile, FileMode.Create))
                    {
                        // Compute the hash of the input file.
                        byte[] hashValue = hmac.ComputeHash(inStream);
                        // Reset inStream to the beginning of the file.
                        inStream.Position = 0;
                        // Write the computed hash value to the output file.
                        outStream.Write(hashValue, 0, hashValue.Length);
                        // Copy the contents of the sourceFile to the destFile.
                        int bytesRead;
                        // read 1K at a time
                        byte[] buffer = new byte[1024];
                        do
                        {
                            // Read from the wrapping CryptoStream.
                            bytesRead = inStream.Read(buffer, 0, 1024);
                            outStream.Write(buffer, 0, bytesRead);
                        } while (bytesRead > 0);
                    }
                }
            }
            return;
        } // end SignFile
        public string DecryptDataString(byte[] mk, DoubleRatchetMessage message)
        {
            using (Aes aes = new AesCryptoServiceProvider())
            {
                aes.Key = mk;
                aes.IV = message.Body.IV;

                using (var plaintext = new MemoryStream())
                {
                    using (var cs = new CryptoStream(plaintext, aes.CreateDecryptor(), CryptoStreamMode.Write))
                    {
                        cs.Write(message.Body.Encrypted, 0, message.Body.Encrypted.Length);
                        cs.Close();
                        return Encoding.UTF8.GetString(plaintext.ToArray());
                    }
                }
            }
        }
        public string RatchetDecrypt(DoubleRatchetState state , DoubleRatchetMessage message )
        {

            var plaintext = TrySkippedMessageKeys(state, message);

            if (plaintext != null)
                return plaintext;

            if (message.Header.DH != state.DHr)
            {
                SkipMessageKeys(state, message.Header.PN);
                DHRatchet(state, message.Header);
            }

            SkipMessageKeys(state, message.Header.N);

            var keys = HKDF.KDF_RK(state.CKr, new byte[] { 0x02 });

            state.CKr = keys.PrivateKey;

            var mk = keys.PublicKey; //KDF_CK(state.CKr)

            Console.WriteLine($"decrypt:message-key-{Convert.ToBase64String(mk)}");

            state.Nr += 1;

            return DecryptDataString(mk, message);
        }

        public string TrySkippedMessageKeys(DoubleRatchetState state, DoubleRatchetMessage message)
        {

            var pair = $"{Convert.ToBase64String(message.Header.DH)}_{message.Header.N}";

            if (state.MKSKIPPED.ContainsKey(pair))
            {
                var mk = state.MKSKIPPED[pair];

                state.MKSKIPPED.Remove(pair);

                return DecryptDataString(mk, message);

            }
            return null;

        }



        public void SkipMessageKeys(DoubleRatchetState state, int until)
        {
            if(state.Nr + MAX_SKIP < until) 
                throw new ApplicationException("error");

            if (state.CKr != null)
            {
                while (state.Nr < until)
                {
                    var keys = HKDF.KDF_RK(state.CKr, new byte[] {0x02});
                    state.CKr = keys.PrivateKey;
                    var mk = keys.PublicKey; //KDF_CK(state.CKr)
                    
                    var pair = $"{Convert.ToBase64String(state.DHr)}_{state.Nr}";
                    state.MKSKIPPED[pair] = mk;
                    state.Nr += 1;
                }
            }
        }

        public void DHRatchet(DoubleRatchetState state , DoubleRatchetMessageHeader header )
        {
            state.PN = state.Ns;
            state.Ns = 0;
            state.Nr = 0;
            state.DHr = header.DH;

            var ecdh = Curve25519.GetSharedSecret(state.DHs.PrivateKey, state.DHr);
            var keys = HKDF.KDF_RK(state.RK, ecdh);

            state.RK = keys.PrivateKey;
            state.CKr = keys.PublicKey;


            state.DHs = Key.Generate();

            var newecdh = Curve25519.GetSharedSecret(state.DHs.PrivateKey, state.DHr);
            var newkeys = HKDF.KDF_RK(state.RK, newecdh);


            state.RK = newkeys.PrivateKey;
            state.CKs = newkeys.PublicKey;

        }

        public static void Main()
        {
            //var skey = Key.Generate();

            //var bb = new byte[64];
            
            //Buffer.BlockCopy(skey.PrivateKey, 00, bb, 0, 32);

            //Buffer.BlockCopy(skey.PublicKey, 00, bb, 32, 32);

            //var skeyb64 = Convert.ToBase64String(bb);


            //return;

            var dr=new DoubleRatchet();

            var aliceState = new DoubleRatchetState {Owner = "alice"};

            var bobState = new DoubleRatchetState {Owner = "bob"};

            var aliceSecret = Key.Generate();
            var bobSecret = Key.Generate();






            ECDiffieHellmanCng a = new ECDiffieHellmanCng();
            

            var k = CngKey.Import(a.PublicKey.ToByteArray(), CngKeyBlobFormat.EccPublicBlob);





            var sharedSecret = Curve25519.GetSharedSecret(aliceSecret.PrivateKey, bobSecret.PublicKey);

            var bobRatchetKey = Key.Generate();
            var aliceRatchetKey = Key.Generate();

            dr.RatchetInitAlice(aliceState, sharedSecret, bobRatchetKey.PublicKey, aliceRatchetKey);

            dr.RatchetInitBob(bobState,sharedSecret, bobRatchetKey);


            var sstate = aliceState;
            var rstate = bobState;


            for (var i = 0; i < 10; i++)
            {

                var message = dr.RatchetEncrypt(sstate, $"Hello world #{i}!");

                var text = dr.RatchetDecrypt(rstate, message);

                sstate = (sstate == aliceState) ? bobState : aliceState;

                rstate = (rstate == bobState) ? aliceState : bobState;
            }
            for (var i = 0; i < 10; i++)
            {

                var message = dr.RatchetEncrypt(sstate, $"Hello world #{i}! from {sstate.Owner}");

                var text = dr.RatchetDecrypt(rstate, message);

                if (i % 2 == 0)
                {
                    sstate = (sstate == aliceState) ? bobState : aliceState;

                    rstate = (rstate == bobState) ? aliceState : bobState;
                }
            }
        }
    }
}
