using System.Security.Cryptography;
using Elliptic;

namespace ConsoleApplication2
{
        public class Key
        {
            public Key(byte[] privateKey, byte[] publicKey)
            {
                PublicKey = publicKey;

                PrivateKey = privateKey;
            }
            public byte[] PublicKey { get; set; }
            public byte[] PrivateKey { get; set; }

            public static Key Generate()
            {
                byte[] randomBytes = new byte[32];

                RNGCryptoServiceProvider.Create().GetBytes(randomBytes);

                byte[] privateKey = Curve25519.ClampPrivateKey(randomBytes);
                byte[] publicKey = Curve25519.GetPublicKey(privateKey);

                

                var key = new Key(privateKey, publicKey);

                return key;
            }

        }

}