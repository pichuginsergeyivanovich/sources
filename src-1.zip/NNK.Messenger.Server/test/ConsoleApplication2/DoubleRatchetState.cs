﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplication2
{
    public class DoubleRatchetState
    {
        public string Owner { get; set; }
        //DH Ratchet key pair (the “sending” or “self” ratchet key)
        public Key DHs { get; set; } 
        //DH Ratchet public key (the “received” or “remote” key)
        public byte[] DHr { get; set; } 
        //32-byte Root Key
        public byte[] RK { get; set; } 
        //32-byte Chain Keys for sending and receiving
        public byte[] CKs { get; set; } 
        //32-byte Chain Keys for sending and receiving
        public byte[]CKr { get; set; }  
        //Message numbers for sending and receiving 
        public int Ns { get; set; }  
        //Message numbers for sending and receiving
        public int Nr { get; set; }  
        //Number of messages in previous sending chain
        public int PN { get; set; } 
        
        //Dictionary of skipped-over message keys, indexed by ratchet public key and message number. Raises an exception if too manyelements are stored.
        public Dictionary<string,byte[]>MKSKIPPED= new Dictionary<string, byte[]>();
    }
}
