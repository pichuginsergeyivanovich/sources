﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplication2
{
    public class DoubleRatchetMessage
    {
        public DoubleRatchetMessageHeader Header { get; set; }
        public DoubleRatchetMessageBody Body { get; set; }
    }
}
