﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplication2
{
    public class DoubleRatchetMessageHeader
    {
        public byte[] DH { get; set; }
        public int PN { get; set; }

        public int N { get; set; }
    }
}
