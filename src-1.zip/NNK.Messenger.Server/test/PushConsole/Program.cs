﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


using NNK.Messenger.Business;
using NNK.Messenger.Business.Dapper;

namespace PushConsole
{
    class Program
    {
        static void Main(string[] args)
        {
            var dp = new DapperConnectionStringProvider();


            var idops = new IdentityOperations(dp);

            var idp = new DapperAspNetIdentityConnectionStringProvider();

            var uops = new UserOperations(idp);
            var pushOps = new PushOperations(idops, uops);

            var cert = File.ReadAllBytes(@"NNKMessagesProdCertificates.p12");

            byte isProdOrDev = 1;

            pushOps.SendPush("Text", new[]
            {
                "28B7FBB28F60BDB94E1D1F360819A9319C0391A3C59AC6224358BC66000D486E"
                //"595AE7DF969E703E7049CF62411F0A2F407BA2A343B55190C3D2C69F32C56F7E"
            }, cert, "",isProdOrDev);

            Console.ReadLine();
        }
    }
}
