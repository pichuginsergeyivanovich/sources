﻿using NNK.Beeline.Services.Business.Data;
using NNK.Beeline.Services.Business.Providers;
using NNK.Beeline.Services.Business.Services;
using NNK.Beeline.Services.Data;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplication1
{
    class Program
    {
        static void sendSms2(string message)
        {
            var ms = new MessagesSplitter();

            var p = new SmppServiceParametersProviderHardcoded();

            var s = new BeelineSmsService(ms, p);

            s.OpenSession();

            //s.SendMessage("CDU NNK", "79067981094", message, null);
            s.SendMessage("8796", "79169266143, 79067981094", message, null);

            s.CloseSession();
        }
        static void sendSms(string message)
        {
            var tr = new SmsTaskRepository();
            var pr = new SmppPacketRepository();
            var rp = new RabbitMqProjectSettingsProvider();
            var eup = new NNK.Beeline.Services.Business.Providers.EmptyUserProvider();
            var rr = new RecipientRepository(eup);

            SmsServiceOperations _smsServiceOps = new SmsServiceOperations(rr, tr, rp, pr);

            var task = new SmsTask();

            task.SmsTaskId = Guid.NewGuid();

            task.From = "8796";

            task.Etc = "+79067981094";

            task.MessageText = message;

            task.Created = DateTime.Now;

            task.RecipientIds = "0";

            task.StatusId = 1;

            task.StatusTime = DateTime.Now;

            task.IsServiceTask = true;

            tr.Insert(task);

            _smsServiceOps.SendSmsFromWeb(task);
        }
        static void Main(string[] args)
        {
            sendSms2("sadhbvjhwajhqs");

            Console.WriteLine("press any key to quit");
            Console.ReadLine();
        }
    }
}
