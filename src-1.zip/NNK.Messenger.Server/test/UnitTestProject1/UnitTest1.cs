﻿using System;
using Dapper.Contrib.Extensions;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using NNK.Messenger.Business.Dapper;
using NNK.Messenger.Core;
using NNK.Messenger.Data;

namespace UnitTestProject1
{
    [TestClass]
    public class UnitTest1
    {
        public class csp : IDapperConnectionStringProvider
        {
            public csp()
            {
                ConnectionString = "Data Source = 10.1.41.60; Initial Catalog = NNK.Messenger.Test; Integrated Security = False; User ID=test; password=test;";
            }

            public string ConnectionString { get; }
        }
        [TestMethod]
        public void TestMethod1()
        {
            var dp = new csp();
            var pops = new NNK.Messenger.Business.Dapper.PartyOperations(dp);
            var amo = new AttachMetadataOperations(dp);

            var co = new ChatOperations(dp, pops);
            var mo = new MessageOperations(dp, co,amo);


            var m = mo.Get(Guid.Parse("B4F2F443-AB0A-4C6B-A6F9-00B62C63F8E1"));


            if (m == null)
                return;

            m.StatusSrvDelivered = true;
            m.StatusDelivered = true;
            m.StatusRead = true;

            var mw = new MessageWrapper
            {
                ID = m.ID,
                Author = m.Author,
                ChatID = m.ChatID,
                Created = m.Created,
                StatusDelivered = m.StatusDelivered,
                StatusRead = m.StatusRead,
                StatusSrvDelivered = m.StatusSrvDelivered,
                Text = m.Text
            };


            mo.Execute(db => db.Update(mw));


            Assert.IsNotNull(m);
        }
        [TestMethod]
        public void ChatOperations_Get_Success()
        {
            var dp = new csp();

            var pops = new NNK.Messenger.Business.Dapper.PartyOperations(dp);

            var co = new ChatOperations(dp, pops);

            var i = co.Get(Guid.Parse("F0E5A3BA-F2D4-422A-95FF-35DCC2A2EE16"));

            Assert.IsNotNull(i);
        }
    }
}
