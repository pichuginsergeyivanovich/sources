﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplication4
{
    class Program
    {
        public class ServerSideKeyHelper
        {
            private ServerSideKeyHelper()
            {
                var strKey = "eLyV8Wt4K7/yJ5mm2wc6dTxj18Vly1adeptRtlGTG0xroiJN2Se9kPeZMHwtcMyCkLw2+FlFiKoNg8ACMyx1HQ==";

                var keyBytes = Convert.FromBase64String(strKey);

                _privateKey = new byte[32];

                _publicKey = new byte[32];

                Buffer.BlockCopy(keyBytes, 00, _privateKey, 0, 32);

                Buffer.BlockCopy(keyBytes, 32, _publicKey, 0, 32);

            }

            byte[] _privateKey;

            byte[] _publicKey;

            static ServerSideKeyHelper _instance;
            public static ServerSideKeyHelper Instance
            {
                get
                {

                    if (_instance == null)
                        _instance = new ServerSideKeyHelper();

                    return _instance;
                }
            }

            public byte[] PrivateKey => _privateKey;
            public byte[] PublicKey => _publicKey;

            public string PublicKeyAsString => Convert.ToBase64String(_publicKey);

        }
        public static byte[] EncryptDataString(byte[] key, string plaintext, out byte[] iv)
        {
            using (Aes aes = new AesCryptoServiceProvider())
            {
                aes.Key = key;

                //aes.IV = new byte[16];

                iv = aes.IV;

                using (var ciphertext = new MemoryStream())
                {
                    using (var cs = new CryptoStream(ciphertext, aes.CreateEncryptor(), CryptoStreamMode.Write))
                    {
                        byte[] plaintextMessage = Encoding.UTF8.GetBytes(plaintext);

                        cs.Write(plaintextMessage, 0, plaintextMessage.Length);

                        cs.Close();

                        return ciphertext.ToArray();
                    }
                }
            }
        }
        static void Main(string[] args)
        {
            var key = ServerSideKeyHelper.Instance.PublicKey;

            byte[] iv;
            Console.WriteLine($"key={Convert.ToBase64String(key)}");
            Console.WriteLine($"Привет, {Convert.ToBase64String(EncryptDataString(key, "Привет", out iv))}, iv={Convert.ToBase64String(iv)}");
            Console.WriteLine($"Жили у бабуси 2 весёлых гуся, {Convert.ToBase64String(EncryptDataString(key, "Жили у бабуси 2 весёлых гуся", out iv))}, iv={Convert.ToBase64String(iv)}");
            Console.ReadLine();
        }
    }
}
